.. aiosqlite documentation master file, created by
   sphinx-quickstart on Sun Apr 26 19:57:46 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. include:: ../README.rst


.. toctree::
    :hidden:
    :maxdepth: 2

    api

.. toctree::
    :hidden:
    :maxdepth: 1

    changelog
    contributing

