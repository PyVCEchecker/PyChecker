# PyLD JSON-LD meta data

__all__ = [
        '__copyright__', '__license__', '__version__'
]

__copyright__ = 'Copyright (c) 2011-2018 Digital Bazaar, Inc.'
__license__ = 'New BSD license'
__version__ = '2.0.3'
