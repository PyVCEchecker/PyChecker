# coding: utf-8
MAJOR_VERSION = 0
MINOR_VERSION = 38
PATCH_VERSION = "0"
__short_version__ = f"{MAJOR_VERSION}.{MINOR_VERSION}"
__version__ = f"{__short_version__}.{PATCH_VERSION}"
