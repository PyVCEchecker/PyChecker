from . import zha, zll

PROFILES = {zha.PROFILE_ID: zha, zll.PROFILE_ID: zll}
