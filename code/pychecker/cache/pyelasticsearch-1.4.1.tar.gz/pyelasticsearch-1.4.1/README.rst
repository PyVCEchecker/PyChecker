Please see http://pyelasticsearch.readthedocs.org/ or the docs folder.
