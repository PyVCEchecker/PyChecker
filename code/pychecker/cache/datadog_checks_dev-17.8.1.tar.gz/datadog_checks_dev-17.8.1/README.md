# Datadog Checks Dev

[![Latest PyPI version][1]][3]
[![Supported Python versions][2]][3]

-----

This is the developer toolkit designed for use by any [Agent-based][5] check or
integration repository.


## Installation

See [this guide][6].

## Documentation

Docs are available [here][7].

[1]: https://img.shields.io/pypi/v/datadog-checks-dev.svg
[2]: https://img.shields.io/pypi/pyversions/datadog-checks-dev.svg
[3]: https://pypi.org/project/datadog-checks-dev/
[5]: https://github.com/DataDog/datadog-agent
[6]: https://datadoghq.dev/integrations-core/setup/#ddev
[7]: https://datadoghq.dev/integrations-core/ddev/about/
