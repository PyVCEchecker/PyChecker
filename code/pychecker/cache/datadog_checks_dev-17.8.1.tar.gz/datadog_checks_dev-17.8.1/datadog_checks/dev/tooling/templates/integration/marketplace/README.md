# {integration_name}

## Overview
High level overview of what this integration does.

Screenshots should be absent for this section, instead put them in the media carousel with captions.

All `###` headers are optional to showcase what this integration includes:

### Metrics

### Events

### Monitors

### Dashboards

## Setup
Specific step-by-step configuration instructions for this integration.

Screenshots are okay for this section, if they help demonstrate configuration steps.

## Uninstallation
Specific step-by-step uninstallation instructions for this integration.

## Support
Information about how and where to go for support for this integration.
