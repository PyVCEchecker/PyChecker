*******
History
*******

1.2.2
=====

* Corrected processing of name with a dot.

1.2.1
=====

* Corrected processing of URLs with a hyphen.

1.2
===

* Improved parsing speed by compiling regex on global context and reusing
  named collection.

1.1
===

* Cleaned up unused packages from requirements.
* Added python 3.4 and 3.5 support.
* Further parsing of valid git URLs.
* Pass pep8 and yapf.
* Added to travis ci.
* Execute one regex at a time.


1.0.2
=====

* Corrected pbr version info package name.

1.0.1
=====

* Support parsing domains which contain a hyphen.

1.0
===

* Initial release.
