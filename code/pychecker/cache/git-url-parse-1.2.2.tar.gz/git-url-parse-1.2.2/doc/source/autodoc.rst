Autodoc
=======

Parser
------

.. autoclass:: giturlparse.parser.Parser
   :members:

.. autoclass:: giturlparse.parser.ParserError
   :members:
