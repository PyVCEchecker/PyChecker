Testing
=======

::

    $ pip install tox
    $ tox
