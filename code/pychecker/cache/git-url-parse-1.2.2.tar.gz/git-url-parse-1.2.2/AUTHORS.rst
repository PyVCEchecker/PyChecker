*******
Credits
*******

Development Leads
=================

* John Dewey (`@retr0h`_)

Core Committers
===============

Contributors
============

.. _`@retr0h`: https://github.com/retr0h
