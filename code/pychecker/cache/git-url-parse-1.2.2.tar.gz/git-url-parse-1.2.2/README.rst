.. image:: http://img.shields.io/travis/retr0h/git-url-parse.svg?style=popout-square&logo=travis
  :target: https://travis-ci.org/retr0h/git-url-parse

.. image:: https://img.shields.io/codecov/c/github/retr0h/git-url-parse.svg?style=popout-square&logo=codecov
  :target: https://codecov.io/gh/retr0h/git-url-parse

.. image:: https://img.shields.io/pypi/v/git-url-parse.svg?style=popout-square&logo=python
  :target: https://pypi.org/project/git-url-parse/

.. image:: https://img.shields.io/readthedocs/git-url-parse.svg?style=popout-square&logo=Read%20the%20Docs
  :target: https://git-url-parse.readthedocs.io/en/latest/

***********
giturlparse
***********

A simple GIT URL parser similar to `giturlparse.py`_.

.. _`giturlparse.py`: https://github.com/FriendCode/giturlparse.py

Documentation
=============

https://git-url-parse.readthedocs.io/

License
=======

MIT
