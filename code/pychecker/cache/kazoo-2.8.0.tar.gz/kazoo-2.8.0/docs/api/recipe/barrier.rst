.. _barrier_module:

:mod:`kazoo.recipe.barrier`
----------------------------

.. automodule:: kazoo.recipe.barrier

Public API
++++++++++

    .. autoclass:: Barrier
        :members:

        .. automethod:: __init__

    .. autoclass:: DoubleBarrier
        :members:

        .. automethod:: __init__
