.. _lease_module:

:mod:`kazoo.recipe.lease`
----------------------------

.. automodule:: kazoo.recipe.lease

Public API
++++++++++

    .. autoclass:: NonBlockingLease
        :members:

        .. automethod:: __init__

    .. autoclass:: MultiNonBlockingLease
        :members:

        .. automethod:: __init__
