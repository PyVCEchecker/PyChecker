"""Internal implementation of `~certbot_dns_nsone.dns_nsone` plugin."""
