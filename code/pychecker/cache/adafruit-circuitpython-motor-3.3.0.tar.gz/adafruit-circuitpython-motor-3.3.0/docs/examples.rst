Simple tests
-------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/motor_servo_sweep_simpletest.py
    :caption: examples/motor_servo_sweep_simpletest.py
    :linenos:

.. literalinclude:: ../examples/motor_pca9685_dc_motor.py
    :caption: examples/motor_pca9685_dc_motor.py
    :linenos:

.. literalinclude:: ../examples/motor_pca9685_stepper_motor.py
    :caption: examples/motor_pca9685_stepper_motor.py
    :linenos:

.. literalinclude:: ../examples/motor_pca9685_servo_sweep.py
    :caption: examples/motor_pca9685_servo_sweep.py
    :linenos:

.. literalinclude:: ../examples/motor_pca9685_continuous_servo.py
    :caption: examples/motor_pca9685_continuous_servo.py
    :linenos:
