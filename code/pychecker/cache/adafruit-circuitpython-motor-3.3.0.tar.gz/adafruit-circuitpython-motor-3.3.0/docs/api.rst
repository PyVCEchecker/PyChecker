
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_motor.motor
   :members:

.. automodule:: adafruit_motor.servo
  :members:

.. automodule:: adafruit_motor.stepper
 :members:
