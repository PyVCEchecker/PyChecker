from clize import run

def hello_world():
    return "Hello world!"

if __name__ == '__main__':
    run(hello_world)
