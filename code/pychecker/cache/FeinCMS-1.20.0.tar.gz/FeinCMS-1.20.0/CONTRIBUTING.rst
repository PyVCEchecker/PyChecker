=======================
Contributing to FeinCMS
=======================

Submission guidelines
=====================

If you are creating a pull request, fork the repository and make any changes
in your own feature branch.

Write and run tests.


Code of Conduct
===============

This project adheres to the
`Open Code of Conduct <http://todogroup.org/opencodeofconduct/#FeinCMS/dev@feinheit.ch>`_.
By participating, you are expected to honor this code.
