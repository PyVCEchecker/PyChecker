# flake8: noqa
from __future__ import absolute_import, unicode_literals

import warnings

from feincms.module.medialibrary.contents import MediaFileContent


warnings.warn(
    "Import MediaFileContent from feincms.module.medialibrary.contents.",
    DeprecationWarning,
    stacklevel=2,
)
