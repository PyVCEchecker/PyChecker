# flake8: noqa
from __future__ import absolute_import, unicode_literals

import warnings


warnings.warn(
    "The contactform content has been deprecated. Use form-designer instead.",
    DeprecationWarning,
    stacklevel=2,
)
