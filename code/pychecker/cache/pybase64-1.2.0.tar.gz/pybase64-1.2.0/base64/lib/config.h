
#define HAVE_SSSE3                 1
#define HAVE_SSE41                 1
#define HAVE_SSE42                 1
#define HAVE_AVX                   1
#define HAVE_AVX2                  1
#define HAVE_NEON32                0
#define HAVE_NEON64                0
#define HAVE_FAST_UNALIGNED_ACCESS 1
