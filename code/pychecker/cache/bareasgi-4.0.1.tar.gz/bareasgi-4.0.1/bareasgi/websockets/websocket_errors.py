"""Websocket errors"""


class WebSocketInternalError(Exception):
    """Exception raised for a WebSocket internal error"""
