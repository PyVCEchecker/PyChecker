Forms Related Bits
==================


set_form_widgets_attrs
----------------------

**etc.toolbox.set_form_widgets_attrs** allows bulk apply HTML attributes to every field widget of a given form.

.. code-block:: python

        set_form_widgets_attrs(my_form, {'class': 'clickable'})

