from .admins import ReadonlyAdmin
from .models import CustomModelPage
