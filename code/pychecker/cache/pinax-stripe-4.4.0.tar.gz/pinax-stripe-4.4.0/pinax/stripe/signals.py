from .webhooks import registry

WEBHOOK_SIGNALS = registry.signals()
