fedmsg/git-hooks
================

These hooks are to be copied to repo locations so that events on the repos are
broadcast to the bus.
