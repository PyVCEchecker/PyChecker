.. _conf:

=============
Configuration
=============

fedmsg requires some configuration before it will work properly.

.. automodule:: fedmsg.config
