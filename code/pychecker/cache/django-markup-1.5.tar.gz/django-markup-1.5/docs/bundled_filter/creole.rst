.. _filter-creole:

Creole Wiki Syntax
==================

- Filter name: ``creole``
- Pypi package: ``python-creole``

This is a Python implementation of a parser for the Creole_
wiki markup language.

.. _Creole: http://wikicreole.org/wiki/Creole1.0
