.. _filter-widont:

Widont Filter
=============

- Filter name: ``widont``
- Provided by django-markup

Puts a non-breaking space ``&nbsp;`` within the last two words, to avoid
orphan words in the next line.
