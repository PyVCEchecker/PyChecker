Update-file-legal-hold command
******************************

.. argparse::
   :module: b2.console_tool
   :func: get_parser
   :prog: b2
   :path: update-file-legal-hold
