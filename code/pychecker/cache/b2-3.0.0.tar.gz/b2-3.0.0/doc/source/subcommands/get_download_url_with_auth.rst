Get-download-url-with-auth command
**********************************

.. argparse::
   :module: b2.console_tool
   :func: get_parser
   :prog: b2
   :path: get-download-url-with-auth
