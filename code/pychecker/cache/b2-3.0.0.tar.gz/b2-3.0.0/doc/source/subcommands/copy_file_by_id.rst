Copy-file-by-id command
***********************

.. argparse::
   :module: b2.console_tool
   :func: get_parser
   :prog: b2
   :path: copy-file-by-id
