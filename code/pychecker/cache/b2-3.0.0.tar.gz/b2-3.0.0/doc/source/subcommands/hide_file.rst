Hide-file command
*****************

.. argparse::
   :module: b2.console_tool
   :func: get_parser
   :prog: b2
   :path: hide-file
