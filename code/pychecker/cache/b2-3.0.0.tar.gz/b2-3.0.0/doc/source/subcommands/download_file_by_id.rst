Download-file-by-id command
***************************

.. argparse::
   :module: b2.console_tool
   :func: get_parser
   :prog: b2
   :path: download-file-by-id
