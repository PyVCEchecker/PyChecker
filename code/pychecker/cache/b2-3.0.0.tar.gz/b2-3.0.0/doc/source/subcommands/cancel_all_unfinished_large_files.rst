Cancel-all-unfinished-large-files command
*****************************************

.. argparse::
   :module: b2.console_tool
   :func: get_parser
   :prog: b2
   :path: cancel-all-unfinished-large-files
