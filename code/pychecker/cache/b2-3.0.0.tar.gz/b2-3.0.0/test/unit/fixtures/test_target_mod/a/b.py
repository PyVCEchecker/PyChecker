######################################################################
#
# File: test/unit/fixtures/test_target_mod/a/b.py
#
# Copyright 2019 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################


def g(x):
    return x + 1
