######################################################################
#
# File: test/unit/fixtures/test_target_mod/z.py
#
# Copyright 2019 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################


def f():
    return 'from target'
