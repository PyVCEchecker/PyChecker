######################################################################
#
# File: test/unit/fixtures/test_source_mod/c/d.py
#
# Copyright 2019 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################


def h(x):
    return x + 2
