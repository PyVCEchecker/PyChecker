class ExporterException(Exception):
    pass


class ConfigException(ExporterException):
    pass
