Installing hyperframe
=====================

hyperframe is trivial to install from the Python Package Index. Simply run:

.. code-block:: console

    $ pip install hyperframe

Alternatively, feel free to download one of the release tarballs from
`our GitHub page`_, extract it to your favourite directory, and then run

.. code-block:: console

    $ python setup.py install

hyperframe has no external dependencies.



.. _our GitHub page: https://github.com/python-hyper/hyperframe
