# -*- coding: cp1250 -*-

print("�")
