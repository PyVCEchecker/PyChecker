"""test: avoid already-imported warning: PYTEST_DONT_REWRITE."""
