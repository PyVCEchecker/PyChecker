Microsoft Azure CLI 'role' Command Module for Role-Based Access Control (RBAC)
==============================================================================

This package is for the 'role' module.
i.e. 'az role'


