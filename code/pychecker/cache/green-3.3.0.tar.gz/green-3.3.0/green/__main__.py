from __future__ import absolute_import

import sys

from .cmdline import main

sys.exit(main())
