class CurrentlyNotSupported(Exception):
    pass