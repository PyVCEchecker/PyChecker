import sys

from prospector.run import main

if __name__ == "__main__":
    sys.exit(main())
