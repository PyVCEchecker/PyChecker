demands documentation
=====================

.. automodule:: demands
    :members:
    :undoc-members:
    :show-inheritance:
