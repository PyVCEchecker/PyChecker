Jabber IDs (JID)
=================

.. module:: sleekxmpp.xmlstream.jid

.. autoclass:: JID
    :members:
