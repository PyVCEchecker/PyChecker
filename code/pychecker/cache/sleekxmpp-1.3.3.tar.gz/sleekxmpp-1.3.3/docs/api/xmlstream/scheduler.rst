=========
Scheduler
=========

.. module:: sleekxmpp.xmlstream.scheduler

.. autoclass:: Task
    :members:

.. autoclass:: Scheduler
    :members:
