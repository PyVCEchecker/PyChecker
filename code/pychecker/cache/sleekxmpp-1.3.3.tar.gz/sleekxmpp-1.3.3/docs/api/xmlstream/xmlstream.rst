==========
XML Stream
==========

.. module:: sleekxmpp.xmlstream.xmlstream

.. autoexception:: RestartStream

.. autoclass:: XMLStream
    :members:
