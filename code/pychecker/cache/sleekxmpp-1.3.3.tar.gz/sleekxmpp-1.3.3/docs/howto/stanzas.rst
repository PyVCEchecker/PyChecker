.. _work-with-stanzas:

How to Work with Stanza Objects
===============================


.. _create-stanza-interfaces:

Defining Stanza Interfaces
--------------------------


.. _create-stanza-plugins:

Creating Stanza Plugins
-----------------------



.. _create-extension-plugins:

Creating a Stanza Extension
---------------------------



.. _override-parent-interfaces:

Overriding a Parent Stanza
--------------------------
