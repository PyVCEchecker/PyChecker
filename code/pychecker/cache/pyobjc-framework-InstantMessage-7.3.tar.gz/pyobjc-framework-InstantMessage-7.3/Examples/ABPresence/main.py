import ABPersonDisplayNameAdditions  # noqa: F401
import PeopleDataSource  # noqa: F401
import ServiceWatcher  # noqa: F401
from PyObjCTools import AppHelper


AppHelper.runEventLoop()
