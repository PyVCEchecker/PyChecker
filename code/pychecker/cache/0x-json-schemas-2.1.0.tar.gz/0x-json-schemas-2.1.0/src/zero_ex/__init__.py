"""0x Python API."""
__import__("pkg_resources").declare_namespace(__name__)  # type: ignore
