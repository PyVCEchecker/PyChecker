===
API
===

.. toctree::
   :maxdepth: 2

   face.rst
   bbox.rst
   size_metrics.rst
   bitmap_size.rst
   bitmap.rst
   charmap.rst
   outline.rst
   glyph.rst
   bitmap_glyph.rst
   glyph_slot.rst
   sfnt_name.rst
   stroker.rst
   constants.rst
