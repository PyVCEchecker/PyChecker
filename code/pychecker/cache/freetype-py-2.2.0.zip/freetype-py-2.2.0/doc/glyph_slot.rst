.. currentmodule:: freetype

Glyph slot
==========
.. autoclass:: GlyphSlot
   :members:
