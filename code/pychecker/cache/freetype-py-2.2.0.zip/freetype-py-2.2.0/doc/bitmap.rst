.. currentmodule:: freetype

Bitmap
======
.. autoclass:: Bitmap
   :members:
