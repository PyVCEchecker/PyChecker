TT_MAC_IDS
==========

A list of valid values for the 'encoding_id' for TT_PLATFORM_MACINTOSH
charmaps and name entries.

.. data:: TT_MAC_ID_ROMAN

.. data:: TT_MAC_ID_TELUGU

.. data:: TT_MAC_ID_GURMUKHI

.. data:: TT_MAC_ID_TIBETAN

.. data:: TT_MAC_ID_SIMPLIFIED_CHINESE

.. data:: TT_MAC_ID_SINDHI

.. data:: TT_MAC_ID_SINHALESE

.. data:: TT_MAC_ID_RUSSIAN

.. data:: TT_MAC_ID_KANNADA

.. data:: TT_MAC_ID_VIETNAMESE

.. data:: TT_MAC_ID_MONGOLIAN

.. data:: TT_MAC_ID_DEVANAGARI

.. data:: TT_MAC_ID_HEBREW

.. data:: TT_MAC_ID_TAMIL

.. data:: TT_MAC_ID_THAI

.. data:: TT_MAC_ID_BURMESE

.. data:: TT_MAC_ID_MALDIVIAN

.. data:: TT_MAC_ID_TRADITIONAL_CHINESE

.. data:: TT_MAC_ID_JAPANESE

.. data:: TT_MAC_ID_GREEK

.. data:: TT_MAC_ID_LAOTIAN

.. data:: TT_MAC_ID_KHMER

.. data:: TT_MAC_ID_UNINTERP

.. data:: TT_MAC_ID_ORIYA

.. data:: TT_MAC_ID_RSYMBOL

.. data:: TT_MAC_ID_MALAYALAM

.. data:: TT_MAC_ID_GEEZ

.. data:: TT_MAC_ID_KOREAN

.. data:: TT_MAC_ID_GUJARATI

.. data:: TT_MAC_ID_BENGALI

.. data:: TT_MAC_ID_ARABIC

.. data:: TT_MAC_ID_GEORGIAN

.. data:: TT_MAC_ID_ARMENIAN

.. data:: TT_MAC_ID_SLAVIC

