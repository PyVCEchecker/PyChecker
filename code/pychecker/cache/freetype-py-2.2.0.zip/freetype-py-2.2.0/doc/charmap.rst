.. currentmodule:: freetype

Charmap
=======
.. autoclass:: Charmap
   :members:
