Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/pca9685_simpletest.py
    :caption: examples/pca9685_simpletest.py
    :linenos:

.. literalinclude:: ../examples/pca9685_calibration.py
    :caption: examples/pca9685_calibration.py
    :linenos:

.. literalinclude:: ../examples/pca9685_servo.py
    :caption: examples/pca9685_servo.py
    :linenos:
