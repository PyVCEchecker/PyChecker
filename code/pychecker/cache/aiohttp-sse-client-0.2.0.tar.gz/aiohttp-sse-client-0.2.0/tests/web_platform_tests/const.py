WPT_SERVER = 'http://www.w3c-test.org/eventsource/'
