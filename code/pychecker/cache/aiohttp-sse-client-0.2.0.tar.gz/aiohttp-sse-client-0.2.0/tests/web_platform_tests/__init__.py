"""Tests against web-platform-tests eventsource test suite.

..seealso: https://github.com/web-platform-tests/wpt/tree/master/eventsource
"""
