# -*- coding: utf-8 -*-

"""Top-level package for SSE Client."""

__author__ = """Jason Hu"""
__email__ = 'awaregit@gmail.com'
__version__ = '0.2.0'
