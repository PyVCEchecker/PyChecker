=======
History
=======

0.2.0 (2020-10-20)
------------------

**Breaking Changes**

* Drop Python 3.5 support
* Add Python 3.8 support

**Non functional changes**

* Clarify the license (Apache Software License 2.0), thanks @fabaff
* Update dependency packages


0.1.7 (2020-03-30)
------------------

* Allow passing kwargs without specifying headers

0.1.6 (2019-08-06)
------------------

* Fix Unicode NULL handling in event id field

0.1.5 (2019-08-06)
------------------

* Fix last id reconnection (by @Ronserruya)

0.1.4 (2018-10-04)
------------------

* Switch to Apache Software License 2.0

0.1.3 (2018-10-03)
------------------

* Change the error handling, better fit the live specification.

0.1.2 (2018-10-03)
------------------

* Implement auto-reconnect feature.

0.1.1 (2018-10-02)
------------------

* First release on PyPI.
