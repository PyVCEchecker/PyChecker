Welcome to irc documentation!
=============================

.. toctree::
   :maxdepth: 1

   history
   irc

.. include:: ../README.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

