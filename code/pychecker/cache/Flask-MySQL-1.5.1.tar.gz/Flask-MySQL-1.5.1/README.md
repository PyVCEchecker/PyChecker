Flask-MySQL
===========

Flask-MySQL allows you to access MySQL directly from your flask application.

To install it :

    pip install Flask-MySQL

To suggest a feature or report a bug :
https://github.com/cyberdelia/flask-mysql/issues
