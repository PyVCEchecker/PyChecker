from django.apps import AppConfig


class TestConfig(AppConfig):
    name = "django_countries.tests"
    label = "django_countries_tests"
