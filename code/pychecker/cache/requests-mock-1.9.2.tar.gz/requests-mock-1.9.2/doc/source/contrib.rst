==================
Additional Loading
==================

Common additional loading mechanism are supported in the :py:mod:`requests_mock.contrib` module.

These modules may require dependencies outside of what is provided by `requests_mock` and so must be provided by the including application.

.. toctree::

    fixture
    pytest
