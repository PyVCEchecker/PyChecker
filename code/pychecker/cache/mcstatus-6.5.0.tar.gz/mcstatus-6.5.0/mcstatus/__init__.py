from mcstatus.server import MinecraftServer, MinecraftBedrockServer
