# coding: utf-8

"""
Workflow mgmgt + task scheduling + dependency resolution.
"""

__author__ = 'The Luigi Authors'
__contact__ = 'https://github.com/spotify/luigi'
__license__ = 'Apache License 2.0'
__version__ = '3.0.0'
__status__ = 'Production'
