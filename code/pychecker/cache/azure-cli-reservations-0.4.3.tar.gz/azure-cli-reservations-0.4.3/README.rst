Microsoft Azure CLI 'reservations' Command Module
=================================================

This package is for the 'reservations' module.
i.e. 'az reservations'
