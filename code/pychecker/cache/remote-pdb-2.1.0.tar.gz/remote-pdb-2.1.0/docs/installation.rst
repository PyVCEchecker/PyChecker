============
Installation
============

At the command line::

    pip install remote-pdb
