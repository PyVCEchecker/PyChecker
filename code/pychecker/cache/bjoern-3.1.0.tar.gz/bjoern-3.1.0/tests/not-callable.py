import bjoern
bjoern.run(object(), '0.0.0.0', 8080)
