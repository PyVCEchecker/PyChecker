Would you like to contribute to **poyo**? You're awesome! 😃

Please check out the [good first issue][good first issue] label for tasks,
that are good candidates for your first contribution to poyo. Your
contributions are greatly appreciated! Every little bit helps and credit will
always be given.

Everyone interacting in the poyo project's codebases, issue trackers, chat
rooms, and mailing lists is expected to follow the [PyPI Code of
Conduct][code of conduct].

Join the poyo [community][community]! 🌍🌏🌎

[code of conduct]: https://www.pypa.io/en/latest/code-of-conduct/
[community]: https://github.com/hackebrot/poyo/blob/master/COMMUNITY.md
[good first issue]: https://github.com/hackebrot/poyo/labels/good%20first%20issue
