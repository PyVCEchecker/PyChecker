version_info = (1, 0, 2)
__version__ = '.'.join(map(str, version_info))
