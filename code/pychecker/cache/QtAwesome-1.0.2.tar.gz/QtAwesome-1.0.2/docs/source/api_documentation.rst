API Reference Documentation
---------------------------

.. automodule:: qtawesome
