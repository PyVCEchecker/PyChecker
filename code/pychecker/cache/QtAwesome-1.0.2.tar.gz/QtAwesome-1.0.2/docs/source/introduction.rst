Introduction
------------

QtAwesome enables iconic fonts such as Font Awesome and Elusive Icons in PyQt
and PySide applications.

It started as a Python port of the QtAwesome_ C++ library by Rick Blommers.

.. _QtAwesome: https://github.com/gamecreature/QtAwesome
