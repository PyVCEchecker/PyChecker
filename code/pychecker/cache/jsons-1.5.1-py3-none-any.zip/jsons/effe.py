"""
Some awesome module
"""


class SomeCoolClass:
    """
    Some awesome class
    """

    def cool_method(self, x: int):
        """
        Some awesome method
        Args:
            x: some cool parameter.

        Returns: something cool.

        """
        return 42
