IPython Vega
============

IPython/Jupyter notebook module for `Vega <https://github.com/vega/vega/>`_
and `Vega-Lite <https://github.com/vega/vega-lite/>`_.
Notebooks with embedded visualizations can be viewed on GitHub and nbviewer.

For more information, see https://github.com/vega/ipyvega.

Installation Notes
------------------
When installing from PyPI, extra steps may be required to enable the Jupyter
notebook extension. For more information, see the
`github page <https://github.com/vega/ipyvega>`_.
