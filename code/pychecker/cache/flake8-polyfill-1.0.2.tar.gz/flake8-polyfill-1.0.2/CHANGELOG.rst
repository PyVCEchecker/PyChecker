1.0.2 (2017-12-29)
------------------

- Fix bug where user-supplied value for an option is ignored if the option
  is transformed with `comma_separated_list` or `normalize_paths` (!4)

1.0.1 (2016-07-19)
------------------

- Fix some packaging bugs

1.0.0 (2016-07-19)
------------------

- Release Initial Version of flake8-polyfill

- Includes:

  * ``flake8_polyfill.options`` for Flake8 2.x/3.x compatibility handling

  * ``flake8_polyfill.stdin`` for Flake8 2.x stdin monkey patching that can
    also be used on Flake8 3.x

  * ``flake8_polyfill.version`` which can be used to retrieve a tuple to
    test Flake8's version information on all versions of Flake8
