"""The polyfill package for Flake8 plugins."""

__version__ = '1.0.2'
__version_info__ = tuple(int(i) for i in __version__.split('.') if i.isdigit())
