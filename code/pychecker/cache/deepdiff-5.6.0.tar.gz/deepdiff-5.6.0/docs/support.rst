:doc:`/index`

Support
=======

Hello,

This is Sep, the creator of DeepDiff. Thanks for using DeepDiff!
If you find a bug please create a ticket on our `github repo`_

Please note that my time is very limited for support given my other commitments so it may take a while to get back to you. In case you need direct contact for a pressing issue, I can be reached via hello at zepworks . com email address for consulting.

Thank you!

Sep

.. _github repo: https://github.com/seperman/deepdiff

Back to :doc:`/index`
