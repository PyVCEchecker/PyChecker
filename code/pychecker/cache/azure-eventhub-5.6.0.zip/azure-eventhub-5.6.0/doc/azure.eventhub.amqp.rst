azure.eventhub.amqp package
===========================

    .. autoclass:: azure.eventhub.amqp.AmqpAnnotatedMessage
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.amqp.AmqpMessageHeader
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.amqp.AmqpMessageProperties
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.amqp.AmqpMessageBodyType
        :members:
        :undoc-members:
        :inherited-members:
