azure.eventhub.exceptions package
=================================

    .. autoclass:: azure.eventhub.exceptions.EventHubError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.ConnectError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.ConnectionLostError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.EventDataError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.EventDataSendError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.AuthenticationError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.OwnershipLostError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.ClientClosedError
        :members:
        :undoc-members:

    .. autoclass:: azure.eventhub.exceptions.OperationTimeoutError
        :members:
        :undoc-members:
