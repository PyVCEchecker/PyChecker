============
Installation
============

To install Parsel, we recommend you to use `pip <https://pip.pypa.io/>`_::

    $ pip install parsel

You `probably shouldn't
<https://stackoverflow.com/questions/3220404/why-use-pip-over-easy-install>`_,
but you can also install it with easy_install::

    $ easy_install parsel
