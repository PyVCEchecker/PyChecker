=======
Credits
=======

Development Lead
----------------

* Johan Lübcke <johan@lubcke.se>

Contributors
------------

* Davide Olianas <ubuntupk@gmail.com>
* Andrzej Klajnert <andrzejk@cadence.com>
