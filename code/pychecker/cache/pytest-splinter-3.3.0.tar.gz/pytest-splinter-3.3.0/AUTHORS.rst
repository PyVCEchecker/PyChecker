Authors
=======

`Anatoly Bubenkov <bubenkoff@gmail.com>`_
    original idea and implementation, new features and improvements

These people have contributed to `pytest-splinter`, in alphabetical order:

* `Alessio Bogon <youtux@github.com>`_
* `Andreas Pelme <andreas@pelme.se>`_
* `Andrey Makhnach <andrey.makhnach@gmail.com>`_
* `Aymeric Augustin <https://myks.org/>`_
* `Daniel Hahler <github@thequod.de>`_
* `Hugo van Kemenade <https://github.com/hugovk/>`_
* `Ionel Cristian Mărieș <contact@ionelmc.ro>`_
* `Joshua Fehler <jsfehler@github.com>`_
* `Laurence Rowe <l@lrowe.co.uk>`_
* `Marco Buccini <markon@github.com>`_
* `Michał Pasternak <michal.dtz@gmail.com>`_
* `Michel Sabchuk <michel@sabchuk.com.br>`_
* `Mikko Ohtamaa <mikko@opensourcehacker.com>`_
* `Oleg Pidsadnyi <oleg.pidsadnyi@gmail.com>`_
* `Peter Lauri <peterlauri@gmail.com>`_
* `Suresh V <sureshvv@github.com>`_
* `Tomáš Ehrlich <tomas.ehrlich@gmail.com>`_
* `Tony Narlock <tony@git-pull.com>`_
