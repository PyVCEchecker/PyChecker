import sys
import pytest
from sdl2.ext import algorithms


class TestSDL2ExtAlgorithms(object):
    __tags__ = ["sdl2ext"]

    @pytest.mark.skip("not implemented")
    def test_cohensutherland(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_liangbarsky(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_clipline(self):
        pass

    def test_point_on_line(self):
        pass
