(index)=

# libtmux

```{include} ../README.md

```

## Table of Contents

```{toctree}
:maxdepth: 2

quickstart
about
properties
traversal
servers
sessions
windows
panes
api
glossary
developing
history

```
