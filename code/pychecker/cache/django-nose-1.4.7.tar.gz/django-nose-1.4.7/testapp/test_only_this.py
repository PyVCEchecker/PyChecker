"""Django's test runner won't find this, but nose will."""


def test_multiplication():
    """Check some advanced maths."""
    assert 2 * 2 == 4
