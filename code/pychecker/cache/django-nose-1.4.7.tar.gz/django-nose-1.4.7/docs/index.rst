.. django-nose documentation master file

===========
django-nose
===========

.. include:: ../README.rst
    :start-after: .. Omit badges from docs

Contents
--------

.. toctree::
   :maxdepth: 2

   installation
   usage
   upgrading
   contributing
   authors
   changelog

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

