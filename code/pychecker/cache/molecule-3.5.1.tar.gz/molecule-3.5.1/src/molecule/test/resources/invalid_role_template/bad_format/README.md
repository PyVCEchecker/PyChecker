This is a custom readme that's inside the invalid role template.
When trying to use the role command with this template, an exception should be raised,
as the name of the parent folder is wrongly written.
