========
Usage
========

To use pipreqs in a project::

    import pipreqs
