#!/usr/bin/env python
from bandit.cli import main
main.main()
