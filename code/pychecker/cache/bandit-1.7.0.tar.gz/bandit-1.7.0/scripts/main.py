#!/usr/bin/env python
# -*- coding:utf-8 -*-

# Copyright 2014 Hewlett-Packard Development Company, L.P.
#
# SPDX-License-Identifier: Apache-2.0


from bandit import bandit

if __name__ == '__main__':
    bandit.main()
