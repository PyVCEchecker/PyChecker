import os

os.system('/bin/echo hi')
