subprocess.call(["/bin/ls", "-l"])
subprocess.call(["/bin/ls", "-l"]) #noqa
subprocess.call(["/bin/ls", "-l"]) # noqa
subprocess.call(["/bin/ls", "-l"]) # nosec
subprocess.call(["/bin/ls", "-l"])
subprocess.call(["/bin/ls", "-l"]) #nosec
subprocess.call(["/bin/ls", "-l"])
