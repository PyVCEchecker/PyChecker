def subprocess_shell_cmd():
    # sample function with known subprocess shell cmd candidates

def yaml_load():
    # sample function with known yaml.load candidates

def xml_sax_make_parser():
    # sample function with known xml.sax.make_parser candidates
