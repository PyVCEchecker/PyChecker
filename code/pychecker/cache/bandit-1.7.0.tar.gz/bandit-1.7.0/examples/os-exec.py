import os

os.execl(path, arg0, arg1)
os.execle(path, arg0, arg1, env)
os.execlp(file, arg0, arg1)
os.execlpe(file, arg0, arg1, env)
os.execv(path, args)
os.execve(path, args, env)
os.execvp(file, args)
os.execvpe(file, args, env)

