import os

os.startfile('/bin/foo.docx')
os.startfile('/bin/bad.exe')
os.startfile('/bin/text.txt')
