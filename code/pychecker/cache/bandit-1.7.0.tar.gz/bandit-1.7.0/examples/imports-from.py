from subprocess import Popen

from ..foo import sys
from . import sys
from .. import sys
from .. import subprocess
from ..subprocess import Popen
