exec("do evil")
exec "do evil"