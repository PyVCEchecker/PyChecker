----
text
----

.. automodule:: bandit.formatters.text
