------
screen
------

.. automodule:: bandit.formatters.screen
