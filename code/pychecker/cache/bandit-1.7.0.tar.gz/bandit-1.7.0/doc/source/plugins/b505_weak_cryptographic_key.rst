----------------------------
B505: weak_cryptographic_key
----------------------------

.. automodule:: bandit.plugins.weak_cryptographic_key
