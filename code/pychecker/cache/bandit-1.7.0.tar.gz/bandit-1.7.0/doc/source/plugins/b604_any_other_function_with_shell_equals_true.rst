-----------------------------------------------
B604: any_other_function_with_shell_equals_true
-----------------------------------------------

.. currentmodule:: bandit.plugins.injection_shell

.. autofunction:: any_other_function_with_shell_equals_true
   :noindex:
