--------------------------
B502: ssl_with_bad_version
--------------------------

.. currentmodule:: bandit.plugins.insecure_ssl_tls

.. autofunction:: ssl_with_bad_version
   :noindex:
