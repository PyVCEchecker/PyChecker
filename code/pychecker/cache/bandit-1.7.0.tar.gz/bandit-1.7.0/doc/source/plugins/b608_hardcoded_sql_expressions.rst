-------------------------------
B608: hardcoded_sql_expressions
-------------------------------

.. automodule:: bandit.plugins.injection_sql
