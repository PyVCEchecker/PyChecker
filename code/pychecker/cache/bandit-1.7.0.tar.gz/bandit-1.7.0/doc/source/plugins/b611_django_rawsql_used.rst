------------------------
B611: django_rawsql_used
------------------------

.. currentmodule:: bandit.plugins.django_sql_injection

.. autofunction:: django_rawsql_used
   :noindex:
