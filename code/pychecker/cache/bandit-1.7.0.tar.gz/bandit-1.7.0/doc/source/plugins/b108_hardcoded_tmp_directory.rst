-----------------------------
B108: hardcoded_tmp_directory
-----------------------------

.. automodule:: bandit.plugins.general_hardcoded_tmp
