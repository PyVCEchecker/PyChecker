---------------------------
B503: ssl_with_bad_defaults
---------------------------

.. currentmodule:: bandit.plugins.insecure_ssl_tls

.. autofunction:: ssl_with_bad_defaults
   :noindex:
