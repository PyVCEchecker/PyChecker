---------------------------------
B606: start_process_with_no_shell
---------------------------------

.. currentmodule:: bandit.plugins.injection_shell

.. autofunction:: start_process_with_no_shell
   :noindex:
