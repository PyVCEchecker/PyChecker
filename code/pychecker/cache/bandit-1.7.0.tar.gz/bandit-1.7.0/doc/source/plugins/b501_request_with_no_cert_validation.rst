-------------------------------------
B501: request_with_no_cert_validation
-------------------------------------

.. automodule:: bandit.plugins.crypto_request_no_cert_validation
