----------------------
B703: django_mark_safe
----------------------

.. currentmodule:: bandit.plugins.django_xss

.. autofunction:: django_mark_safe
   :noindex:
