-----------------------------------
B104: hardcoded_bind_all_interfaces
-----------------------------------

.. automodule:: bandit.plugins.general_bind_all_interfaces
