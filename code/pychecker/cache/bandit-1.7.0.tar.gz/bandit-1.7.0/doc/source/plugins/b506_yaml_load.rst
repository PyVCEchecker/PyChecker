---------------
B506: yaml_load
---------------

.. automodule:: bandit.plugins.yaml_load
