-------------------------
B504: ssl_with_no_version
-------------------------

.. currentmodule:: bandit.plugins.insecure_ssl_tls

.. autofunction:: ssl_with_no_version
   :noindex:
