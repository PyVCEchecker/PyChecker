-------------------------
B112: try_except_continue
-------------------------

.. automodule:: bandit.plugins.try_except_continue
