-------------------------------
B105: hardcoded_password_string
-------------------------------

.. currentmodule:: bandit.plugins.general_hardcoded_password

.. autofunction:: hardcoded_password_string
   :noindex:
