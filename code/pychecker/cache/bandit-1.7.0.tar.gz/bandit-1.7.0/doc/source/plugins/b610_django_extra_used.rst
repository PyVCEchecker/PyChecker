-----------------------
B610: django_extra_used
-----------------------

.. currentmodule:: bandit.plugins.django_sql_injection

.. autofunction:: django_extra_used
   :noindex:
