--------------------------------
B106: hardcoded_password_funcarg
--------------------------------

.. currentmodule:: bandit.plugins.general_hardcoded_password

.. autofunction:: hardcoded_password_funcarg
   :noindex:
