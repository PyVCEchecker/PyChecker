FeedGenerator
=============

|githubci| |pypi|

.. |githubci| image:: https://img.shields.io/github/workflow/status/getpelican/feedgenerator/build
    :target: https://github.com/getpelican/feedgenerator/actions
    :alt: Build Status

.. |pypi| image:: https://img.shields.io/pypi/v/feedgenerator
    :target: https://pypi.org/project/feedgenerator/
    :alt: PyPI Version

FeedGenerator is a standalone version of Django’s feedgenerator_ module.
It has evolved over time and includes numerous enhancements.

.. _feedgenerator: https://github.com/django/django/blob/master/django/utils/feedgenerator.py
