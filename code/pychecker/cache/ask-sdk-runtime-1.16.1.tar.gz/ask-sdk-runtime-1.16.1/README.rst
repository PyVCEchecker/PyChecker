=============================================================
ASK SDK Runtime - Runtime layer components for Python ASK SDK
=============================================================

ask-sdk-runtime is the Runtime layer package for Alexa Skills Kit (ASK) SDK by
the Software Development Kit (SDK) team for Python. It provides the
base abstraction components and generic implementations for ASK SDKs.
