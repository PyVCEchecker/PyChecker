.. :changelog:

Release History
===============
1.0.6
+++++
* Add `__version__` in `__init__.py`

1.0.5
+++++
* Support PEP420 namespace package

1.0.4
+++++
* MANIFEST file change to fix wheel install

1.0.3
+++++
* Indicate Python 3.7 support

1.0.2
+++++
* Minor fixes

1.0.1
+++++
* Minor fixes

1.0.0
+++++
* Initialize the azure-cli-telemetry package.
