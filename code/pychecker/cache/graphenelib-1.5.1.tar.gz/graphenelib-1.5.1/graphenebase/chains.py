# -*- coding: utf-8 -*-
default_prefix = "GPH"

known_chains = {
    "GPH": {
        "chain_id": "b8d1603965b3eb1acba27e62ff59f74efa3154d43a4188d381088ac7cdf35539",
        "core_symbol": "CORE",
        "prefix": "GPH",
    },
    "TEST": {
        "chain_id": "39f5e2ede1f8bc1a3a54a7914414e3779e33193f1f5693510e73cb7a87617447",
        "core_symbol": "TEST",
        "prefix": "TEST",
    },
}
