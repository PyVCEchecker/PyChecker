from actstream.tests.test_gfk import GFKManagerTestCase
from actstream.tests.test_zombies import ZombieTest
from actstream.tests.test_activity import ActivityTestCase
from actstream.tests.test_feeds import FeedsTestCase
from actstream.tests.test_views import ViewsTest
