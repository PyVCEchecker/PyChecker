First-time contributors: Please fill out the Dropbox Contributor
License Agreement (CLA) at https://opensource.dropbox.com/cla/
(we currently check this manually, so we apologize for delays).

Everyone:

- Please run the tests (`pytest`) and make sure they pass.
- Please add tests for the bug/feature you are fixing/adding.
- Please follow PEP 8 for coding style.
