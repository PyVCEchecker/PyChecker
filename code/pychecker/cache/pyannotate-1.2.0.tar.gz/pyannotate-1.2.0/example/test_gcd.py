# Tests for gcd function.

from gcd import gcd

def test_gcd():
    assert gcd(5, 10) == 5
    assert gcd(12, 45) == 3
