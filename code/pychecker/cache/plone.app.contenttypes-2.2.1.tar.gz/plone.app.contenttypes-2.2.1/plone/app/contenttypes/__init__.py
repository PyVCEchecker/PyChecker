# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory

from . import permissions


permissions  # pyflakes

_ = MessageFactory('plone')
