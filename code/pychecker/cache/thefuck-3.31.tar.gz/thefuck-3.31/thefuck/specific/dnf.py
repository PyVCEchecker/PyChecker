from thefuck.utils import which

dnf_available = bool(which('dnf'))
