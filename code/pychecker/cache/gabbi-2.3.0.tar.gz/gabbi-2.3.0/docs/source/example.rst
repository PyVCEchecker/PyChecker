Example Tests
=============

.. _example:

What follows is a commented example of some tests in a single
file demonstrating many of the :doc:`format` features. See
:doc:`loader` for the Python needed to integrate with a testing
harness.

.. literalinclude:: example.yaml
   :language: yaml


