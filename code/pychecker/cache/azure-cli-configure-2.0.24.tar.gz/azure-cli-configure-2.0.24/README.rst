Microsoft Azure CLI 'configure' Command Module
==============================================

This package is for the 'configure' module.
i.e. 'az configure'
