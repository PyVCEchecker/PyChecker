"""Setup the muffin package."""

from setuptools import setup


setup()
