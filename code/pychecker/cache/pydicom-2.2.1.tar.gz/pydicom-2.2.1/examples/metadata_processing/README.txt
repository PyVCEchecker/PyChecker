.. _metadata_processing_examples:

Metadata processing
-------------------

These examples illustrates the processing available in pydicom to modify the
metadata of DICOM data.
