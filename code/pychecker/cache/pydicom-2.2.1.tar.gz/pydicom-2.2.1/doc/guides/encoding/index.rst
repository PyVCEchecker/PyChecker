
===================
Pixel Data Encoding
===================

*Transfer Syntax UID* specific encoding information:

.. toctree::
   :maxdepth: 1

   rle_lossless


Encoding plugin information: 

.. toctree::
   :maxdepth: 1

   encoder_plugin_options
   encoder_plugins
