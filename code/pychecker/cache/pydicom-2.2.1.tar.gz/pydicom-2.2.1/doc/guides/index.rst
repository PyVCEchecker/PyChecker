:orphan:

======
Guides
======

These guides contain higher-level information for those already familiar with
pydicom:

.. toctree::
   :maxdepth: 1

   element_value_types
   encoding/index
   cli/cli_guide
   glossary
   writing_documentation
