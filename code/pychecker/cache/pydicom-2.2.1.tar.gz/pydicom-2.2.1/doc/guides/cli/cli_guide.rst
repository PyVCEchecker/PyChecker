:orphan:

.. rubric:: pydicom command-line interface

.. _cli_guide:

============================
Command-line Interface Guide
============================

.. versionadded:: 2.2

.. contents::
    :depth: 1
    :local:
    :backlinks: top


.. _cli_intro:
.. include:: cli_intro.rst

.. _cli_show:
.. include:: cli_show.rst

.. _cli_codify:
.. include:: cli_codify.rst

.. _cli_dev:
.. include:: cli_dev.rst
