.. _api_fileio:

Dataset IO
==========

Reading and writing DICOM datasets and support classes and functions.

.. toctree::
   :maxdepth: 2
   :includehidden:

   fileio.read
   fileio.write
   fileio.base
   fileio.util
