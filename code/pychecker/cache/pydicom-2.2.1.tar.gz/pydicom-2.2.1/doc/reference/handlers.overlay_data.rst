.. _api_handlers_overlaydata:

Overlay Data Handlers (:mod:`pydicom.overlays`)
============================================================

.. currentmodule:: pydicom.overlays

.. autosummary::
   :toctree: generated/

   numpy_handler


.. automodule:: pydicom.overlays
   :members:
