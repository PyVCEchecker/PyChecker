.. _api_elem:

Representation of Data Elements
===============================

.. toctree::
   :maxdepth: 2
   :includehidden:

   elem.dataelem
   elem.tag
   elem.values
   elem.multival
   elem.sequence
   elem.valuerep
