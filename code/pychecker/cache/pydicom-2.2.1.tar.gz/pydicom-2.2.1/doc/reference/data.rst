.. _api_data:

Getting Included Datasets (:mod:`pydicom.data`)
===============================================

.. currentmodule:: pydicom.data

Getting datasets included with *pydicom*

.. autosummary::
   :toctree: generated/

   get_charset_files
   get_palette_files
   get_testdata_file
   get_testdata_files
