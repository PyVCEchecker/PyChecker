.. _api_errors:

Exceptions (:mod:`pydicom.errors`)
==================================

.. currentmodule:: pydicom.errors

.. autosummary::
   :toctree: generated/

   InvalidDicomError
