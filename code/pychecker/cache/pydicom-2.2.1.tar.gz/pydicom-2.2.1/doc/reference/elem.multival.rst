.. _api_elem_multival:

Element Multi-value Representation (:mod:`pydicom.multival`)
============================================================

.. currentmodule:: pydicom.multival

Representation of the values for data elements with VM > 1.

.. autosummary::
   :toctree: generated/

   MultiValue
