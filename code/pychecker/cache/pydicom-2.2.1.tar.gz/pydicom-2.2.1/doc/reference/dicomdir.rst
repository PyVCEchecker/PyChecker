.. _api_dicomdir:

DICOMDIR (:mod:`pydicom.dicomdir`)
================================================

.. currentmodule:: pydicom.dicomdir

Representation of DICOMDIR datasets.

.. autosummary::
   :toctree: generated/

   DicomDir
