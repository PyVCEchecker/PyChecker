.. _api_misc:

Miscellaneous (:mod:`pydicom.misc`)
===================================

.. currentmodule:: pydicom.misc

Miscellaneous functions.

.. autosummary::
   :toctree: generated/

   is_dicom
   size_in_bytes
