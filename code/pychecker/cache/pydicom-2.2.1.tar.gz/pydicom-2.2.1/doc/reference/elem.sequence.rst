.. _api_elem_sequence:

Sequence Element Value Representation (:mod:`pydicom.sequence`)
===============================================================

.. currentmodule:: pydicom.sequence

Representation of the value for sequence data elements and utilities.

.. autosummary::
   :toctree: generated/

   Sequence
   validate_dataset
