from __future__ import absolute_import
from .assertpy import assert_that, assert_warn, soft_assertions, fail, soft_fail, add_extension, remove_extension, WarningLoggingAdapter, __version__
from .file import contents_of
