# VLC sample

code taken for regression testing from https://github.com/videolan/vlc
