Canary sample taken from codelite https://github.com/eranif/codelite
License applies as per LICENSE file in this folder
