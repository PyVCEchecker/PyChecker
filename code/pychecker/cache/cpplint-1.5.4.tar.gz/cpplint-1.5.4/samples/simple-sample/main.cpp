// Copyright 2020 foo
#include <main.h>
int main(int argc,char** argv) {
  char* h = "Hello";  //test
    printf(h);
    return 0;
}
