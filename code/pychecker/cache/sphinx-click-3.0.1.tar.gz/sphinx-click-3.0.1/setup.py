#!/usr/bin/env python

from setuptools import setup

setup(
    setup_requires=['pbr>=2.0'],
    pbr=True,
)
