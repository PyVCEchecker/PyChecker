WARNING
=======

This is an outdated python package, please switch to `ezdxf`: https://pypi.org/project/ezdxf/

Advantage of `ezdxf` over `dxfgrabber` is read/write support for DXF versions:

    - R12
    - R2000
    - R2004
    - R2007
    - R2010
    - R2013
    - R2018

Documentation
=============

http://dxfgrabber.readthedocs.io

Source at GitHub.com:

https://github.com/mozman/dxfgrabber.git

Contact
=======

dxfgrabber@mozman.at
