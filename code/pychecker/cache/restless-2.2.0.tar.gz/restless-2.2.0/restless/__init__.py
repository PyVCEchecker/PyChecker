__author__ = 'Daniel Lindsley'
__license__ = 'BSD'
__version__ = (2, 2, 0)
VERSION = '.'.join(map(str, __version__))


from .resources import Resource
