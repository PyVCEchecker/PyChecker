.. ref-exceptions

==========
Exceptions
==========

restless.exceptions
-------------------

.. automodule:: restless.exceptions
   :members:
   :undoc-members:
