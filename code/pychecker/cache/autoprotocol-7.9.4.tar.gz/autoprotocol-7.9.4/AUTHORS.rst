=======
Credits
=======

Autoprotocol-Python is currently maintained by members of Strateos Inc.

Here is a list of active contributors from Strateos:

- Vanessa Biggers - `polarpine <https://github.com/polarpine>`_ - vanessa.biggers@strateos.com
- Yang Choo - `yangchoo <https://github.com/yangchoo>`_ - yang.choo@strateos.com
- Aaron Karlsberg - `aaronstrateos <https://github.com/aaronstrateos>`_ - aaron.karlsberg@strateos.com
- Peter Lee - `pleaderlee <https://github.com/pleaderlee>`_ - peter.lee@strateos.com
- Dylan Leidig - `dzleidig <https://github.com/dzleidig>`_ - dylan.leidig@strateos.com
- Xi Liu - `xiliustrateos <https://github.com/xiliustrateos>`_ - xi.liu@strateos.com
- Eriberto Lopez - `EribertoLopez <https://github.com/EribertoLopez>`_ - eriberto.lopez@strateos.com
- Joshua Nowak - `joshhacksthings <https://github.com/joshhacksthings>`_ - josh.nowak@strateos.com
- Asuka Ota - `aota001 <https://github.com/aota001>`_ - asuka.ota@strateos.com
- Eric Shade - `ericschade <https://github.com/ericschade>`_ - eric.shade@strateos.com



Especially active past contributors we're grateful to:

- Jeremy Apthorp - `nornagon <https://github.com/nornagon>`_
- Jim Culver - `drjimmypants <https://github.com/drjimmypants>`_
- Donald Dalton - `dbdalton2000 <https://github.com/dbdalton2000>`_
- Tali Herzka - `therzka <https://github.com/therzka>`_
- Varun Kanwar - `VarunKanwar <https://github.com/VarunKanwar>`_
- David Lyon - `dauglyon <https://github.com/dauglyon>`_
- Rhys Ormond - `rhysormond <https://github.com/rhysormond>`_
- Cornelia Scheitz - `cojofra <https://github.com/cojofra>`_

`For a full list of Github contributors, please click here <https://github.com/autoprotocol/autoprotocol-python/contributors>`_

For more information about Autoprotocol and its specification, visit `autoprotocol.org <http://www.autoprotocol.org>`_
