"""Maintains current version of package"""
__version__ = "7.9.4"
