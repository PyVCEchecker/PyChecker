Documentation Archive
=====================

- `3.2.0 <https://pyproj4.github.io/pyproj/3.2.0/>`_
- `3.1.0 <https://pyproj4.github.io/pyproj/3.1.0/>`_
- `3.0.1 <https://pyproj4.github.io/pyproj/3.0.1/>`_
- `2.6.1 <https://pyproj4.github.io/pyproj/v2.6.1rel/>`_
- `2.5.0 <https://pyproj4.github.io/pyproj/v2.5.0rel/>`_
- `2.4.2 <https://pyproj4.github.io/pyproj/v2.4.2rel/>`_
- `2.3.1 <https://pyproj4.github.io/pyproj/v2.3.1rel/>`_
- `2.2.2 <https://pyproj4.github.io/pyproj/v2.2.2rel/>`_
- `2.1.3 <https://pyproj4.github.io/pyproj/v2.1.3rel/>`_
- `1.9.6 <https://pyproj4.github.io/pyproj/v1.9.6rel/>`_
