CLI
====

.. argparse::
   :ref: pyproj.__main__.parser
   :prog: pyproj
