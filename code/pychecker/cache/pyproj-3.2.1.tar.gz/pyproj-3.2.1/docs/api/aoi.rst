Area of Interest
==================

pyproj.aoi.AreaOfInterest
--------------------------

.. note:: The backwards compatible import is `pyproj.transformer.AreaOfInterest`

.. autoclass:: pyproj.aoi.AreaOfInterest
    :members:


pyproj.aoi.AreaOfUse
---------------------

.. autoclass:: pyproj.aoi.AreaOfUse
    :members:


pyproj.aoi.BBox
-----------------

.. autoclass:: pyproj.aoi.BBox
    :members:
