Lists
=====


pyproj.list.get_proj_operations_map
-----------------------------------

.. note:: The backwards compatible import is `pyproj.get_proj_operations_map`

.. autofunction:: pyproj.list.get_proj_operations_map


pyproj.list.get_ellps_map
--------------------------

.. note:: The backwards compatible import is `pyproj.get_ellps_map`

.. autofunction:: pyproj.list.get_ellps_map


pyproj.list.get_prime_meridians_map
------------------------------------

.. note:: The backwards compatible import is `pyproj.get_prime_meridians_map`

.. autofunction:: pyproj.list.get_prime_meridians_map
