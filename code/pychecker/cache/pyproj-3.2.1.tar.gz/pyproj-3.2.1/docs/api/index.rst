API Documentation
=================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   crs/index
   transformer
   geod
   proj
   database
   list
   datadir
   network
   sync
   global_context
   enums
   aoi
   exceptions
   show_versions
