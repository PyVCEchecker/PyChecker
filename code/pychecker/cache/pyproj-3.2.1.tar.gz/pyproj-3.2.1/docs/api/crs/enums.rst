Enumerations
============

DatumType
----------

.. autoclass:: pyproj.crs.enums.DatumType
    :members:


CoordinateOperationType
------------------------

.. autoclass:: pyproj.crs.enums.CoordinateOperationType
    :members:


Cartesian2DCSAxis
------------------

.. autoclass:: pyproj.crs.enums.Cartesian2DCSAxis
    :members:


Ellipsoidal2DCSAxis
--------------------

.. autoclass:: pyproj.crs.enums.Ellipsoidal2DCSAxis
    :members:


Ellipsoidal3DCSAxis
--------------------

.. autoclass:: pyproj.crs.enums.Ellipsoidal3DCSAxis
    :members:

VerticalCSAxis
---------------

.. autoclass:: pyproj.crs.enums.VerticalCSAxis
    :members:
