.. _network_api:

PROJ Network Settings
======================


pyproj.network.set_network_enabled
-----------------------------------

.. autofunction:: pyproj.network.set_network_enabled


pyproj.network.is_network_enabled
----------------------------------

.. autofunction:: pyproj.network.is_network_enabled


pyproj.network.set_ca_bundle_path
----------------------------------

.. autofunction:: pyproj.network.set_ca_bundle_path
