import warnings

from feeluown.player.playlist import *  # noqa


warnings.warn('use feeluown.player.playlist please',
              DeprecationWarning, stacklevel=2)
