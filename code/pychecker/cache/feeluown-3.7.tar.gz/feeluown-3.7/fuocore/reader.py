import warnings

# for backward compact
from feeluown.utils.reader import *  # noqa


warnings.warn('use feeluown.utils.reader please',
              DeprecationWarning, stacklevel=2)
