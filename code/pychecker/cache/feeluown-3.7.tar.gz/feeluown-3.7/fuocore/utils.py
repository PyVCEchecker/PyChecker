import warnings

from feeluown.utils.utils import *  # noqa


warnings.warn('use feeluown.utils.utils please',
              DeprecationWarning, stacklevel=2)
