import warnings

from feeluown.media import *  # noqa


warnings.warn('use feeluown.media please',
              DeprecationWarning, stacklevel=2)
