import warnings

# for backward compact
from feeluown.excs import *  # noqa


warnings.warn('use feeluown.excs please',
              DeprecationWarning, stacklevel=2)
