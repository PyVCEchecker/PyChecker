import warnings

from feeluown.utils.dispatch import *  # noqa


warnings.warn('use feeluown.utils.dispatch please',
              DeprecationWarning, stacklevel=2)
