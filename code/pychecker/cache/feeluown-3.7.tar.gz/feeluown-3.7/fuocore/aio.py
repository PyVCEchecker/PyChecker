import warnings

# for backward compact
from feeluown.utils.aio import *  # noqa


warnings.warn('use feeluown.utils.aio please',
              DeprecationWarning, stacklevel=2)
