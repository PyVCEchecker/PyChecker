import warnings

from feeluown.player.base_player import *  # noqa


warnings.warn('use feeluown.player please',
              DeprecationWarning, stacklevel=2)
