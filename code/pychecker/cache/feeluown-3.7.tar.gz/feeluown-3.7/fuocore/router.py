import warnings

# for backward compact
from feeluown.utils.router import *  # noqa


warnings.warn('use feeluown.utils.router please',
              DeprecationWarning, stacklevel=2)
