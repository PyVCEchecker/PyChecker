import warnings

# for backward compact
from feeluown.models.uri import *  # noqa


warnings.warn('use feeluown.models.uri please',
              DeprecationWarning, stacklevel=2)
