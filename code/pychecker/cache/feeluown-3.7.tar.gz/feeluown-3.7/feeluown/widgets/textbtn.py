from PyQt5.QtWidgets import QPushButton


class TextButton(QPushButton):
    pass
