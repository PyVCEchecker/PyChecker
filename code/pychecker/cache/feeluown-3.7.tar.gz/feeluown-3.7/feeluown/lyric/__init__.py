from .live_lyric import LiveLyric


__all__ = (
    'LiveLyric',
)
