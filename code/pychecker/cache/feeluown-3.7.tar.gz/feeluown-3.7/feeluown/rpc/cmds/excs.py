from feeluown.excs import FuoException


class CmdException(FuoException):
    pass
