:orphan:

===================
JupyterHub REST API
===================

.. this doc exists as a resolvable link target
.. which _static files are not

.. meta::
    :http-equiv=refresh: 0;url=../_static/rest-api/index.html

The rest API docs are `here <../_static/rest-api/index.html>`_
if you are not redirected automatically.
