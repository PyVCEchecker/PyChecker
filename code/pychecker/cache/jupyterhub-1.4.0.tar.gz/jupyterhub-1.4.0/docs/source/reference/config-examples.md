# Configuration examples

The following sections provide examples, including configuration files and tips, for the
following:

- Configuring GitHub OAuth
- Using reverse proxy (nginx and Apache)
- Run JupyterHub without root privileges using `sudo`
