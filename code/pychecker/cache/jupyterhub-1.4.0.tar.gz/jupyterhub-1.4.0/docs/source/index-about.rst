=====
About
=====

JupyterHub is an open source project and community. It is a part of the
`Jupyter Project <https://jupyter.org>`_. JupyterHub is an open and inclusive
community, and invites contributions from anyone. This section covers information
about our community, as well as ways that you can connect and get involved.

.. toctree::
   :maxdepth: 1

   contributor-list
   changelog
   gallery-jhub-deployments
