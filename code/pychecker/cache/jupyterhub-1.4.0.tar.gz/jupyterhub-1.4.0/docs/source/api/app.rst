=========================
Application configuration
=========================

Module: :mod:`jupyterhub.app`
=============================

.. automodule:: jupyterhub.app

.. currentmodule:: jupyterhub.app

:class:`JupyterHub`
-------------------

.. autoconfigurable:: JupyterHub
