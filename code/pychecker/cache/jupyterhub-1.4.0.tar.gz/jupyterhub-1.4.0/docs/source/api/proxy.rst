=======
Proxies
=======

Module: :mod:`jupyterhub.proxy`
===============================

.. automodule:: jupyterhub.proxy

.. currentmodule:: jupyterhub.proxy

:class:`Proxy`
--------------

.. autoconfigurable:: Proxy
    :members:

:class:`ConfigurableHTTPProxy`
------------------------------

.. autoconfigurable:: ConfigurableHTTPProxy
    :members: debug, auth_token, check_running_interval, api_url, command
