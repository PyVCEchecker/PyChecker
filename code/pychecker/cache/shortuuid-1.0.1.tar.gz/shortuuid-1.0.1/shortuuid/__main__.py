from .main import uuid

if __name__ == "__main__":
    print(uuid())
