Microsoft Azure CLI 'data lake store' Command Module
====================================================

This package is for the 'data lake store' module.
i.e. 'az dls'


