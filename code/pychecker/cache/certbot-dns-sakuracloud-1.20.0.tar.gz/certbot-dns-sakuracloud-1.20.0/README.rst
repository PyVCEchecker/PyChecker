Sakura Cloud DNS Authenticator plugin for Certbot
