# -*- coding: utf-8 -*-
import os


def run(*args):
    print('Script called from: %s' % os.getcwd())
