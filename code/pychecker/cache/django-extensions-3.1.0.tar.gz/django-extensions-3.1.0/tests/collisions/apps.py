# -*- coding: utf-8 -*-
from django.apps import AppConfig


class FooConfig(AppConfig):
    name = 'tests.collisions'
    app_label = 'collisions'
