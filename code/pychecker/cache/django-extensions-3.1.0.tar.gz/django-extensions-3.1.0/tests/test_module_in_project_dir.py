# -*- coding: utf-8 -*-
from tests.testapp.classes_to_include import BaseIncludedClass


class FourthDerivedClass(BaseIncludedClass):
    pass
