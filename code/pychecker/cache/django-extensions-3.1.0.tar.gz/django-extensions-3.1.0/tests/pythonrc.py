# -*- coding: utf-8 -*-
def pythonrc_test_func():
    return "pythonrc was loaded"
