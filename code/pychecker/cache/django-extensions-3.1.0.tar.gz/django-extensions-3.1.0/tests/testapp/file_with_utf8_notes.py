# -*- coding: utf-8 -*-

# TODO: Russian text followed: Это техт на кириллице
