# -*- coding: utf-8 -*-
def run():
    raise Exception
