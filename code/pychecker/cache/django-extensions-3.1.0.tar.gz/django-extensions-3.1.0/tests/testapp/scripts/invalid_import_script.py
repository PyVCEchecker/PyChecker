# -*- coding: utf-8 -*-
import invalidpackage  # NOQA


def run():
    pass
