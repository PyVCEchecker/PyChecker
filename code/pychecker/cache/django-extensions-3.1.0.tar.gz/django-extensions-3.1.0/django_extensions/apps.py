# -*- coding: utf-8 -*-
from django.apps import AppConfig


class DjangoExtensionsConfig(AppConfig):
    name = 'django_extensions'
    verbose_name = "Django Extensions"
