<!---
-*- mode:markdown -*-
vi:ft=markdown
-->

Authors
=======
This software was written and packaged by [Lev E. Givon](https://github.com/lebedov)

Special thanks are due to the following parties for their contributions:

- [Alex Ford](https://github.com/asford) - bug fix.
- [Colin Jermain](https://github.com/cjermain) - Python 3 support.
- [John Tyree](https://github.com/johntyree) - support for numpy scalar booleans.
- [Mehdi Sadeghi](https://github.com/mehdisadeghi) - bug reports.
- [Sujoy Roy](https://github.com/tvkpz) - bug reports.
- [Jose Coutinho](https://github.com/tiagocoutinho) - make msgpack-numpy  params consistent with msgpack-python.
