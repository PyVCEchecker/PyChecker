VERSION = "2.11.0"


def version():
    return VERSION
