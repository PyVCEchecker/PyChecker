=====
Usage
=====

To use aioresponses in a project::

    import aioresponses
