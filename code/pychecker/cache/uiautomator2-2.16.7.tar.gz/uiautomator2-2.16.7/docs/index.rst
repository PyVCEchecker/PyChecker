.. uiautomator2 documentation master file, created by
   sphinx-quickstart on Tue Feb 18 15:32:23 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to uiautomator2's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: 常用接口

   api

.. toctree::
   :maxdepth: 2
   :caption: 全部接口

   uiautomator2


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
