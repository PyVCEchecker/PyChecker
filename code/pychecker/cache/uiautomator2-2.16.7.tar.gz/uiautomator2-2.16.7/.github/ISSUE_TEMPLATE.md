**看完请删掉该内容**

*提Bug需要注意的事项*

请务必提供详细的信息，能够复现你的问题，否则很难帮你解决。没用的Issue将自动被机器人打上`Invalid`标签并且自动关闭！！。

- 手机型号
- uiautomator2的版本号(`pip show uiautomator2`)
- 手机截图
- 相关日志(Python控制台错误信息, adb logcat完整信息, atxagent.log日志)
- 最好能附上可能复现问题的代码。
