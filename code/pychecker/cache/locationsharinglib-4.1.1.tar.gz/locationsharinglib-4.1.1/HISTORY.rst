.. :changelog:

History
-------

0.0.1 (24-12-2017)
---------------------

* First code creation


4.0.0 (05-03-2019)
------------------

* Removed authentication mechanism and made the service expect an authenticated pickled requests session


4.0.1 (06-03-2019)
------------------

* Removed wrongly placed files in the root of the virtual environment


4.0.2 (07-07-2019)
------------------

* Fixes issue when the battery level is not reported by specific brands of mobiles


4.1.0 (01-09-2019)
------------------

* Implemented support for text based cookies compatible with curl and wget that can be retrieved from addons from the browser.


4.1.1 (22-04-2020)
------------------

* Updated endpoint to rpc from preview and updated dependencies.
