# -*- coding: utf-8 -*-


class UnvalidEncodingAESKey(Exception):
    pass


class AppIdValidationError(Exception):
    pass


class InvalidSignature(Exception):
    pass
