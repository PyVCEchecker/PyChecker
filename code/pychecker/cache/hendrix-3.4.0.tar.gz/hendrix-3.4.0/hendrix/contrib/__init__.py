class SettingsError(Exception):
    "Because we don't to inherit ImproperlyConfigured..."
    pass
