pymemcache.test.test\_integration module
========================================

.. automodule:: pymemcache.test.test_integration
   :members:
   :undoc-members:
   :show-inheritance:
