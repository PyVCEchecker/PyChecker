pymemcache.client.rendezvous module
===================================

.. automodule:: pymemcache.client.rendezvous
   :members:
   :undoc-members:
   :show-inheritance:
