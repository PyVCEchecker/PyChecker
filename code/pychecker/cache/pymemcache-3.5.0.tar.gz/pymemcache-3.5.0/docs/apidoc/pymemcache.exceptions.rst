pymemcache.exceptions module
============================

.. automodule:: pymemcache.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
