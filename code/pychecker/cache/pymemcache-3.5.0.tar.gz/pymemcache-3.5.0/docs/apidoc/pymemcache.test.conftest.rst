pymemcache.test.conftest module
===============================

.. automodule:: pymemcache.test.conftest
   :members:
   :undoc-members:
   :show-inheritance:
