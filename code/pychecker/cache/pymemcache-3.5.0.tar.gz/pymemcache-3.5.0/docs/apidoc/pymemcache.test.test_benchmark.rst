pymemcache.test.test\_benchmark module
======================================

.. automodule:: pymemcache.test.test_benchmark
   :members:
   :undoc-members:
   :show-inheritance:
