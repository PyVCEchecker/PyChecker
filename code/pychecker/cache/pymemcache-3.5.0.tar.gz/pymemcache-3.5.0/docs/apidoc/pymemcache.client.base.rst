pymemcache.client.base module
=============================

.. automodule:: pymemcache.client.base
   :members:
   :undoc-members:
   :show-inheritance:
