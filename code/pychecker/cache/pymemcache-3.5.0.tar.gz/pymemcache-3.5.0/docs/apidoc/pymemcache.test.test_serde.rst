pymemcache.test.test\_serde module
==================================

.. automodule:: pymemcache.test.test_serde
   :members:
   :undoc-members:
   :show-inheritance:
