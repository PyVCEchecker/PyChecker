from . import key
from .readchar import readchar, readkey

__all__ = [readchar, readkey, key]
