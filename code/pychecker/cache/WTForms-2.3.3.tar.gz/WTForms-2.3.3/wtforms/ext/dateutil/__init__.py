import warnings

warnings.warn(
    "'wtforms.ext.dateutil' will be removed in WTForms 3.0.",
    DeprecationWarning,
)
