import warnings

warnings.warn(
    "'wtforms.ext.sqlalchemy' will be removed in WTForms 3.0. Use"
    " WTForms-SQLAlchemy https://github.com/wtforms/wtforms-sqlalchemy"
    " or WTForms-Alchemy https://github.com/kvesteri/wtforms-alchemy"
    " instead.",
    DeprecationWarning,
)
