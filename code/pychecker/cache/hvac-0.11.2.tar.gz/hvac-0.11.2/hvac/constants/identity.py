#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Constants related to the Identity secrets engine."""

ALLOWED_GROUP_TYPES = [
    "internal",
    "external",
]
