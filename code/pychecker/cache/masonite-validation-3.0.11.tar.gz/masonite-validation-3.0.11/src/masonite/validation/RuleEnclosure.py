class RuleEnclosure:
    pass
