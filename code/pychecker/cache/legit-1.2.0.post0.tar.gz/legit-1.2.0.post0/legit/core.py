# -*- coding: utf-8 -*-

"""
legit.core
~~~~~~~~~~

This module provides the basic functionality of legit.
"""

from . import bootstrap

del bootstrap

__version__ = "1.2.0post0"
__author__ = "Kenneth Reitz"
__license__ = "BSD"
