# For the benefit of TestGlobalObject
class ImportableClass(object):
    pass
