def test_interfaces():
    # improve coverage checks for interfaces.py
    from colander import interfaces  # noqa: F401
