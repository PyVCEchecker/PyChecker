sphinx-autobuild
================

This project's documentation is fully contained in the README file.

This Sphinx documentation exists to provide quick-and-easy trial grounds for changes to this project.
