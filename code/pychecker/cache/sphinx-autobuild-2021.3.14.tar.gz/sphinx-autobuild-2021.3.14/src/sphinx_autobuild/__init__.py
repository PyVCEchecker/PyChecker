"""Rebuild Sphinx documentation on changes, with live-reload in the browser."""

__version__ = "2021.03.14"
__url__ = "https://github.com/GaretJax/sphinx-autobuild"
