"""Entrypoint for `python -m sphinx_autobuild`."""
from .cli import main

if __name__ == "__main__":
    main()
