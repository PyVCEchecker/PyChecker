# -*- coding: utf-8 -*-
"""Testing module containing the tests
for collective.dexteritytextindexer.
"""
