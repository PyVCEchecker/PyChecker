---
kernelspec:
  display_name: SageMath 9.2
  language: sage
  name: sagemath
---

```{code-cell} ipython3
print("Hello world")
```
