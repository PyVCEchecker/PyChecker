---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
---

```python
1 + 1
```

A markdown cell
And below, the cell for function f has non trivial cell metadata. And the next cell as well.

```python attributes={"classes": [], "id": "", "n": "10"}
def f(x):
    return x
```

```python attributes={"classes": [], "id": "", "n": "10"}
f(5)
```

More text

```python
2 + 2
```
