---
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

```{raw-cell}

---
title: "Quick test"
output:
  ioslides_presentation:
    widescreen: true
    smaller: true
editor_options:
     chunk_output_type console
---
```

```{code-cell} ipython3
1+2+3
```

```{code-cell} ipython3

```
