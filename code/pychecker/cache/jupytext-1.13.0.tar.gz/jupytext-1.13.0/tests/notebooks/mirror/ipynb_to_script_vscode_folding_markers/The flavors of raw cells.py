# ---
# jupyter:
#   jupytext:
#     cell_markers: region,endregion
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# region raw_mimetype="text/latex" active=""
# $1+1$
# endregion

# region raw_mimetype="text/restructuredtext" active=""
# :math:`1+1`
# endregion

# region raw_mimetype="text/html" active=""
# <b>Bold text<b>
# endregion

# region raw_mimetype="text/markdown" active=""
# **Bold text**
# endregion

# region raw_mimetype="text/x-python" active=""
# 1 + 1
# endregion

# region active=""
# Not formatted
# endregion
