---
title: "Quick test"
output:
  ioslides_presentation:
    widescreen: true
    smaller: true
editor_options:
     chunk_output_type console
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
---

```python
1+2+3
```

```python

```
