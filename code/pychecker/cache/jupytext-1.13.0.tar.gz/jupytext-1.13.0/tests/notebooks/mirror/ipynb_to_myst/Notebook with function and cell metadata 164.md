---
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

```{code-cell} ipython3
1 + 1
```

A markdown cell
And below, the cell for function f has non trivial cell metadata. And the next cell as well.

```{code-cell} ipython3
---
attributes:
  classes: []
  id: ''
  n: '10'
---
def f(x):
    return x
```

```{code-cell} ipython3
---
attributes:
  classes: []
  id: ''
  n: '10'
---
f(5)
```

More text

```{code-cell} ipython3
2 + 2
```
