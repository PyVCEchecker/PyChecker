---
jupyter:
  kernelspec:
    display_name: Octave
    language: octave
    name: octave
---

A markdown cell

```octave
1 + 1
```

```octave
% a code cell with comments
2 + 2
```

```octave
% a simple plot
x = -10:0.1:10;
plot (x, sin (x));
```

```octave
%plot -w 800
% a simple plot with a magic instruction
x = -10:0.1:10;
plot (x, sin (x));
```

And to finish with, a Python cell

```python
a = 1
```

```python
a + 1
```
