# This is a comment

cars

plot(cars)
