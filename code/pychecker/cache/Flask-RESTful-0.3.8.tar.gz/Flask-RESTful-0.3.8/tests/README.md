# Running the tests

Go to main directory and type:

    python2 setup.py test
