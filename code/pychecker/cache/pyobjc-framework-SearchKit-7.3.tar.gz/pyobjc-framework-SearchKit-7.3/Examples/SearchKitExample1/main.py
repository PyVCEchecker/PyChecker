import AppController  # noqa: F401

# Uncomment the next two lines to make
# PyObjC more verbose, which helps during
# debugging.
from PyObjCTools import AppHelper


AppHelper.runEventLoop()
