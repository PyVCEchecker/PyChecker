# -*- coding: utf-8 -*-

"""
See setup.cfg for packaging settings
"""

from setuptools import setup
setup()
