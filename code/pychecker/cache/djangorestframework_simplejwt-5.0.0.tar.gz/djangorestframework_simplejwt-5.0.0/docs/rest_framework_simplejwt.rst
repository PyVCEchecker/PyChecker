rest\_framework\_simplejwt package
==================================

Submodules
----------

rest\_framework\_simplejwt.authentication module
------------------------------------------------

.. automodule:: rest_framework_simplejwt.authentication
    :members:
    :undoc-members:
    :show-inheritance:

rest\_framework\_simplejwt.models module
----------------------------------------

.. automodule:: rest_framework_simplejwt.models
    :members:
    :undoc-members:
    :show-inheritance:

rest\_framework\_simplejwt.serializers module
---------------------------------------------

.. automodule:: rest_framework_simplejwt.serializers
    :members:
    :undoc-members:
    :show-inheritance:

rest\_framework\_simplejwt.tokens module
----------------------------------------

.. automodule:: rest_framework_simplejwt.tokens
    :members:
    :undoc-members:
    :show-inheritance:

rest\_framework\_simplejwt.utils module
---------------------------------------

.. automodule:: rest_framework_simplejwt.utils
    :members:
    :undoc-members:
    :show-inheritance:

rest\_framework\_simplejwt.views module
---------------------------------------

.. automodule:: rest_framework_simplejwt.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: rest_framework_simplejwt
    :members:
    :undoc-members:
    :show-inheritance:
