For information about creating a cmd2 plugin, see template/README.md
