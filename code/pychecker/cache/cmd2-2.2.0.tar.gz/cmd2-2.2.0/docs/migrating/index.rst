Migrating From cmd
==================

.. toctree::
   :maxdepth: 1
   :hidden:

   why
   incompatibilities
   minimum
   next_steps


.. include:: summary.rst
