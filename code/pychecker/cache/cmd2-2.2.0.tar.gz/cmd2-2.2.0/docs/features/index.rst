Features
========

.. toctree::
   :maxdepth: 1

   argument_processing
   builtin_commands
   clipboard
   commands
   completion
   disable_commands
   embedded_python_shells
   generating_output
   help
   history
   hooks
   initialization
   misc
   modular_commands
   multiline_commands
   os
   packaging
   plugins
   prompt
   redirection
   scripting
   settings
   shortcuts_aliases_macros
   startup_commands
   table_creation
   transcripts
