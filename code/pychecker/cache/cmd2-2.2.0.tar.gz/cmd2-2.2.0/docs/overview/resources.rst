Resources
=========

.. _cmd: https://docs.python.org/3/library/cmd.html
.. _`cmd2 project page`: https://github.com/python-cmd2/cmd2
.. _`project bug tracker`: https://github.com/python-cmd2/cmd2/issues

Project related links and other resources:

* cmd_
* `cmd2 project page`_
* `project bug tracker`_
* PyOhio 2019: `slides <https://github.com/python-cmd2/talks/blob/master/PyOhio_2019/cmd2-PyOhio_2019.pdf>`_, `video <https://www.youtube.com/watch?v=pebeWrTqIIw>`_, `examples <https://github.com/python-cmd2/talks/tree/master/PyOhio_2019/examples>`_
