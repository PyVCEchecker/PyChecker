Getting Started
===============

.. toctree::
   :maxdepth: 1
   :hidden:

   installation
   ../examples/first_app
   integrating
   alternatives
   resources


.. include:: summary.rst
