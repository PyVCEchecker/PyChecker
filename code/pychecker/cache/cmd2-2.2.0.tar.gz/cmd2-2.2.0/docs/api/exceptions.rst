cmd2.exceptions
===============

Custom cmd2 exceptions


.. autoclass:: cmd2.exceptions.SkipPostcommandHooks
    :members:

.. autoclass:: cmd2.exceptions.Cmd2ArgparseError
    :members:

.. autoclass:: cmd2.exceptions.CommandSetRegistrationError
    :members:

.. autoclass:: cmd2.exceptions.CompletionError
    :members:

.. autoclass:: cmd2.exceptions.PassThroughException
    :members:
