cmd2_ext_test
=============

External Test Plugin


.. autoclass:: cmd2_ext_test.ExternalTestMixin
    :members:

