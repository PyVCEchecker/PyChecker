cmd2.argparse_custom
====================

.. automodule:: cmd2.argparse_custom
    :members:


Added Accessor Methods
----------------------
.. autofunction:: _action_get_choices_callable

.. autofunction:: _action_set_choices_provider

.. autofunction:: _action_set_completer

.. autofunction:: _action_get_descriptive_header

.. autofunction:: _action_set_descriptive_header

.. autofunction:: _action_get_nargs_range

.. autofunction:: _action_set_nargs_range

.. autofunction:: _action_get_suppress_tab_hint

.. autofunction:: _action_set_suppress_tab_hint

.. autofunction:: _ArgumentParser_get_ap_completer_type

.. autofunction:: _ArgumentParser_set_ap_completer_type


Subcommand Removal
------------------
.. autofunction:: _SubParsersAction_remove_parser
