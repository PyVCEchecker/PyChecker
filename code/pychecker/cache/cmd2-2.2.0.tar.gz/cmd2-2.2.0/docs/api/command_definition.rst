cmd2.command_definition
=======================

.. automodule:: cmd2.command_definition
    :members:
