cmd2.decorators
===============

.. automodule:: cmd2.decorators
    :members:
