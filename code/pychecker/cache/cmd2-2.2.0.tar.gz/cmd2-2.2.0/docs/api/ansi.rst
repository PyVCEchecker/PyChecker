cmd2.ansi
=========

.. automodule:: cmd2.ansi
    :members:
