# flake8: noqa F821
out = dir(app)
out.sort()
print(out)
