#!/usr/bin/env python
# coding=utf-8
"""
Example demonstrating what happens when a Python script raises an exception
"""
1 + 'blue'
