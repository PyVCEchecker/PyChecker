# Authors

## Maintainer

Spyder Development Team ([Spyder-IDE](http://github.com/spyder-ide))


## Main Authors

* Colin Duquesnoy ([@ColinDuquesnoy](http://github.com/ColinDuquesnoy))

* [The QtPy Contributors](https://github.com/spyder-ide/qtpy/graphs/contributors)


## Contributors

* Thomas Robitaille ([@astrofrog](http://www.github.com/astrofrog))
