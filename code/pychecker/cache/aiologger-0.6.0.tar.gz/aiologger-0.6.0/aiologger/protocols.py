import asyncio


class AiologgerProtocol(asyncio.Protocol):
    async def _drain_helper(self):
        pass
