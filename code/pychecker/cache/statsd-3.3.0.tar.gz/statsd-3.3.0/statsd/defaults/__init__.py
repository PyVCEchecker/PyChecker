HOST = 'localhost'
PORT = 8125
IPV6 = False
PREFIX = None
MAXUDPSIZE = 512
