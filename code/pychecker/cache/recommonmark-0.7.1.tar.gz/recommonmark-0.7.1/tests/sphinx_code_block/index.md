Header
======

A paragraph
```
def f():
    pass
```
Another paragraph


