link
====

The link file.

## Section 1

Autosectionlabel will generate a link for this heading at `link:Section 1`.
