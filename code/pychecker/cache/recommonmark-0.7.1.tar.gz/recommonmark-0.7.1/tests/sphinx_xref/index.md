Header
======

A paragraph [link](link) and [absolute link](/link). An [external link](http://www.google.com).

A [ref with spaces][].


[ref with spaces]: <link:Section 1>
