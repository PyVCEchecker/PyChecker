Microsoft Azure CLI 'keyvault' Command Module
=============================================

This package is for the 'keyvault' module.
i.e. 'az keyvault'


