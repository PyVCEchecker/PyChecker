""" Run the JWT tests """

from test import jwt_spec
jwt_spec.setup()
