# -*- coding: utf-8 -*-
"""Templates package for the application."""
