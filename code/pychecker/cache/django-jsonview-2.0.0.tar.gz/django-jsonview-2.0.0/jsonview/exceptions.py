class BadRequest(Exception):
    pass
