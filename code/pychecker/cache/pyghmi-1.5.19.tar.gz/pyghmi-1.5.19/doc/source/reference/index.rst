API reference 
=============

Contents:

.. toctree::
   :maxdepth: 2

.. autoclass:: pyghmi.ipmi.command.Command
