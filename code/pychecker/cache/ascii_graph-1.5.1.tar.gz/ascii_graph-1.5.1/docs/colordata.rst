Package ascii_graph.colordata
=============================

.. automodule:: ascii_graph.colordata
    :members:
    :undoc-members:
    :show-inheritance:

