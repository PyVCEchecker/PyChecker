Contents
========

.. toctree::
   :maxdepth: 4

   ascii_graph
   colordata
   colors
   examples
   changelog

.. include:: ../README.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

