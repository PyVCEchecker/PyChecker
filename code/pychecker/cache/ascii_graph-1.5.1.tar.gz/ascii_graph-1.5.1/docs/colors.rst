Package ascii_graph.colors
==========================

List of colors available in ascii_graph.colors
----------------------------------------------

.. literalinclude:: ../ascii_graph/colors.py
   :language: python

