.. include:: ../src/zope/i18n/testmessagecatalog.rst
