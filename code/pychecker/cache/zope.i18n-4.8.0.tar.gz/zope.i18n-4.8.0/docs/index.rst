
.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   api
   testing
   changelog

====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
