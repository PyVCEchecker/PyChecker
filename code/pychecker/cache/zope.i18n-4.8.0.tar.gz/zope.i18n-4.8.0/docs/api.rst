=========================
 zope.i18n API Reference
=========================

.. testsetup::

   from zope.i18n import interpolate
   from zope.i18n import translate

zope.i18n
=========

.. automodule:: zope.i18n

zope.i18n.config
================

.. automodule:: zope.i18n.config


zope.i18n.compile
=================

.. automodule:: zope.i18n.compile

zope.i18n.format
================

.. automodule:: zope.i18n.format

zope.i18n.gettextmessagecatalog
===============================

.. automodule:: zope.i18n.gettextmessagecatalog

zope.i18n.interfaces
====================

.. automodule:: zope.i18n.interfaces

.. automodule:: zope.i18n.interfaces.locales
