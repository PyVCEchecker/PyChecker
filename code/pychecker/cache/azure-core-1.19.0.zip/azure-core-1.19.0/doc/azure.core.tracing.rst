azure.core.tracing
==================

.. automodule:: azure.core.tracing
   :members:
   :undoc-members:
   :inherited-members:

Submodules
----------

azure.core.tracing.common
-------------------------

.. automodule:: azure.core.tracing.common
   :members:
   :undoc-members:
   :inherited-members:

azure.core.tracing.decorator
----------------------------

.. automodule:: azure.core.tracing.decorator
   :members:
   :undoc-members:
   :inherited-members:

azure.core.tracing.decorator\_async
-----------------------------------

.. automodule:: azure.core.tracing.decorator_async
   :members:
   :undoc-members:
   :inherited-members:

