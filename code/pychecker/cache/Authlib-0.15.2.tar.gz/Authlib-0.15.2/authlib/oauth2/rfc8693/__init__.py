# -*- coding: utf-8 -*-
"""
    authlib.oauth2.rfc8693
    ~~~~~~~~~~~~~~~~~~~~~~

    This module represents an implementation of
    OAuth 2.0 Token Exchange.

    https://tools.ietf.org/html/rfc8693
"""
