..
    This file is part of Flask-CeleryExt
    Copyright (C) 2015, 2016 CERN.

    Flask-CeleryExt is free software; you can redistribute it and/or modify it
    under the terms of the Revised BSD License; see LICENSE file for more
    details.

.. include:: ../README.rst
   :end-before: Documentation

Usage
=====

.. automodule:: flask_celeryext

.. include:: ../CHANGES.rst

.. include:: ../CONTRIBUTING.rst

License
=======

.. include:: ../LICENSE

.. include:: ../AUTHORS.rst
