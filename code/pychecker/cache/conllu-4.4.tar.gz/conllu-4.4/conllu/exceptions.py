class ParseException(Exception):
    pass
