"""Export tldextract's public interface."""

from .tldextract import extract, TLDExtract

from ._version import version as __version__
