'''py.test standard config file.'''

collect_ignore = ('setup.py',)
