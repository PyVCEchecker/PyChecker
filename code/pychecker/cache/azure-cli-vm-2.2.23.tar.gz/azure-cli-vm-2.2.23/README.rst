Microsoft Azure CLI 'vm' Command Module
=======================================

This package is for the 'vm' module.
i.e. 'az vm'


