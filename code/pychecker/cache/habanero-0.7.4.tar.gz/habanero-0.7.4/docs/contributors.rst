.. _contributors:

Contributors
============

* `Scott Chamberlain <https://github.com/sckott>`_
* `Julien Maupetit <https://github.com/jmaupetit>`_
* `Steve Peak <https://github.com/stevepeak>`_
* `Colin Talbert <https://github.com/talbertc-usgs>`_
* `Daniel Himmelstein <https://github.com/dhimmel>`_
* `Kyle Niemeyer <https://github.com/kyleniemeyer>`_
* `ioverka <https://github.com/ioverka>`_
