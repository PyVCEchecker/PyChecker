.. _exceptions:

Exceptions
==========

.. py:module:: habanero

.. autoclass:: RequestError
