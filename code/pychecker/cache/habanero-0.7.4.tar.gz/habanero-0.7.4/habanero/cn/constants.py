cn_base_url = "https://doi.org"
