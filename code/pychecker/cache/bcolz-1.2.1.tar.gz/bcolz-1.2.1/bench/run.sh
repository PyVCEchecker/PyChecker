export PYTHONPATH=..
python concat.py bcolz
python expression.py
python fromiter.py
python getitem.py
python iterator.py
python iter.py
