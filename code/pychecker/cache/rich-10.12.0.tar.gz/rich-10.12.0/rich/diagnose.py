if __name__ == "__main__":  # pragma: no cover
    from rich.console import Console
    from rich import inspect

    console = Console()
    inspect(console)
