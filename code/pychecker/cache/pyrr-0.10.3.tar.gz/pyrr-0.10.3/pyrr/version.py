# -*- coding: utf-8 -*-
# the version of software
# this is used by the setup.py script
__version__ = '0.10.3'

