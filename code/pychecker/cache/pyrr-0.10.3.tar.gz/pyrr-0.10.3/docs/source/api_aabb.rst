.. _api_aabb:

Axis Aligned Bounding Box
*************************

AABB
====

.. automodule:: pyrr.aabb
    :members:
    :undoc-members:

.. _api_aambb:

AAMBB
=====

.. automodule:: pyrr.aambb
    :members:
    :undoc-members:
