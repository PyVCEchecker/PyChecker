.. _api_geometry:

Geometry
********

.. automodule:: pyrr.geometry
    :members:
    :undoc-members:
