.. _api_rectangle:

Rectangle
*********

.. automodule:: pyrr.rectangle
    :members:
    :undoc-members:
