.. _oo_api_vector:

Vectors
*******

Vector3
=======

.. automodule:: pyrr.objects.vector3
    :members:
    :undoc-members:

Vector4
=======

.. automodule:: pyrr.objects.vector4
    :members:
    :undoc-members:
