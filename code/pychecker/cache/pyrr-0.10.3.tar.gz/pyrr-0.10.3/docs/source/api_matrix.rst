.. _api_matrix:

Matrix functions
****************

.. _api_matrix33:

Matrix33
========

.. automodule:: pyrr.matrix33
    :members:
    :undoc-members:

.. _api_matrix44:

Matrix44
========

.. automodule:: pyrr.matrix44
    :members:
    :undoc-members:
