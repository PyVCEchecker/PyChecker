.. _oo_api_matrix:

Matrices
********

Matrix33
========

.. automodule:: pyrr.objects.matrix33
    :members:
    :undoc-members:

Matrix44
========

.. automodule:: pyrr.objects.matrix44
    :members:
    :undoc-members:
