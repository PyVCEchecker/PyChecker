.. _api_integer:

Integer
*******

.. automodule:: pyrr.integer
    :members:
    :undoc-members:
