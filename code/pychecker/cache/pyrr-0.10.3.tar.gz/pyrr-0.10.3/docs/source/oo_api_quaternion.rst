.. _oo_api_quaternion:

Quaternion
**********

Quaternion
==========

.. automodule:: pyrr.objects.quaternion
    :members:
    :undoc-members:
