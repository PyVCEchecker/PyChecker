=============
project purge
=============

Clean resources associated with a specific project.

Block Storage v1, v2; Compute v2; Image v1, v2


.. autoprogram-cliff:: openstack.common
   :command: project purge
