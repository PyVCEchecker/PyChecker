==================
network qos policy
==================

A **Network QoS policy** groups a number of Network QoS rules, applied to a
network or a port.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: network qos policy *
