=========================
federation domain/project
=========================

Identity v3

.. autoprogram-cliff:: openstack.identity.v3
   :command: federation domain *

.. autoprogram-cliff:: openstack.identity.v3
   :command: federation project *
