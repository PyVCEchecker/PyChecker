=================
volume attachment
=================

Block Storage v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume attachment *
