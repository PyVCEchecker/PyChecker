manila
------

.. autoprogram-cliff:: openstack.share.v2
