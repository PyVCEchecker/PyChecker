======
limits
======

The Compute and Block Storage APIs have resource usage limits.

Compute v2, Block Storage v1


.. autoprogram-cliff:: openstack.common
   :command: limits *
