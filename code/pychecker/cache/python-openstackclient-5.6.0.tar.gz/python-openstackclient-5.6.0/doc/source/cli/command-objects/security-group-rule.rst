===================
security group rule
===================

A **security group rule** specifies the network access rules for servers
and other resources on the network.

Compute v2, Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: security group rule *
