================
registered limit
================

Identity v3

Registered limits are used to define default limits for resources within a
deployment.

.. autoprogram-cliff:: openstack.identity.v3
   :command: registered limit *
