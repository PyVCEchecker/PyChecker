==================
network meter rule
==================

A **meter rule** sets the rule for
a meter to measure traffic for a specific IP range.
The following uses **meter** and requires the L3
metering extension.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: network meter rule *
