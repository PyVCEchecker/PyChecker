==========
hypervisor
==========

Compute v2

.. NOTE(efried): have to list these out one by one; 'hypervisor *' pulls in
                 ... stats.

.. autoprogram-cliff:: openstack.compute.v2
   :command: hypervisor list

.. autoprogram-cliff:: openstack.compute.v2
   :command: hypervisor show
