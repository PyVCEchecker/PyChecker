==================
role (Identity v3)
==================

.. autoprogram-cliff:: openstack.identity.v3
   :command: role *
