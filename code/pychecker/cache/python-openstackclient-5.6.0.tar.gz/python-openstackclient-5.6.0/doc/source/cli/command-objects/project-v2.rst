=====================
project (Identity v2)
=====================

.. autoprogram-cliff:: openstack.identity.v2
   :command: project *
