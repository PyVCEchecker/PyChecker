=====================
service (Identity v3)
=====================

.. autoprogram-cliff:: openstack.identity.v3
   :command: service create

.. autoprogram-cliff:: openstack.identity.v3
   :command: service delete

.. autoprogram-cliff:: openstack.identity.v3
   :command: service list

.. autoprogram-cliff:: openstack.identity.v3
   :command: service show

.. autoprogram-cliff:: openstack.identity.v3
   :command: service set
