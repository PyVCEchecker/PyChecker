======
module
======

Internal

Installed Python modules in the OSC process.

.. autoprogram-cliff:: openstack.cli
   :command: module *
