gnocchi
-------

.. autoprogram-cliff:: openstack.metric.v1
