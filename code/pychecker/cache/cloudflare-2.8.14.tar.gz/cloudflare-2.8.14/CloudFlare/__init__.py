""" Cloudflare v4 API"""
from __future__ import absolute_import

__version__ = '2.8.14'

from .cloudflare import CloudFlare

__all__ = ['CloudFlare']
