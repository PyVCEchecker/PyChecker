# -*- coding: utf-8 -*-
from authomatic import providers


class MozillaPersona(providers.AuthenticationProvider):
    pass
