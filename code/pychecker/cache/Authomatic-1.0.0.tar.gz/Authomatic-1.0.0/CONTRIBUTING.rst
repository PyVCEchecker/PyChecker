Contributions are welcome! 

Please read our `commit policy <https://github.com/authomatic/authomatic/wiki/Commit-Policy>`_ in order to save time for you and the maintainers.
