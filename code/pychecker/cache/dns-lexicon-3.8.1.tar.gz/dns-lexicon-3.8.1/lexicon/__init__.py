"""
lexicon - a DNS provider agnostic api to manipulate records.
"""
__author__ = "Jason Kulatunga"
