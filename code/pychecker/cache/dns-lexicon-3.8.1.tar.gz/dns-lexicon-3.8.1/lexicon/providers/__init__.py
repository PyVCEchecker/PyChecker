"""General configuration of lexicon.providers package"""
__author__ = "Jason Kulatunga"
