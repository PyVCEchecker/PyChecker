"""
Just a placeholder so _ext.js_progress can be used as the extension name in conf.py
"""