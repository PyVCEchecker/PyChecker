def test_md5(con):
    """Called by GitHub Actions with auth method md5.
    We just need to check that we can get a connection.
    """
    pass
