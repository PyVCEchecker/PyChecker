.. _deploy:

Deploying your project
======================

Deploying your project involves eggifying it and uploading the egg to Scrapyd via the `addversion.json <https://scrapyd.readthedocs.org/en/latest/api.html#addversion-json>`_ endpoint. You can do this manually, but the easiest way is to use the `scrapyd-deploy` tool provided by `scrapyd-client <https://github.com/scrapy/scrapyd-client>`_ which will do it all for you.
