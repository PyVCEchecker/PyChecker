=======
Scrapyd
=======

.. image:: https://secure.travis-ci.org/scrapy/scrapyd.png?branch=master
    :target: http://travis-ci.org/scrapy/scrapyd

.. image:: https://codecov.io/gh/scrapy/scrapyd/branch/master/graph/badge.svg
    :target: https://codecov.io/gh/scrapy/scrapyd

Scrapyd is a service for running `Scrapy`_ spiders.

It allows you to deploy your Scrapy projects and control their spiders using a
HTTP JSON API.

The documentation (including installation and usage) can be found at:
http://scrapyd.readthedocs.org/

.. _Scrapy: https://github.com/scrapy/scrapy
