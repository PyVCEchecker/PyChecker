aioamqp was originally created in early 2014 at Polyconseil.

AUTHORS are (and/or have been)::

    * Benoît Calvez
    * Thomas Recouvreux
    * Guillaume Gauvrit
    * Morgan Delahaye-Prat
    * Mathias Fröjdman
    * Dmitry Maslov
    * Matthias Urlichs
    * Rémi Cardona
    * Marco Mariani
    * David Honour
    * Igor `mastak`
    * Hans Lellelid
    * `iceboy-sjtu`
    * Sergio Medina Toledo
    * Alexander Gromyko
    * Nick Humrich
    * Pavel Kamaev
    * Mads Sejersen
    * Dave Shawley
    * Jacob Hagstedt P Suorra
    * Corey `notmeta`
    * Paul Wistrand
    * fullylegit
