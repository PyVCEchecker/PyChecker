aioamqp changelog
=================

Here you can see the full list of changes between each aioamqp release.

Version 0.2.0
-------------

 * Remove the `asyncio.Queue` and adds a callback parameter to basic_consume
 * Add a `on_error` callback when creating a channel or a connection


Version 0.1.1
-------------

 * Add `no_wait` and `timeout` parameters to `close` method

Version 0.1
-----------

 * First public preview release.
