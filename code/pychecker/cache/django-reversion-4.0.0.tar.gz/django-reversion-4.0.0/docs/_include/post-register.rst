.. Hint::
    Whenever you register a model with django-reversion, run :ref:`createinitialrevisions`.
