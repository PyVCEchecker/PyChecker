If ``True``, the revision block will be wrapped in a ``transaction.atomic()``.
