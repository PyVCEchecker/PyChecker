If ``True``, versions will not be saved when a model's ``save()`` method is called. This allows version control to be switched off for a given revision block.
