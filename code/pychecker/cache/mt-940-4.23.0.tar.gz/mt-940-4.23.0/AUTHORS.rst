=======
Credits
=======

Development Lead
----------------

* Rick van Hattem (Wolph) <wolph@wol.ph>

Contributors
------------

* Ben Konrath (benkonrath)

Why not join the club?

A more up to date list can be found here: 
https://github.com/WoLpH/mt940/graphs/contributors
