"""Mock module for Sphinx autodoc."""


def dtype(_):
    return NotImplemented
