.. default-role:: py:obj

.. include:: ../README.rst

.. include:: ../CONTRIBUTING.rst

.. default-role::

API Documentation
=================

.. automodule:: soundfile
   :members:
   :undoc-members:

Index
=====

* :ref:`genindex`
