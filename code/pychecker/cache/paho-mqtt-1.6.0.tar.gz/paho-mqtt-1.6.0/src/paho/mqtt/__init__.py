__version__ = "1.6.0"


class MQTTException(Exception):
    pass
