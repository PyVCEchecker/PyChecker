API Reference
=============

.. toctree::
   :maxdepth: 2

   lang_doc_corpus
   datasets_resources
   preprocessing
   extract
   text_stats
   similarity
   representations
   tm
   io
   viz
   augmentation
   misc
