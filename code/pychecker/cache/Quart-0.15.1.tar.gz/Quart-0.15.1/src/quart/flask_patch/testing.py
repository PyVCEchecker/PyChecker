from __future__ import annotations

from quart.testing import QuartClient

FlaskClient = QuartClient

__all__ = ("FlaskClient",)
