from __future__ import annotations

from quart.cli import (  # noqa: F401
    AppGroup,
    QuartGroup,
    run_command,
    ScriptInfo,
    shell_command,
    with_appcontext,
)

FlaskGroup = QuartGroup
