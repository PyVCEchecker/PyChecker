from __future__ import annotations

FOO = "bar"
BOB = "jeff"
