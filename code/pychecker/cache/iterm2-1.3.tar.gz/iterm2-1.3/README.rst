iTerm2
------

iTerm2 3.1 has a new scripting API. It uses Google Protocol Buffers to allow programs written in any language to communicate with iTerm2. Most users will prefer an interface in a high-level language. This library offers a Python interface to iTerm2. Please note that Prefs > Advanced > Enable websocket API server must be enabled in iTerm2 for this library to work.
