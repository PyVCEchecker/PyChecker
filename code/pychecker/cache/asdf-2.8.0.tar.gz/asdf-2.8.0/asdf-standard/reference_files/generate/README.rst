To regenerate the reference files:

    ./generate.py $version

where $version is the version of the ASDF standard to generate.

The resulting reference files should be inspected for correctness by
hand and then committed to the git repository.
