Who uses BibtexParser?
======================

If your project uses BibtexParser, you can ask for the addition of a link in this list.

* https://pypi.org/project/vitae/
* https://github.com/pubs/pubs
* http://timotheepoisot.fr/2013/11/10/shared-bibtex-file-markdown/
* https://github.com/Phyks/BMC
* http://aurelien.naldi.info/research/publications.html
* http://robot.kut.ac.kr/publications
* https://git.atelo.org/etlapale/bibgen
* https://onmenwhostareongraphs.wordpress.com/2015/06/09/graph-display-software-for-author-relationships-with-bibtex-files/
* https://github.com/vitorfs/parsifal
