# -*- coding: utf-8 -*-
from __future__ import absolute_import

from .storage import load_dict as load
from .compile import convert_to_pymorphy2
from .wrapper import Dictionary
