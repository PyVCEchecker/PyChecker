from cupyx.scipy.stats.distributions import entropy  # NOQA
