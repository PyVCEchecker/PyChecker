from cupy.cuda.memory_hooks import debug_print  # NOQA
from cupy.cuda.memory_hooks import line_profile  # NOQA

# import class and function
from cupy.cuda.memory_hooks.debug_print import DebugPrintHook  # NOQA
from cupy.cuda.memory_hooks.line_profile import LineProfileHook  # NOQA
