These files are copied from CUDA Toolkit Distribution and redistributed under the following license:

https://docs.nvidia.com/cuda/archive/9.2/eula/#nvidia-cuda-toolkit-license-agreement
