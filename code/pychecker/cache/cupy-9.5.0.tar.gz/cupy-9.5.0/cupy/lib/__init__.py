from cupy.lib import stride_tricks  # NOQA
