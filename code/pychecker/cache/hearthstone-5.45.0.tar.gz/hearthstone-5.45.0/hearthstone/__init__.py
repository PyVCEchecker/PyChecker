import pkg_resources


__version__ = pkg_resources.require("hearthstone")[0].version
