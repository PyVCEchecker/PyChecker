class ConfigTransform(object):
    def transform(self, config):
        """
        :param config:
        :type config: yowsup.config.base.config.Config
        :return: dict
        :rtype:
        """

    def reverse(self, data):
        """
        :param data:
        :type data:
        :return:
        :rtype: yowsup.config.base.config.Config
        """
