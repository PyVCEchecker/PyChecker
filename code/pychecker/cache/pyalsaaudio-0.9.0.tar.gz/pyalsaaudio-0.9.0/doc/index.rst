.. alsaaudio documentation documentation master file, created by
   sphinx-quickstart on Thu Mar 30 23:52:21 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

alsaaudio documentation
===================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   pyalsaaudio
   terminology
   libalsaaudio

Download
========

* `Download from pypi <https://pypi.python.org/pypi/pyalsaaudio>`_
  
      
Github
======

* `Repository <https://github.com/larsimmisch/pyalsaaudio/>`_
* `Bug tracker <https://github.com/larsimmisch/pyalsaaudio/issues>`_

 
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

    
  
