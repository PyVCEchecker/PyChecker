OpenTelemetry Python API
============================================================================

|pypi|

.. |pypi| image:: https://badge.fury.io/py/opentelemetry-api.svg
   :target: https://pypi.org/project/opentelemetry-api/

Installation
------------

::

    pip install opentelemetry-api

References
----------

* `OpenTelemetry Project <https://opentelemetry.io/>`_
