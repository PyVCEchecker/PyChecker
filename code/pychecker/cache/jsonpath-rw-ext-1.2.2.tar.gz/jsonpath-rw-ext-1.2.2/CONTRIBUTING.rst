If you would like to contribute to the development, just send github pull requests.
