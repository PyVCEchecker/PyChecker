"""The pyang library for parsing, validating, and converting YANG modules"""

__version__ = '2.5.0'
__date__ = '2021-06-21'
