This plugin adds an "Python Address Label" action to "Adress" properties in
the AddressBook application.

To use this plugin you have to build and then install it.

::
   $ python setup.py py2app
   $ cp -r "dist/PyAddressLabel.bundle" ~/"Library/Address Book Plugins"
