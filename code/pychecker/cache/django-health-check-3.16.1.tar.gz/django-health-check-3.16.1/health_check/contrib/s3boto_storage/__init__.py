default_app_config = 'health_check.contrib.s3boto_storage.apps.HealthCheckConfig'
