default_app_config = 'health_check.contrib.celery_ping.apps.HealthCheckConfig'
