MUTATION_ERRORS_FLAG = "graphene_mutation_has_errors"
