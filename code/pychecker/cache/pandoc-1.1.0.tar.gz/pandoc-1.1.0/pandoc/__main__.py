
# Python 2.7 Standard Library
from __future__ import absolute_import
import json
import sys

# Pandoc
import pandoc


pandoc.main()

