"""
Command for loading and serving wsgi apps taken from PasteScript
"""
