__version__ = '21.1.0'

PROJECT_NAME = "galaxy-util"
PROJECT_OWNER = PROJECT_USERAME = "galaxyproject"
PROJECT_URL = "https://github.com/galaxyproject/galaxy"
PROJECT_AUTHOR = 'Galaxy Project and Community'
PROJECT_DESCRIPTION = 'Galaxy Generic Utilities'
PROJECT_EMAIL = 'galaxy-committers@lists.galaxyproject.org'
RAW_CONTENT_URL = "https://raw.github.com/{}/{}/master/".format(
    PROJECT_USERAME, PROJECT_NAME
)
