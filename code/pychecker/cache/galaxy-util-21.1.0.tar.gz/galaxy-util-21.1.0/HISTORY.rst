.. :changelog:

History
-------

.. to_doc

---------------------
21.1.0 (2021-03-19)
---------------------

* First release from the 21.01 branch of Galaxy.

---------------------
20.9.1 (2020-10-28)
---------------------


---------------------
20.9.0 (2020-10-15)
---------------------

* First release from the 20.09 branch of Galaxy.

---------------------
20.5.0 (2020-07-03)
---------------------

* First release from 20.05 branch of Galaxy.

---------------------
19.9.0 (2019-11-21)
---------------------

* Initial import from dev branch of Galaxy during 19.09 development cycle.
