
.. image:: https://badge.fury.io/py/galaxy-util.svg
   :target: https://pypi.org/project/galaxy-util/


Overview
--------

The Galaxy_ utilities module.

* Free software: Academic Free License version 3.0
* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
