BOOTSTRAP = (
    "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/"
    "font/bootstrap-icons.css"
)
FONT_AWESOME = "https://use.fontawesome.com/releases/v5.15.4/css/all.css"
