"""
A pytest plugin for testing and validating ipython notebooks
"""

from ._version import __version__
