version_info = (0, 9, 6)
__version__ = '.'.join(map(str, version_info[:3])) + ''.join(version_info[3:])
