# A simple package for testing with.
print(f"pkg1.__init__: {__name__}")
