This directory contains an example Python binding to the GraphQL
parser and AST library. It uses
[ctypesgen.py](https://github.com/davidjamesca/ctypesgen) to generate
the binding code automatically from the pure C API in
`../c`. `example.py` is a short program that uses this binding.
