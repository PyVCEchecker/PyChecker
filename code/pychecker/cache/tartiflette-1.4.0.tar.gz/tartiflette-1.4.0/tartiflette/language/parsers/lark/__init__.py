from .parser import parse_to_document

__all__ = ("parse_to_document",)
