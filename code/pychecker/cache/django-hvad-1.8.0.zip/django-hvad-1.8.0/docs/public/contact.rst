############################
Contact and support channels
############################

* Github: https://github.com/KristianOellegaard/django-hvad
