__version__ = '1.8.0'
VERSION = (1, 8, 0)
