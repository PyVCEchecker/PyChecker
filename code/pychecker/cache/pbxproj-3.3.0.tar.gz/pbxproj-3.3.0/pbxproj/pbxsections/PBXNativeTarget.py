from pbxproj.pbxsections.PBXGenericTarget import PBXGenericTarget


class PBXNativeTarget(PBXGenericTarget):
    pass
