.. include:: ../license.rst
