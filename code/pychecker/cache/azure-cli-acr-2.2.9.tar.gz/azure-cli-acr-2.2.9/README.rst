Microsoft Azure CLI 'acr' Command Module
========================================

This package is for the 'acr' module.
i.e. 'az acr'
