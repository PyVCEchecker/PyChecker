# -*- coding: utf-8 -*-

default_app_config = 'admin_interface.apps.AdminInterfaceConfig'
