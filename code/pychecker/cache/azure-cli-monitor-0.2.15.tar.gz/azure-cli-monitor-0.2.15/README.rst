Microsoft Azure CLI 'Monitor' Command Module
============================================

