# Tool to render all grammars found in some path

	python render_all_grammars.py

The script indicates how to proceed.
