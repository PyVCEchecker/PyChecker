# State machine language

This is a video tutorial that explains the implementation of [the StateMachine example](https://github.com/textX/textX/tree/master/examples/StateMachine).

---

See [the blog post about this language
implementation](http://www.igordejanovic.net/2016/05/06/implementing-martin-fowler-state-machine-dsl-in-textx.html).


<iframe width="560" height="315" src="https://www.youtube.com/embed/HI14jk0JIR0" frameborder="0" allowfullscreen></iframe>
