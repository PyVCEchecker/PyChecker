# Toy language compiler

A toy language compiler tutorial

---

[Windel Bouwman](http://www.windel.nl/) wrote an [excellent
tutorial](https://ppci.readthedocs.io/en/latest/howto/toy.html) for using textX
and [ppci](https://ppci.readthedocs.io/en/latest/) to write a
compiler for a simple language.



