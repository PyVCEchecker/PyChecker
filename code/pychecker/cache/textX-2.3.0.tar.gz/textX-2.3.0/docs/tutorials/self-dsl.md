# self-dsl

A tutorial site on creation of Domain-Specific Languages.

---

Pierre Bayerl is maintaining an [excellent tutorial
site](https://goto40.github.io/self-dsl/) on writing DSL for both Xtext and
textX. Check out his [tutorial for
textX](https://goto40.github.io/self-dsl/textx_intro/).
