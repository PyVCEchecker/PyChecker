This is a place for new development ideas.

Contributions are welcome. If you have new idea or would like to refine some of
the existing make a fork of the repo, do your changes and send me a pull
request.


