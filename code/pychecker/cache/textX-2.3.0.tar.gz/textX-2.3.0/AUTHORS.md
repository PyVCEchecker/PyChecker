textX - Meta-language for building Domain-Specific Languages (DSLs) in Python

# Developers

- Igor R. Dejanović (initial author and lead developer)<br>
  GitHub: https://github.com/igordejanovic/<br>
  email: igor DOT dejanovic AT gmail DOT com

- Pierre Bayerl<br>
  GitHub: https://github.com/goto40/


# Contributors

For the full information about contributions see
[here](https://github.com/textX/textX/graphs/contributors)

