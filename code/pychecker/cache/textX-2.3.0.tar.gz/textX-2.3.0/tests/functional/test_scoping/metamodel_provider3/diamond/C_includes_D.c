C:

import "D.a"

class C extends D {
    method c
}