C:
import "model_a2.a"
class C
obj c_a2:A2

