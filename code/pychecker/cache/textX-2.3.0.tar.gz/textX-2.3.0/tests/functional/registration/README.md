These tests are based on https://github.com/textX/textx-multi-metamodel-example
