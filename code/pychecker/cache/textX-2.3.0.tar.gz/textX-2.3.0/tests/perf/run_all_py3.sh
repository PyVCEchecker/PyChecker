#!/bin/bash
./run_memory.sh py3
./run_speed.sh py3
./callgraph.sh py3

