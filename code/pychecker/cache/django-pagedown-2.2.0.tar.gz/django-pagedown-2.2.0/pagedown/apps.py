from django.apps import AppConfig


class PagedownConfig(AppConfig):
    name = 'pagedown'
    verbose_name = 'Pagedown'
