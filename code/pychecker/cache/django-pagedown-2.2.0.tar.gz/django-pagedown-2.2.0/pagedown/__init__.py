VERSION = ('2', '2', '0')

default_app_config = 'pagedown.apps.PagedownConfig'
