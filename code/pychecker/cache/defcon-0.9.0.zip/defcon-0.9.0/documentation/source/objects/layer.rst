.. highlight:: python

=====
Layer
=====

Layer
^^^^^

.. module:: defcon
.. autoclass:: Layer
   :inherited-members:
   :members:
