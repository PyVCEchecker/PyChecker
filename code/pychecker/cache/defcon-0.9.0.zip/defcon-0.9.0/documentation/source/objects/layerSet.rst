.. highlight:: python

========
LayerSet
========

LayerSet
^^^^^^^^

.. module:: defcon
.. autoclass:: LayerSet
   :inherited-members:
   :members:
