To compile this documentation, use Sphinx. In the shell, move to the root source folder where `setup.py` file is, and enter the following:

    python setup.py build_sphinx

Alternatively, if the `make` command is available, you can move to the `documentation` folder where the `Makefile` is located, and run:

    make html

For more info about Sphinx:

    http://www.sphinx-doc.org/
