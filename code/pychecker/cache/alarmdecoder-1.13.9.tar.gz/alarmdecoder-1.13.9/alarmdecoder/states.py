class FireState:
    """
    Fire alarm status
    """
    NONE = 0
    ALARM = 1
    ACKNOWLEDGED = 2
