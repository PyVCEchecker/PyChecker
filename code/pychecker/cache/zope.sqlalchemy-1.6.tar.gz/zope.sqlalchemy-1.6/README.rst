|Build status|_

.. |Build status| image:: https://travis-ci.com/zopefoundation/zope.sqlalchemy.svg?branch=master
.. _Build status: https://travis-ci.com/zopefoundation/zope.sqlalchemy

See src/zope/sqlalchemy/README.rst
