"""
    python-creole exceptions
    ~~~~~~~~~~~~~~~~~~~~~~~~

    :copyleft: 2011 by python-creole team, see AUTHORS for more details.
    :license: GNU GPL v3 or above, see LICENSE for more details.
"""


class DocutilsImportError(ImportError):
    pass
