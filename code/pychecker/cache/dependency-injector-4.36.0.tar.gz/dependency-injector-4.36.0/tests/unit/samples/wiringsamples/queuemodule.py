# Hotfix, see: https://github.com/ets-labs/python-dependency-injector/issues/362
from queue import Queue


__all__ = ('Queue',)
