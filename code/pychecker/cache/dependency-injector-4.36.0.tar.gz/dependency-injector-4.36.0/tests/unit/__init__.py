"""Dependency injector unit tests."""
