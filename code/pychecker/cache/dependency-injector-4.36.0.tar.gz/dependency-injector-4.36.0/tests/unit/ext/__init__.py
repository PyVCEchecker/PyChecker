"""Dependency injector extension unit tests."""
