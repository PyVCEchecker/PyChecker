"""Dependency injector container unit tests."""
