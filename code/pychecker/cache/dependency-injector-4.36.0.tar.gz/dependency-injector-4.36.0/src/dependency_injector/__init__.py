"""Top-level package."""

__version__ = '4.36.0'
"""Version number.

:type: str
"""
