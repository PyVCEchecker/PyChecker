from ._codespell import main, _script_main, VERSION as __version__  # noqa
