c.InlineBackend.figure_formats = {'svg'}
c.InlineBackend.rc = {'figure.dpi': 96}
