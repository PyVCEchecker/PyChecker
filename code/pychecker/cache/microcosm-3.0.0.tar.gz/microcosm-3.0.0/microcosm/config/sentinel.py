class _Unset:
    def __repr__(self):
        return '<value not set>'


UNSET = _Unset()
