"""
Scope bindings to multiple configurations.

This feature is EXPERIMENTAL! Use at your own risk.

"""
from microcosm.scoping.decorators import scoped_binding  # noqa
from microcosm.scoping.factories import ScopedFactory  # noqa
