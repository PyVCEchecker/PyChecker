"""
Shared constants.

"""


DEFAULTS = "_defaults"
RESERVED = object()
