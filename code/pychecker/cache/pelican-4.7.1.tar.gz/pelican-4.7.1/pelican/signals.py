raise ImportError(
    'Importing from `pelican.signals` is deprecated. '
    'Use `from pelican import signals` or `import pelican.plugins.signals` instead.'
)
