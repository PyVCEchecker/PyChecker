NAME = 'namespace plugin'


def register():
    pass
