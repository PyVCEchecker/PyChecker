from .submodule import noop  # noqa: F401


def register():
    pass
