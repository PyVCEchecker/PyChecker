
This is a super article !
#########################

:tags: foo, bar, foobar
:date: 2010-12-02 10:14
:modified: 2010-12-02 10:20
:category: yeah
:author: Alexis Métaireau
:summary:
    Multi-line metadata should be supported
    as well as **inline markup** and stuff to "typogrify"...
:custom_field: http://notmyidea.org
:custom_formatted_field:
    Multi-line metadata should also be supported
    as well as *inline markup* and stuff to "typogrify"...
