Article with template
#####################

:template: custom

This article has a custom template to be called when rendered

This is some content. With some stuff to "typogrify".
