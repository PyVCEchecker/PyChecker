# This file has Macintosh line endings (\r) on purposereturn 'mac'  # noqa
