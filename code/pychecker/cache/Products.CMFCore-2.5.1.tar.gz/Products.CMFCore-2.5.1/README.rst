.. image:: https://github.com/zopefoundation/Products.CMFCore/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/Products.CMFCore/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/Products.CMFCore/badge.svg
        :target: https://coveralls.io/github/zopefoundation/Products.CMFCore

.. image:: https://readthedocs.org/projects/cmfcore/badge/?version=latest
        :target: https://cmfcore.readthedocs.org/en/latest/
        :alt: Documentation Status

.. image:: https://img.shields.io/pypi/v/Products.CMFCore.svg
        :target: https://pypi.org/project/Products.CMFCore/
        :alt: Current version on PyPI

.. image:: https://img.shields.io/pypi/pyversions/Products.CMFCore.svg
        :target: https://pypi.org/project/Products.CMFCore/
        :alt: Supported Python versions


Products.CMFCore
================

This product declares the key framework services for the Zope
Content Management Framework (CMF).


