requirementslib.environment module
==================================

.. automodule:: requirementslib.environment
    :members:
    :undoc-members:
    :show-inheritance:
