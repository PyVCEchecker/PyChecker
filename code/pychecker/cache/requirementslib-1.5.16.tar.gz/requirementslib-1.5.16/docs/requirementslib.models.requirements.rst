requirementslib.models.requirements module
==========================================

.. automodule:: requirementslib.models.requirements
    :members:
    :undoc-members:
    :show-inheritance:
