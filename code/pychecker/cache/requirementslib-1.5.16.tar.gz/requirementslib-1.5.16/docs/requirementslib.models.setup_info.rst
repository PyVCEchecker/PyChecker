requirementslib.models.setup\_info module
=========================================

.. automodule:: requirementslib.models.setup_info
    :members:
    :undoc-members:
    :show-inheritance:
