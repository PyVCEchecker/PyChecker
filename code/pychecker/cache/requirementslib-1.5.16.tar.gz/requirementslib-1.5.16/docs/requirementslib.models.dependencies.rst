requirementslib.models.dependencies module
==========================================

.. automodule:: requirementslib.models.dependencies
    :members:
    :undoc-members:
    :show-inheritance:
