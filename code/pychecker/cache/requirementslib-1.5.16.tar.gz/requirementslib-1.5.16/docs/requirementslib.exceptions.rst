requirementslib.exceptions module
=================================

.. automodule:: requirementslib.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
