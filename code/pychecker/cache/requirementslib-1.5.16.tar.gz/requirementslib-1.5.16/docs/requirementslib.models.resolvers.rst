requirementslib.models.resolvers module
=======================================

.. automodule:: requirementslib.models.resolvers
    :members:
    :undoc-members:
    :show-inheritance:
