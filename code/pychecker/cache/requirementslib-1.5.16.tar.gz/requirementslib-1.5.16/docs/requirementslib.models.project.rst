requirementslib.models.project module
=====================================

.. automodule:: requirementslib.models.project
    :members:
    :undoc-members:
    :show-inheritance:
