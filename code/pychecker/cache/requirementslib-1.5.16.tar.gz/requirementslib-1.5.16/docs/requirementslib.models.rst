requirementslib.models package
==============================

.. automodule:: requirementslib.models
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   requirementslib.models.cache
   requirementslib.models.dependencies
   requirementslib.models.lockfile
   requirementslib.models.markers
   requirementslib.models.metadata
   requirementslib.models.metadata
   requirementslib.models.pipfile
   requirementslib.models.project
   requirementslib.models.requirements
   requirementslib.models.resolvers
   requirementslib.models.setup_info
   requirementslib.models.utils
   requirementslib.models.url
   requirementslib.models.vcs
