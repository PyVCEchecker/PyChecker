requirementslib.models.pipfile module
=====================================

.. automodule:: requirementslib.models.pipfile
    :members:
    :undoc-members:
    :show-inheritance:
