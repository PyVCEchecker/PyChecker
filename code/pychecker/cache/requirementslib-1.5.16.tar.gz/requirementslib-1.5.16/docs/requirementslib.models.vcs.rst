requirementslib.models.vcs module
=================================

.. automodule:: requirementslib.models.vcs
    :members:
    :undoc-members:
    :show-inheritance:
