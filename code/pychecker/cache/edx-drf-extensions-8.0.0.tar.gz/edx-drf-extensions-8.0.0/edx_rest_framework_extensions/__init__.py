""" edx Django REST Framework extensions. """

__version__ = '8.0.0'  # pragma: no cover
