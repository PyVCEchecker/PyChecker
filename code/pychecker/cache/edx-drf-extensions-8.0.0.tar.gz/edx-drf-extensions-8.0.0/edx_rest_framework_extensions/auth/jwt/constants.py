"""
JWT Authentication constants.
"""

JWT_DELIMITER = '.'
USE_JWT_COOKIE_HEADER = 'HTTP_USE_JWT_COOKIE'
