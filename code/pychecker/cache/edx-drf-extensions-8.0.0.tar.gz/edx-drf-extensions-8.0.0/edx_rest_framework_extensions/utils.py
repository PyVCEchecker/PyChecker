""" Utility functions. """

# for compatibility with rest_framework_jwt
# pylint: disable=unused-import
from edx_rest_framework_extensions.auth.jwt.decoder import jwt_decode_handler
