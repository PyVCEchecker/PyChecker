# Included so Django's startproject command runs against the docs directory
