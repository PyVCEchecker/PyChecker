=================
python-anyconfig
=================

.. image:: https://img.shields.io/pypi/v/anyconfig.svg
   :target: https://pypi.python.org/pypi/anyconfig/
   :alt: [Latest Version]

.. image:: https://img.shields.io/pypi/pyversions/anyconfig.svg
   :target: https://pypi.python.org/pypi/anyconfig/
   :alt: [Python versions]

.. image:: https://img.shields.io/pypi/l/anyconfig.svg
   :target: https://pypi.python.org/pypi/anyconfig/
   :alt: MIT License

.. image:: https://github.com/ssato/python-anyconfig/workflows/Tests/badge.svg
   :target: https://github.com/ssato/python-anyconfig/actions?query=workflow%3ATests
   :alt: [Github Actions: Test status]

.. image:: https://img.shields.io/coveralls/ssato/python-anyconfig.svg
   :target: https://coveralls.io/r/ssato/python-anyconfig
   :alt: [Coverage Status]

.. .. image:: https://landscape.io/github/ssato/python-anyconfig/master/landscape.svg?style=flat
   :target: https://landscape.io/github/ssato/python-anyconfig/master
   :alt: [Code Health]

.. image:: https://scrutinizer-ci.com/g/ssato/python-anyconfig/badges/quality-score.png?b=master
   :target: https://scrutinizer-ci.com/g/ssato/python-anyconfig
   :alt: [Code Quality by Scrutinizer]

.. image:: https://img.shields.io/lgtm/grade/python/g/ssato/python-anyconfig.svg
   :target: https://lgtm.com/projects/g/ssato/python-anyconfig/context:python
   :alt: [Code Quality by LGTM]

.. .. image:: https://www.openhub.net/p/python-anyconfig/widgets/project_thin_badge.gif
   :target: https://www.openhub.net/p/python-anyconfig
   :alt: [Open HUB]

.. image:: https://readthedocs.org/projects/python-anyconfig/badge/?version=latest
   :target: http://python-anyconfig.readthedocs.io/en/latest/?badge=latest
   :alt: [Doc Status]

.. .. image:: https://img.shields.io/github/contributors/ssato/python-anyconfig
   :target: https://github.com/ssato/python-anyconfig/graphs/contributors/
   :alt: [GitHub contributors]

