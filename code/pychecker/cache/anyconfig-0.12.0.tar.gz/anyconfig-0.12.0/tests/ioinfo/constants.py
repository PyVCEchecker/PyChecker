#
# Copyright (C) 2021 Satoru SATOH <satoru.satoh@gmail.com>
# License: MIT
#
# pylint: disable=missing-docstring
import pathlib


TEST_PY = pathlib.Path(__file__).resolve()

# vim:sw=4:ts=4:et:
