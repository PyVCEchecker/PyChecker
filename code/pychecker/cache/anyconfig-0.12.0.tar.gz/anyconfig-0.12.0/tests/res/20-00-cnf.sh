a=0
b='bbb'   # a comment
c="ccc"   # an another comment
export d='ddd'  ## double comment
 export e="eee" ### tripple comment
