# Test cases for anyconfig\_cli

- 10.json, 20.xml, 30.sh + o/10.json: multi type inputs without any options to load, and dump to a JSON file without any options
