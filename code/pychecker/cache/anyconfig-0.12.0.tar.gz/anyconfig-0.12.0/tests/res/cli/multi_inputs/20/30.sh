d='DDD'
