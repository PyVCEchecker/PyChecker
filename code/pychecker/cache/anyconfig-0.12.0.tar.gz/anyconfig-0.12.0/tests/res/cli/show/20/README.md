# Test cases for anyconfig\_cli

- 10.json + o/10.json: no args with '-E' (load config from environment variables) option and a '-O josn' (JSON output type) option; it should print environment variables as a dict in JSON format
- 20.json + o/20.json: no args with '--env' (load config from environment variables) option and a '-O josn' (JSON output type) option; it should print environment variables as a dict in JSON format
