# Test cases for anyconfig\_cli

- 10.json + o/10.json: an input (this input file will be replaced with a file doees not exist) with '--ignore-missing' and '-O json' options to load and dump a JSON data as a string
