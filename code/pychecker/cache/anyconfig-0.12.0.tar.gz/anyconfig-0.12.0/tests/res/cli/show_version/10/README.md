# Test cases for anyconfig\_cli

- 10.json + o/10.json: no args, a '--version' option
