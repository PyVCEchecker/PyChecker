# Test cases for anyconfig\_cli

- {1,2,3}0.json + o/10.json: multi JSON inputs without any options to load, and dump to a JSON file without any options
