# Test cases for anyconfig\_cli

- 10.json + o/10.json: no args, a '-h' option, help messages should be printed (see e/10.json)
- 20.json + o/20.json: no args, a '--help' option, help messages should be printed (see e/20.json)
- 30.json + o/30.json: no args, a '-L' option, parsers should be printed (see e/30.json)
- 40.json + o/40.json: no args, a '--list' option, parsers should be printed (see e/40.json)

