# Test cases for anyconfig\_cli

- 10.json + o/10.json: a JSON input with "--args ..." option to load, and dump to the modified JSON file without any output options
