# Test cases for anyconfig\_cli

- 10.json + o/10.json: an input with known file type with "--set a=2" option to load, and dump to the modified JSON file without any output options
- 20.conf + o/20.json: an input with known file type with "--set b.c=ccc" option to load, and dump to the modified JSON file without any output options
