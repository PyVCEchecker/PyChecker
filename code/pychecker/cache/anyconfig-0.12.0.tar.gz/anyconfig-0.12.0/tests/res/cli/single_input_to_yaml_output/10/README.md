# Test cases for anyconfig\_cli

- 10.json + o/10.json: a JSON input without any options to load, and dump to a YAML file without any options
- 20.json + o/20.json: a JSON input without any options to load, and dump to a YAML file with '-O yaml' option
- 30.yml + o/30.json: a YAML input without any options to load, and dump to a JSON file without any options
- 40.yml + o/40.json: a YAML input with '-I yaml' option to load, and dump to a JSON file without any options
