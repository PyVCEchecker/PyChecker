# Test cases for anyconfig\_cli

- 10.json + o/10.json: a JSON input with "--gen-schema" option to load, and dump to a JSON schema file without any output options
