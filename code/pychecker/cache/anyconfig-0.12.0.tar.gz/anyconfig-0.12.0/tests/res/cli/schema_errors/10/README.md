# Test cases for anyconfig\_cli

- 10.json + o/10.json: An JSON input to load with "--validate" option without "--schema" option should cause an error.
