:mod:`anyconfig.api._load`
===============================

.. automodule:: anyconfig.api._load
    :members:
    :undoc-members:
    :show-inheritance:
