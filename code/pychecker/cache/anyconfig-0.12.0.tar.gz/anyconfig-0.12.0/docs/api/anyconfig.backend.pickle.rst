:mod:`anyconfig.backend.pickle`
================================

.. automodule:: anyconfig.backend.pickle
    :members:
    :special-members:
    :private-members:
    :undoc-members:
    :show-inheritance:
