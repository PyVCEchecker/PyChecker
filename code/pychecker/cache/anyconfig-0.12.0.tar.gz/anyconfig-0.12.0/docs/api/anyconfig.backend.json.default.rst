:mod:`anyconfig.backend.json.default`
========================================

.. automodule:: anyconfig.backend.json.default
    :members:
    :special-members:
    :private-members:
    :undoc-members:
    :show-inheritance:
