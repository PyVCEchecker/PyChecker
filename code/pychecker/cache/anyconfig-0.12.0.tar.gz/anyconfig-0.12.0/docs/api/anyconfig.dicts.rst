:mod:`anyconfig.dicts`
========================

.. automodule:: anyconfig.dicts
    :members:
    :undoc-members:
    :show-inheritance:

