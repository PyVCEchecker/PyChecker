:mod:`anyconfig.ioinfo.constants`
==================================

.. automodule:: anyconfig.ioinfo.constants
    :members:
    :special-members:
    :private-members:
    :undoc-members:
    :show-inheritance:
