:mod:`anyconfig.backend.base.compat`
=======================================

.. automodule:: anyconfig.backend.base.compat
    :members:
    :undoc-members:
    :show-inheritance:
