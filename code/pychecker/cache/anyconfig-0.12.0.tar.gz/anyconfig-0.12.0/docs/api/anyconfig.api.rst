:mod:`anyconfig.api`
=====================

.. automodule:: anyconfig.api
    :members:
    :undoc-members:
    :show-inheritance:
    
.. toctree::

   anyconfig.api.datatypes
   anyconfig.api._dump
   anyconfig.api._load
   anyconfig.api._open
   anyconfig.api.utils
