:mod:`anyconfig.query.query`
=============================

.. automodule:: anyconfig.query.query
    :members:
    :undoc-members:
    :show-inheritance:
