:mod:`anyconfig.common.errors`
================================

.. automodule:: anyconfig.common.errors
    :members:
    :undoc-members:
    :show-inheritance:
