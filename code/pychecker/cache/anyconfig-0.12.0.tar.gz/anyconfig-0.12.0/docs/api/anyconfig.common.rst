:mod:`anyconfig.common`
========================

.. automodule:: anyconfig.common
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::

   anyconfig.common.datatypes
   anyconfig.common.errors
