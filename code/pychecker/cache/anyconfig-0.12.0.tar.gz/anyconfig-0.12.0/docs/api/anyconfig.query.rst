:mod:`anyconfig.query`
========================

.. automodule:: anyconfig.query
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::

   anyconfig.query.datatypes
   anyconfig.query.default
   anyconfig.query.query
