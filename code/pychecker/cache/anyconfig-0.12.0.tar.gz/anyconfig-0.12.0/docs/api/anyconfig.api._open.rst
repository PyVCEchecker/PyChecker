:mod:`anyconfig.api._open`
===============================

.. automodule:: anyconfig.api._open
    :members:
    :undoc-members:
    :show-inheritance:
