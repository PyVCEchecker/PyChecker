:mod:`anyconfig.backend.shellvars`
===================================

.. automodule:: anyconfig.backend.shellvars
    :members:
    :special-members:
    :private-members:
    :undoc-members:
    :show-inheritance:
