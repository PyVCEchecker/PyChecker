:mod:`anyconfig.schema.datatypes`
==================================

.. automodule:: anyconfig.schema.datatypes
    :members:
    :undoc-members:
    :show-inheritance:
