:mod:`anyconfig.schema.default`
================================

.. automodule:: anyconfig.schema.default
    :members:
    :undoc-members:
    :show-inheritance:
