:mod:`anyconfig.schema.jsonschema`
====================================

.. automodule:: anyconfig.schema.jsonschema
    :members:
    :undoc-members:
    :show-inheritance:
