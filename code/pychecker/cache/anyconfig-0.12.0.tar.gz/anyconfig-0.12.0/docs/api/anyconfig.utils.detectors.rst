:mod:`anyconfig.utils.detectors`
=================================

.. automodule:: anyconfig.utils.detectors
    :members:
    :undoc-members:
    :show-inheritance:
