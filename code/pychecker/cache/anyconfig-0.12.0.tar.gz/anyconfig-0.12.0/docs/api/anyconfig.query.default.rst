:mod:`anyconfig.query.default`
===============================

.. automodule:: anyconfig.query.default
    :members:
    :undoc-members:
    :show-inheritance:
