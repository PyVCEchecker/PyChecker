:mod:`anyconfig.schema`
========================

.. automodule:: anyconfig.schema
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::

   anyconfig.schema.datatypes
   anyconfig.schema.default
   anyconfig.schema.jsonschema
