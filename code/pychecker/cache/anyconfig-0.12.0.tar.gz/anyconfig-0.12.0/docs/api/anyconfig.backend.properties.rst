:mod:`anyconfig.backend.properties`
=====================================

.. automodule:: anyconfig.backend.properties
    :members:
    :special-members:
    :private-members:
    :undoc-members:
    :show-inheritance:
