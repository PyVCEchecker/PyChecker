=================
python-anyconfig
=================

.. toctree::
    :maxdepth: 1

    usage
    api/index
    design
    cli

.. include:: introduction.rst
.. include:: hacking.rst

.. vim:sw=2:ts=2:et:
