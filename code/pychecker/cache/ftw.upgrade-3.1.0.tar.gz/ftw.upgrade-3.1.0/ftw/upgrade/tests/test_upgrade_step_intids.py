from ftw.upgrade.testing import INTID_UPGRADE_FUNCTIONAL_TESTING
from ftw.upgrade.tests.test_upgrade_step import TestUpgradeStep


class TestUpgradeStepIntids(TestUpgradeStep):

    layer = INTID_UPGRADE_FUNCTIONAL_TESTING
