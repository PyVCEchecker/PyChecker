#!/usr/bin/env python
from setuptools import setup

setup(
    long_description_content_type='text/x-rst'
)
