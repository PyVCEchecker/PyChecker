default_app_config = "graphql_ws.django.apps.GraphQLChannelsApp"
