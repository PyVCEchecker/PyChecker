from django.apps import AppConfig


class GraphQLChannelsApp(AppConfig):
    name = "graphql_ws.django"
    label = "graphql_channels"
