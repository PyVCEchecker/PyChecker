=====
Usage
=====

To use GraphQL AioWS in a project::

    import graphql_ws
