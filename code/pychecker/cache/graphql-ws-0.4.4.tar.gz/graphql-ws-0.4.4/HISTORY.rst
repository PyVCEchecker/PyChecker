=======
History
=======

0.4.4 (2021-08-24)
==================
- Fix: Readme syntax

0.4.3 (2021-08-24)
==================
- Add markdown support for package description
- Fix: PyPi publish

0.4.2 (2021-08-24)
==================
- Bump django version

0.4.1 (2021-08-24)
==================
- Bump graphql-ws version in source code

0.4.0 (2021-08-24)
==================
- Removed support for Django 2
- Added GitHub actions
- Added Channels v3 compatibility
- Added new module to support Channels > 1 #18
- Fix: tests are running again
- Fix: Correctly unsubscribe after on_start operation is complete
- Breaking changes

0.3.1 (2020-05-19)
==================
- update travis deployment credentials and remove travis autogen config


0.3.0 (2018-09-25)
==================

- Django channels (v1) server (with example app).

- Websockets lib server (with example app).

- Observable aiter server.


0.2.0 (2017-11-18)
==================

- Add gevent subscription server.

- Add example flask gevent app.


0.1.0 (2017-10-15)
==================

- First release on PyPI.
