import click


@click.command()
def get_context():
    return {}
