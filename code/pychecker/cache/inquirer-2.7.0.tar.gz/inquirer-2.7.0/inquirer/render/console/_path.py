# -*- coding: utf-8 -*-

from . import Text


class Path(Text):
    pass
