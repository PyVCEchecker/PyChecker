.. certbot-dns-cloudflare documentation master file, created by
   sphinx-quickstart on Tue May  9 10:20:04 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to certbot-dns-cloudflare's documentation!
==================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: certbot_dns_cloudflare
   :members:

.. toctree::
   :maxdepth: 1

   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
