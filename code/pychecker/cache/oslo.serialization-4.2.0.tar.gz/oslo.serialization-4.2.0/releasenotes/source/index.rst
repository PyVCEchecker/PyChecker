==================================
 oslo.serialization Release Notes
==================================

.. toctree::
   :maxdepth: 1

   unreleased
   wallaby
   victoria
   ussuri
   train
   stein
   rocky
   queens
   pike
   ocata
