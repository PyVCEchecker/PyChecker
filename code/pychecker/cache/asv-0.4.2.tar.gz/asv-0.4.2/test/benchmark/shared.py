def shared_function():
    return 42
