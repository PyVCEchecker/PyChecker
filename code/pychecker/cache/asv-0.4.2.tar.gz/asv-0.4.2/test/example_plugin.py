from asv.environment import Environment

print("Imported custom environment")


class MyEnvironment(Environment):
    pass
