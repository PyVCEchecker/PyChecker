#!/usr/bin/env bash

set -e

mkdocs serve --dev-addr 127.0.0.1:8008
