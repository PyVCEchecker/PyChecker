import typer


def main():
    typer.echo("Hello World")


if __name__ == "__main__":
    typer.run(main)
