Please read the [Development - Contributing](https://typer.tiangolo.com/contributing/) guidelines in the documentation site.
