There are several ways to declare multiple values for *CLI options* and *CLI arguments*.

We'll see them in the next short sections.
