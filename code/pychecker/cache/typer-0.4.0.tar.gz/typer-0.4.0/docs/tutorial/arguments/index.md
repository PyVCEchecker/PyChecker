In the next few sections we'll see some ways to modify how *CLI arguments* work.

We'll create optional *CLI arguments*, we'll add integrated help for *CLI arguments*, etc.
