`typer.Argument()` has several other use cases. Such as for data validation, to enable other features, etc.

You will see about these use cases later in the docs.
