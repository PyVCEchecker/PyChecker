In the next short sections we will see how to modify *CLI options* using `typer.Option()`.

`typer.Option()` works very similarly to `typer.Argument()`, but has some extra features that we'll see next.
