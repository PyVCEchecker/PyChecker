from .jsonpath import *  # noqa
from .parser import parse  # noqa


# Current package version
__version__ = '1.5.2'
