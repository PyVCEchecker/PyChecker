COO\.prod
=========

.. currentmodule:: sparse

.. automethod:: COO.prod