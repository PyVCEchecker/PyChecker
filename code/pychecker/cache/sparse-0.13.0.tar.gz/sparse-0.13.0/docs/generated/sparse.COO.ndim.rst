COO\.ndim
=========

.. currentmodule:: sparse

.. autoattribute:: COO.ndim