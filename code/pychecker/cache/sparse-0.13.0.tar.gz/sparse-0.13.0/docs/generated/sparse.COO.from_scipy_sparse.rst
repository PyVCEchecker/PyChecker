COO\.from\_scipy\_sparse
========================

.. currentmodule:: sparse

.. automethod:: COO.from_scipy_sparse