COO\.min
========

.. currentmodule:: sparse

.. automethod:: COO.min