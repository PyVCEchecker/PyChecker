GCXS.\_\_init\_\_
=================

.. currentmodule:: sparse

.. automethod:: GCXS.__init__