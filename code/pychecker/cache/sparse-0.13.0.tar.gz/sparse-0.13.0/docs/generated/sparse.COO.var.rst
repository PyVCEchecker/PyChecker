COO.var
=======

.. currentmodule:: sparse

.. automethod:: COO.var