COO.asformat
============

.. currentmodule:: sparse

.. automethod:: COO.asformat