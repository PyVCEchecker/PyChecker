DOK\.to\_coo
============

.. currentmodule:: sparse

.. automethod:: DOK.to_coo