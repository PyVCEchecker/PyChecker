COO\.nbytes
===========

.. currentmodule:: sparse

.. autoattribute:: COO.nbytes