COO\.size
=========

.. currentmodule:: sparse

.. autoattribute:: COO.size
