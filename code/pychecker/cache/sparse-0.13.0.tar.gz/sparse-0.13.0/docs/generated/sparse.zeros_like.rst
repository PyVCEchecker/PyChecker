zeros_like
==========

.. currentmodule:: sparse

.. autofunction:: zeros_like
