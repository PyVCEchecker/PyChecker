GCXS.amax
=========

.. currentmodule:: sparse

.. automethod:: GCXS.amax