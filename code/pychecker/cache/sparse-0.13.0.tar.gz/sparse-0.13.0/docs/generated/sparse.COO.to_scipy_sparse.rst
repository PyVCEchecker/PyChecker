COO\.to\_scipy\_sparse
======================

.. currentmodule:: sparse

.. automethod:: COO.to_scipy_sparse