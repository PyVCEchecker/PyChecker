outer
=====

.. currentmodule:: sparse

.. autofunction:: outer