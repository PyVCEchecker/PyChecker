COO\.reduce
===========

.. currentmodule:: sparse

.. automethod:: COO.reduce