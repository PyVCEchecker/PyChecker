kron
====

.. currentmodule:: sparse

.. autofunction:: kron
