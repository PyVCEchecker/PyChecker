SparseArray\.nnz
================

.. currentmodule:: sparse

.. autoattribute:: SparseArray.nnz