COO.swapaxes
============

.. currentmodule:: sparse

.. automethod:: COO.swapaxes