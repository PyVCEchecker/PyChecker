GCXS.prod
=========

.. currentmodule:: sparse

.. automethod:: GCXS.prod