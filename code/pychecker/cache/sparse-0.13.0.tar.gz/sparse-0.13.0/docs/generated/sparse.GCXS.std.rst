GCXS.std
========

.. currentmodule:: sparse

.. automethod:: GCXS.std