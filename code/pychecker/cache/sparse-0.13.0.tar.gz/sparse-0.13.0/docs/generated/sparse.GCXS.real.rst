GCXS.real
=========

.. currentmodule:: sparse

.. autoproperty:: GCXS.real