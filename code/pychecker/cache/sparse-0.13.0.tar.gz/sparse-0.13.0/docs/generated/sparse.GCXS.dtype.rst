GCXS.dtype
==========

.. currentmodule:: sparse

.. autoproperty:: GCXS.dtype