GCXS.dot
========

.. currentmodule:: sparse

.. automethod:: GCXS.dot