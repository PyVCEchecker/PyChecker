SparseArray\.ndim
=================

.. currentmodule:: sparse

.. autoattribute:: SparseArray.ndim