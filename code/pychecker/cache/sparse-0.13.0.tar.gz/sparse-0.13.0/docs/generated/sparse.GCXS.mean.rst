GCXS.mean
=========

.. currentmodule:: sparse

.. automethod:: GCXS.mean