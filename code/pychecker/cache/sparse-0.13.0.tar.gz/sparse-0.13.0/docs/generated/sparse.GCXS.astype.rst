GCXS.astype
===========

.. currentmodule:: sparse

.. automethod:: GCXS.astype