GCXS.sum
========

.. currentmodule:: sparse

.. automethod:: GCXS.sum