GCXS.density
============

.. currentmodule:: sparse

.. autoproperty:: GCXS.density