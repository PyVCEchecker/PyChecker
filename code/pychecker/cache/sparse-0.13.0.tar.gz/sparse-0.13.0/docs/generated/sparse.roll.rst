roll
====

.. currentmodule:: sparse

.. autofunction:: roll