COO\.from\_numpy
================

.. currentmodule:: sparse

.. automethod:: COO.from_numpy