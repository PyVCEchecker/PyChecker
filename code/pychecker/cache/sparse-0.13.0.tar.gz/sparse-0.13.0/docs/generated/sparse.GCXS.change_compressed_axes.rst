GCXS.change\_compressed\_axes
=============================

.. currentmodule:: sparse

.. automethod:: GCXS.change_compressed_axes