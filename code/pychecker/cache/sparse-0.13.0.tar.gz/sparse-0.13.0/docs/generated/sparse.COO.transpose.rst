COO\.transpose
==============

.. currentmodule:: sparse

.. automethod:: COO.transpose