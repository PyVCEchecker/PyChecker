GCXS.round\_
============

.. currentmodule:: sparse

.. automethod:: GCXS.round_