nanmin
======

.. currentmodule:: sparse

.. autofunction:: nanmin