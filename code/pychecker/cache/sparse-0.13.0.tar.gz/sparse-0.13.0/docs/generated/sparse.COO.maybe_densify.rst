COO\.maybe\_densify
===================

.. currentmodule:: sparse

.. automethod:: COO.maybe_densify