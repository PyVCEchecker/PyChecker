GCXS.transpose
==============

.. currentmodule:: sparse

.. automethod:: GCXS.transpose