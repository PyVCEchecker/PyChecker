zeros
=====

.. currentmodule:: sparse

.. autofunction:: zeros
