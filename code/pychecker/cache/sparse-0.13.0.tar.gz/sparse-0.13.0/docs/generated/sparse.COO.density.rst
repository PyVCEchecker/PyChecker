COO\.density
============

.. currentmodule:: sparse

.. autoattribute:: COO.density
