COO\.tocsc
==========

.. currentmodule:: sparse

.. automethod:: COO.tocsc