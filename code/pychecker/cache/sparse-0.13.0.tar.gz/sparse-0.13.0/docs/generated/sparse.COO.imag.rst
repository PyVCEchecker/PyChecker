COO\.imag
=========

.. currentmodule:: sparse

.. autoattribute:: COO.imag
