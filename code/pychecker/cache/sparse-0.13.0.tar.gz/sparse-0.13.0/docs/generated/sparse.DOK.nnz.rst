DOK\.nnz
========

.. currentmodule:: sparse

.. autoattribute:: DOK.nnz