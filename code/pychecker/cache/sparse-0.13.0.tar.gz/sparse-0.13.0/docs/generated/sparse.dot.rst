dot
===

.. currentmodule:: sparse

.. autofunction:: dot