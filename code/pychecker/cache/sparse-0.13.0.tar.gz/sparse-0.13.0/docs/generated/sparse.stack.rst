stack
=====

.. currentmodule:: sparse

.. autofunction:: stack