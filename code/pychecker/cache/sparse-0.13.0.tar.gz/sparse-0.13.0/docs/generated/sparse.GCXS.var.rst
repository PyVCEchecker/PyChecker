GCXS.var
========

.. currentmodule:: sparse

.. automethod:: GCXS.var