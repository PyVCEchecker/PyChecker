DOK\.todense
============

.. currentmodule:: sparse

.. automethod:: DOK.todense