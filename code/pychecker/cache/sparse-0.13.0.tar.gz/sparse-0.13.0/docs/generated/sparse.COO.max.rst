COO\.max
========

.. currentmodule:: sparse

.. automethod:: COO.max