full
====

.. currentmodule:: sparse

.. autofunction:: full
