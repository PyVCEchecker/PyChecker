COO.any
=======

.. currentmodule:: sparse

.. automethod:: COO.any