argwhere
========

.. currentmodule:: sparse

.. autofunction:: argwhere