COO\.round
==========

.. currentmodule:: sparse

.. automethod:: COO.round