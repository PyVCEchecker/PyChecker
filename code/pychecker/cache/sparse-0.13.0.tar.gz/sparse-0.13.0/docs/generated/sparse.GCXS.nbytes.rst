GCXS.nbytes
===========

.. currentmodule:: sparse

.. autoproperty:: GCXS.nbytes