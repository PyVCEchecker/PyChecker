DOK\.ndim
=========

.. currentmodule:: sparse

.. autoattribute:: DOK.ndim