tril
====

.. currentmodule:: sparse

.. autofunction:: tril