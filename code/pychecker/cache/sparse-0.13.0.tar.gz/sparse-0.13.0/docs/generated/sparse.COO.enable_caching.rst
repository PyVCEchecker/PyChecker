COO\.enable\_caching
====================

.. currentmodule:: sparse

.. automethod:: COO.enable_caching