GCXS.to\_scipy\_sparse
======================

.. currentmodule:: sparse

.. automethod:: GCXS.to_scipy_sparse