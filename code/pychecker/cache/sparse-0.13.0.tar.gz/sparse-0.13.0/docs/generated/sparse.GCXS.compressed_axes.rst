GCXS.compressed\_axes
=====================

.. currentmodule:: sparse

.. autoproperty:: GCXS.compressed_axes