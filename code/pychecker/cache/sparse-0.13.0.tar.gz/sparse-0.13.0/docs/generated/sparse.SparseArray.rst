SparseArray
===========

.. currentmodule:: sparse

.. autoclass:: SparseArray

   .. rubric:: Attributes
   .. autosummary::
      :toctree:

      SparseArray.density
      SparseArray.ndim
      SparseArray.nnz
      SparseArray.size

   .. rubric:: Methods
   .. autosummary::
      :toctree:

      SparseArray.asformat
      SparseArray.todense

