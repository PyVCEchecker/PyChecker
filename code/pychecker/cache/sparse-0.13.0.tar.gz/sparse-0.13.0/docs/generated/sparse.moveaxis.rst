moveaxis
========

.. currentmodule:: sparse

.. autofunction:: moveaxis