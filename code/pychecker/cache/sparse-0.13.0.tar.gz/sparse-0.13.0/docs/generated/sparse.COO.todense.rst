COO\.todense
============

.. currentmodule:: sparse

.. automethod:: COO.todense