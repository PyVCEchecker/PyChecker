GCXS.todense
============

.. currentmodule:: sparse

.. automethod:: GCXS.todense