elemwise
========

.. currentmodule:: sparse

.. autofunction:: elemwise