nanprod
=======

.. currentmodule:: sparse

.. autofunction:: nanprod