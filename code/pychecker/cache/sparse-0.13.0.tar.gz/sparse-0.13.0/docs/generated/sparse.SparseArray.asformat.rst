SparseArray.asformat
====================

.. currentmodule:: sparse

.. automethod:: SparseArray.asformat