SparseArray\.size
=================

.. currentmodule:: sparse

.. autoattribute:: SparseArray.size