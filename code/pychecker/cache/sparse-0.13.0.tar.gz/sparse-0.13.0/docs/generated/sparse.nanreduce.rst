nanreduce
=========

.. currentmodule:: sparse

.. autofunction:: nanreduce