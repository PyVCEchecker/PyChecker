GCXS.reshape
============

.. currentmodule:: sparse

.. automethod:: GCXS.reshape