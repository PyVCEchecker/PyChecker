nanmean
=======

.. currentmodule:: sparse

.. autofunction:: nanmean
