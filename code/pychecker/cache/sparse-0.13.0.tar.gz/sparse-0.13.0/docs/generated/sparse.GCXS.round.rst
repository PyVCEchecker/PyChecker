GCXS.round
==========

.. currentmodule:: sparse

.. automethod:: GCXS.round