as\_coo
=======

.. currentmodule:: sparse

.. autofunction:: as_coo