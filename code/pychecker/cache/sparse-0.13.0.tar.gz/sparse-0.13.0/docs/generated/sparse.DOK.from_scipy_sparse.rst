DOK.from\_scipy\_sparse
=======================

.. currentmodule:: sparse

.. automethod:: DOK.from_scipy_sparse