result_type
===========

.. currentmodule:: sparse

.. autofunction:: result_type