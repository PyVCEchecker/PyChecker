SparseArray.todense
===================

.. currentmodule:: sparse

.. automethod:: SparseArray.todense