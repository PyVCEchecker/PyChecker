GCXS.nnz
========

.. currentmodule:: sparse

.. autoproperty:: GCXS.nnz