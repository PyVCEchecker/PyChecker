GCXS.conj
=========

.. currentmodule:: sparse

.. automethod:: GCXS.conj