COO\.clip
=========

.. currentmodule:: sparse

.. automethod:: COO.clip
