COO\.dtype
==========

.. currentmodule:: sparse

.. autoattribute:: COO.dtype