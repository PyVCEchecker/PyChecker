GCXS.min
========

.. currentmodule:: sparse

.. automethod:: GCXS.min