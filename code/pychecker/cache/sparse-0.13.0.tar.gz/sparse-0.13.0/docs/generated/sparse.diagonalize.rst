diagonalize
===========

.. currentmodule:: sparse

.. autofunction:: diagonalize