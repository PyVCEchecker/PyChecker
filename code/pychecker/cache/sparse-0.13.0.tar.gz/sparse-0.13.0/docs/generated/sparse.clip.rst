clip
====

.. currentmodule:: sparse

.. autofunction:: clip