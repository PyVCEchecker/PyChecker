DOK.asformat
============

.. currentmodule:: sparse

.. automethod:: DOK.asformat