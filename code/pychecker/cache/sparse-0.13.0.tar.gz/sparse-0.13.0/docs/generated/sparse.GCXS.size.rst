GCXS.size
=========

.. currentmodule:: sparse

.. autoproperty:: GCXS.size