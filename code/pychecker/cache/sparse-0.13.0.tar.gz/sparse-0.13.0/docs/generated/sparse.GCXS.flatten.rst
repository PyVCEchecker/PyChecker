GCXS.flatten
============

.. currentmodule:: sparse

.. automethod:: GCXS.flatten