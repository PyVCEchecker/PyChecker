isposinf
========

.. currentmodule:: sparse

.. autofunction:: isposinf