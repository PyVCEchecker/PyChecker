COO\.T
======

.. currentmodule:: sparse

.. autoattribute:: COO.T