GCXS.todok
==========

.. currentmodule:: sparse

.. automethod:: GCXS.todok