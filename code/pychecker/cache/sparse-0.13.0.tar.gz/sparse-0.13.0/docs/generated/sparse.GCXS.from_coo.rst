GCXS.from\_coo
==============

.. currentmodule:: sparse

.. automethod:: GCXS.from_coo