COO\.reshape
============

.. currentmodule:: sparse

.. automethod:: COO.reshape