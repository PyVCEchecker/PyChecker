COO\.dot
========

.. currentmodule:: sparse

.. automethod:: COO.dot