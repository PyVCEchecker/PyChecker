COO\.mean
=========

.. currentmodule:: sparse

.. automethod:: COO.mean
