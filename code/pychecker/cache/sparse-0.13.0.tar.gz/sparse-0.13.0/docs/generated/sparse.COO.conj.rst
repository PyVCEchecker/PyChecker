COO\.conj
=========

.. currentmodule:: sparse

.. automethod:: COO.conj
