nanmax
======

.. currentmodule:: sparse

.. autofunction:: nanmax