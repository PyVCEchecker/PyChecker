GCXS.maybe\_densify
===================

.. currentmodule:: sparse

.. automethod:: GCXS.maybe_densify