ones
====

.. currentmodule:: sparse

.. autofunction:: ones
