GCXS.ndim
=========

.. currentmodule:: sparse

.. autoproperty:: GCXS.ndim