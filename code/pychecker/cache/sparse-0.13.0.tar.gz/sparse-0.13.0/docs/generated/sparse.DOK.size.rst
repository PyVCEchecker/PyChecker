DOK\.size
=========

.. currentmodule:: sparse

.. autoattribute:: DOK.size