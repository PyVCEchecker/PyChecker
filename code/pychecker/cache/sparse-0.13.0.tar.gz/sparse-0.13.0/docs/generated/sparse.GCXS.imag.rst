GCXS.imag
=========

.. currentmodule:: sparse

.. autoproperty:: GCXS.imag