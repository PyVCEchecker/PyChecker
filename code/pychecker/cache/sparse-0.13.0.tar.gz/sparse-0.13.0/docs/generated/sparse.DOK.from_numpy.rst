DOK\.from\_numpy
================

.. currentmodule:: sparse

.. automethod:: DOK.from_numpy