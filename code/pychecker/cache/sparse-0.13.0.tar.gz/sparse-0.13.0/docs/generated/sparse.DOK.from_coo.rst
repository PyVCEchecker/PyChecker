DOK\.from\_coo
==============

.. currentmodule:: sparse

.. automethod:: DOK.from_coo