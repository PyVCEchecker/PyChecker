full_like
=========

.. currentmodule:: sparse

.. autofunction:: full_like
