DOK\.density
============

.. currentmodule:: sparse

.. autoattribute:: DOK.density