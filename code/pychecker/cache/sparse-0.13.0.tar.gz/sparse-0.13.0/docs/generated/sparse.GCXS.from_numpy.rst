GCXS.from\_numpy
================

.. currentmodule:: sparse

.. automethod:: GCXS.from_numpy