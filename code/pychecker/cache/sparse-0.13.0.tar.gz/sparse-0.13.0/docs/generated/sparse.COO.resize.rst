COO.resize
==========

.. currentmodule:: sparse

.. automethod:: COO.resize