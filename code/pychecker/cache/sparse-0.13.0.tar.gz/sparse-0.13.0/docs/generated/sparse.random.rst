random
======

.. currentmodule:: sparse

.. autofunction:: random