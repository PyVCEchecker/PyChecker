﻿pad
===

.. currentmodule:: sparse

.. autofunction:: pad