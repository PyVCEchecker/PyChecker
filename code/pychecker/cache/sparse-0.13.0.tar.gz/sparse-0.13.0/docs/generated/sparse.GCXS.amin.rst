GCXS.amin
=========

.. currentmodule:: sparse

.. automethod:: GCXS.amin