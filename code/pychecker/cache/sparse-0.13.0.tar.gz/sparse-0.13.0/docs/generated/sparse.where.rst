where
=====

.. currentmodule:: sparse

.. autofunction:: where