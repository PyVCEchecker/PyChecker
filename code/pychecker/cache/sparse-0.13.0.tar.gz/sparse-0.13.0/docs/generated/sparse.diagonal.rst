diagonal
=============

.. currentmodule:: sparse

.. autofunction:: diagonal