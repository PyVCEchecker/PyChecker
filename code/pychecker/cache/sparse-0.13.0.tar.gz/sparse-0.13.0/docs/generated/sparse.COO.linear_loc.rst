COO\.linear\_loc
================

.. currentmodule:: sparse

.. automethod:: COO.linear_loc