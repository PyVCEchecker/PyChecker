COO\.tocsr
==========

.. currentmodule:: sparse

.. automethod:: COO.tocsr