eye
===

.. currentmodule:: sparse

.. autofunction:: eye
