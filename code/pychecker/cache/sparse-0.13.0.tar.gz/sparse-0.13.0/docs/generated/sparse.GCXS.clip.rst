GCXS.clip
=========

.. currentmodule:: sparse

.. automethod:: GCXS.clip