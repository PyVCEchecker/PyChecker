GCXS.asformat
=============

.. currentmodule:: sparse

.. automethod:: GCXS.asformat