triu
====

.. currentmodule:: sparse

.. autofunction:: triu