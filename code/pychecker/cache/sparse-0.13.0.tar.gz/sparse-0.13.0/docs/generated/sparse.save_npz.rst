save\_npz
=========

.. currentmodule:: sparse

.. autofunction:: save_npz