COO\.copy
=========

.. currentmodule:: sparse

.. automethod:: COO.copy
