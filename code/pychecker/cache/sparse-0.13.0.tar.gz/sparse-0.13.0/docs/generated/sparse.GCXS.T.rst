GCXS.T
======

.. currentmodule:: sparse

.. autoproperty:: GCXS.T