COO\.nnz
========

.. currentmodule:: sparse

.. autoattribute:: COO.nnz