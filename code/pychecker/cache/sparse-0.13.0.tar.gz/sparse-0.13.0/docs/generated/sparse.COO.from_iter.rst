COO.from\_iter
==============

.. currentmodule:: sparse

.. automethod:: COO.from_iter