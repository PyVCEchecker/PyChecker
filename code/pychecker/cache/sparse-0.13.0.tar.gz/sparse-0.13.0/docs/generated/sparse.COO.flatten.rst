COO.flatten
===========

.. currentmodule:: sparse

.. automethod:: COO.flatten