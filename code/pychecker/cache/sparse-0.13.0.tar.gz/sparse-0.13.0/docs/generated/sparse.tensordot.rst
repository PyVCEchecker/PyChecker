tensordot
=========

.. currentmodule:: sparse

.. autofunction:: tensordot