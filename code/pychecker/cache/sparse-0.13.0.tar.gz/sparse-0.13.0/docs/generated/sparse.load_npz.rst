load\_npz
=========

.. currentmodule:: sparse

.. autofunction:: load_npz