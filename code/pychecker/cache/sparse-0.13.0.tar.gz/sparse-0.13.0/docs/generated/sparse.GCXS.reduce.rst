GCXS.reduce
===========

.. currentmodule:: sparse

.. automethod:: GCXS.reduce