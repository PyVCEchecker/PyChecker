ones_like
=========

.. currentmodule:: sparse

.. autofunction:: ones_like
