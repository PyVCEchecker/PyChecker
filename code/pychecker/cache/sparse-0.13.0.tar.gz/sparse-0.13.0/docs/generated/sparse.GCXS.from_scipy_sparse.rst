GCXS.from\_scipy\_sparse
========================

.. currentmodule:: sparse

.. automethod:: GCXS.from_scipy_sparse