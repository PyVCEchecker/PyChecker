GCXS.copy
=========

.. currentmodule:: sparse

.. automethod:: GCXS.copy