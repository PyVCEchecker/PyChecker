COO.all
=======

.. currentmodule:: sparse

.. automethod:: COO.all