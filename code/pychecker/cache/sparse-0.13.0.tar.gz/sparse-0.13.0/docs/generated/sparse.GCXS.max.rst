GCXS.max
========

.. currentmodule:: sparse

.. automethod:: GCXS.max