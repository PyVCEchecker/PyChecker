GCXS.from\_iter
===============

.. currentmodule:: sparse

.. automethod:: GCXS.from_iter