COO\.astype
===========

.. currentmodule:: sparse

.. automethod:: COO.astype