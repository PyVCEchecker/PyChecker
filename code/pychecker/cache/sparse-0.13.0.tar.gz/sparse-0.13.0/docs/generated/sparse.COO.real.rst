COO\.real
=========

.. currentmodule:: sparse

.. autoattribute:: COO.real
