isneginf
========

.. currentmodule:: sparse

.. autofunction:: isneginf