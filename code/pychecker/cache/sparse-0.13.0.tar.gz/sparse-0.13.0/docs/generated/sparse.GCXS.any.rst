GCXS.any
========

.. currentmodule:: sparse

.. automethod:: GCXS.any