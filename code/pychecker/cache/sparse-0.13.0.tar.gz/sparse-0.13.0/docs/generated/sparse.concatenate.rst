concatenate
===========

.. currentmodule:: sparse

.. autofunction:: concatenate