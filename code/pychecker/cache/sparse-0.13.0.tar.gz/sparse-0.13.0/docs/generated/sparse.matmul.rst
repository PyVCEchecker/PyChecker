matmul
======

.. currentmodule:: sparse

.. autofunction:: matmul