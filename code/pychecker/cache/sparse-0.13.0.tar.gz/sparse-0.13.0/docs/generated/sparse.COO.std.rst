COO.std
=======

.. currentmodule:: sparse

.. automethod:: COO.std