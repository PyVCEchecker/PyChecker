COO.nonzero
===========

.. currentmodule:: sparse

.. automethod:: COO.nonzero