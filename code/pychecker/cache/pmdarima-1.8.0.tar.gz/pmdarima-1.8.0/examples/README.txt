.. _general_examples:

Examples
========

General examples
----------------

General-purpose and introductory examples for ``pmdarima``. These examples are
designed to introduce you to the package style and layout.

.. raw:: html

   <br/>
