.. _preprocessing_examples:

Preprocessing examples
----------------------

Examples of how to use the :mod:`pmdarima.preprocessing` module to transform
your time series or exog features inside or outside of a pipeline.

.. raw:: html

   <br/>
