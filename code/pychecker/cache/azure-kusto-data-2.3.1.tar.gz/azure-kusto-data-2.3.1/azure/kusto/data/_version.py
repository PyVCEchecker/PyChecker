# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License
VERSION = "2.3.1"
