Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/esp32spi_simpletest.py
    :caption: examples/esp32spi_simpletest.py
    :linenos:


Other Examples
---------------

.. literalinclude:: ../examples/esp32spi_cheerlights.py
    :caption: examples/esp32spi_cheerlights.py
    :linenos:

.. literalinclude:: ../examples/esp32spi_aio_post.py
    :caption: examples/esp32spi_aio_post.py
    :linenos:
