class NaNCreationError(Exception):
    """Simulation error."""

    pass
