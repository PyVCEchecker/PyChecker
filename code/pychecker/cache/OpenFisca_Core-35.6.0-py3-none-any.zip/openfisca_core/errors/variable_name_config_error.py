class VariableNameConflictError(Exception):
    """
    Exception raised when two variables with the same name are added to a tax and benefit system.
    """

    pass
