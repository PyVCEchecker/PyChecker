from openfisca_core.parameters import Parameter


class ValuesHistory(Parameter):
    """
    Only for backward compatibility.
    """

    pass
