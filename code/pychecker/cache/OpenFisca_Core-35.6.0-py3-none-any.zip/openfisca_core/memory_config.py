# The memory config module has been deprecated since X.X.X,
# and will be removed in the future.
#
# Module's contents have been moved to the experimental module.
#
# The following are transitional imports to ensure non-breaking changes.
# Could be deprecated in the next major release.

from openfisca_core.experimental import MemoryConfig  # noqa: F401
