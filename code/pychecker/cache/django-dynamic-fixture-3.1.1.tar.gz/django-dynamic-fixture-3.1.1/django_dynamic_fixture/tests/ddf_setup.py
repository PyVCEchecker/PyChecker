import platform
import django


print('\n\n')
print(':: DDF-Nose plugin. ddf_setup.py loaded.')
print(platform.python_version())
print('Django {}'.format(django.VERSION))
print('\n\n')
