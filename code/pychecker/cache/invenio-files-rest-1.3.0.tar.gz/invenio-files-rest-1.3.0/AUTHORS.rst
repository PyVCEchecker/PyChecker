..
    This file is part of Invenio.
    Copyright (C) 2015-2019 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Chiara Bigarella
- David Zerulla
- Emanuel Dima
- Esteban J. G. Gabancho
- Harris Tzovanakis
- Ioan Ungurean
- Jacopo Notarstefano
- Javier Delgado
- Javier Martin Montull
- Jiri Kuncar
- Jose Benito Gonzalez Lopez
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Nicola Tarocco
- Nicolas Harraudeau
- Niklas Persson
- Nikos Filippakis
- Sami Hiltunen
- Samuele Kaplun
- Sebastian Witowski
- Spiros Delviniotis
- Steven Loria
- Tibor Simko
