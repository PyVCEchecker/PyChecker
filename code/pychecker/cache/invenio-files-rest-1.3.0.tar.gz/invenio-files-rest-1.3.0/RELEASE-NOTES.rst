..
    This file is part of Invenio.
    Copyright (C) 2015-2019 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

==============================
 Invenio-Files-REST v1.0.0a23
==============================

Invenio-Files-REST v1.0.0a23 was released on May 30, 2018.

About
-----

Files download/upload REST API similar to S3 for Invenio.

*This is an experimental developer preview release.*

What's new
----------

- Initial public release.

Installation
------------

   $ pip install invenio-files-rest==1.0.0a23

Documentation
-------------

   https://invenio-files-rest.readthedocs.io/

Happy hacking and thanks for flying Invenio-Files-REST.

| Invenio Development Team
|   Email: info@inveniosoftware.org
|   IRC: #invenio on irc.freenode.net
|   Twitter: https://twitter.com/inveniosoftware
|   GitHub: https://github.com/inveniosoftware/invenio-files-rest
|   URL: http://inveniosoftware.org
