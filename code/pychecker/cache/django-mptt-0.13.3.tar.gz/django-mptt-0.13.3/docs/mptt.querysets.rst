==================
``mptt.querysets``
==================

.. automodule:: mptt.querysets
    :members:
    :undoc-members:
