=================
``mptt.managers``
=================

.. automodule:: mptt.managers
    :members:
    :undoc-members:
