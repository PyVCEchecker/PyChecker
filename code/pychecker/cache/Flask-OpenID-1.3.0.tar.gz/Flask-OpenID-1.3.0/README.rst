Flask-OpenID
============

Adds support for OpenID to flask applications.  Check out the
example for more information.

Documentation: http://packages.python.org/Flask-OpenID/


CHANGELOG
---------

* 1.3.0 Version: 8, September 2021

Python 3-only compatible version with 2to3 removed to satisfy
setuptools removal of 2to3 configuration option of setup.py
