from pew.pew import pew

pew()
