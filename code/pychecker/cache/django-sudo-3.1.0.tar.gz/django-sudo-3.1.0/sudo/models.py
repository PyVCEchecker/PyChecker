"""
sudo.models
~~~~~~~~~~~

:copyright: (c) 2020 by Matt Robenolt.
:license: BSD, see LICENSE for more details.
"""
# Register signals automatically by installing the app
from sudo.signals import *  # noqa
