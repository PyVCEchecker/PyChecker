from .DES import *

DES = des
DES3 = triple_des

DES_CBC = CBC
DES_ECB = ECB