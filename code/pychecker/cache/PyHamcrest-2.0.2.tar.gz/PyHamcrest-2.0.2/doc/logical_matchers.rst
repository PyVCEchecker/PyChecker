Logical Matchers
----------------

Boolean logic using other matchers.


all_of
^^^^^^

.. automodule:: hamcrest.core.core.allof
    :exclude-members: all_of
.. autofunction:: all_of(matcher1[, matcher2[, ...]])

any_of
^^^^^^

.. automodule:: hamcrest.core.core.anyof
    :exclude-members: any_of
.. autofunction:: any_of(matcher1[, matcher2[, ...]])

anything
^^^^^^^^

.. automodule:: hamcrest.core.core.isanything
    :exclude-members: anything
.. autofunction:: anything([description])

is_not
^^^^^^

.. automodule:: hamcrest.core.core.isnot
