Decorator Matchers
------------------

Matchers that decorate other matchers for better expression.


described_as
^^^^^^^^^^^^

.. automodule:: hamcrest.core.core.described_as
    :exclude-members: described_as
.. autofunction:: described_as(description, matcher[, value1[, ...]])

is\_
^^^^

.. automodule:: hamcrest.core.core.is_
