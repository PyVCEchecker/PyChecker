from aldryn_search import receivers  # noqa @UnusedImport
