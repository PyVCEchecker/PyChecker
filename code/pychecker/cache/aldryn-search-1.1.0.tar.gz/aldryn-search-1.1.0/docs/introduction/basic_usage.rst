###########
Basic usage
###########

When using the CMS, you can create a django CMS page to hook the Aldryn Search application into.
In its *Advanced settings*, set its ``Application`` to *Aldryn Search*.

The page will now contain a basic search form that allows you to search against your configured
search backend.
