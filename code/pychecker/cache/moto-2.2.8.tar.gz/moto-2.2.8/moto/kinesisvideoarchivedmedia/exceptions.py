from __future__ import unicode_literals

# Not implemented exceptions for now
