def bytesize(val):
    return len(val.encode("utf-8"))
