from __future__ import unicode_literals
from .models import instance_metadata_backend

instance_metadata_backends = {"global": instance_metadata_backend}
