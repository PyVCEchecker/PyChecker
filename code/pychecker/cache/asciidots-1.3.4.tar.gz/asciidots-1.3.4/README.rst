I have tried for hours to get README.rst to work.

Just read it at https://github.com/aaronduino/asciidots/
