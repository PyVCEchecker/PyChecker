class DotsExit(SystemExit):
    pass
