def run():
    pass

class A(object):
    def run():
        pass

class B(object):
    def run():
        pass
