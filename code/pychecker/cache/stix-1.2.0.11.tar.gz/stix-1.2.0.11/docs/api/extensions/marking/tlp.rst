:mod:`stix.extensions.marking.tlp` Module
=========================================

.. module:: stix.extensions.marking.tlp

Classes
-------

.. autoclass:: TLPMarkingStructure
	:show-inheritance:
	:members:
