:mod:`stix.extensions.structured_coa.generic_structured_coa` Module
===================================================================

.. module:: stix.extensions.structured_coa.generic_structured_coa

Classes
-------

.. autoclass:: GenericStructuredCOA
	:show-inheritance:
	:members:
