:mod:`stix.extensions.marking.simple_marking` Module
====================================================

.. module:: stix.extensions.marking.simple_marking

Classes
-------

.. autoclass:: SimpleMarkingStructure
	:show-inheritance:
	:members:
