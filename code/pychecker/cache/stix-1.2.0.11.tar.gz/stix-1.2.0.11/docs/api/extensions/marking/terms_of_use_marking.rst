:mod:`stix.extensions.marking.terms_of_use_marking` Module
==========================================================

.. module:: stix.extensions.marking.terms_of_use_marking

Classes
-------

.. autoclass:: TermsOfUseMarkingStructure
	:show-inheritance:
	:members:
