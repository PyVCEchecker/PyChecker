:mod:`stix.common.statement` Module
===================================

.. module:: stix.common.statement

Classes
-------

.. autoclass:: Statement
	:show-inheritance:
	:members:
