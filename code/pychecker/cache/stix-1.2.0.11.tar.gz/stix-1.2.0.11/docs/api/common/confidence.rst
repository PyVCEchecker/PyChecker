:mod:`stix.common.confidence` Module
====================================

.. module:: stix.common.confidence

Classes
-------

.. autoclass:: Confidence
	:show-inheritance:
	:members:
