:mod:`stix.common.activity` Module
==================================

.. module:: stix.common.activity

Classes
-------

.. autoclass:: Activity
	:show-inheritance:
	:members:
