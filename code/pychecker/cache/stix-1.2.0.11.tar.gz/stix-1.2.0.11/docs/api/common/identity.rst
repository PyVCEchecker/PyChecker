:mod:`stix.common.identity` Module
==================================

.. module:: stix.common.identity

Classes
-------

.. autoclass:: Identity
	:show-inheritance:
	:members:

.. autoclass:: RelatedIdentities
	:show-inheritance:
	:members:
	
Functions
---------

.. autofunction:: add_extension

