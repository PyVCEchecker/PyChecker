:mod:`stix.common.information_source` Module
============================================

.. module:: stix.common.information_source

Classes
-------

.. autoclass:: InformationSource
	:show-inheritance:
	:members:

.. autoclass:: ContributingSources
	:show-inheritance:
	:members:
