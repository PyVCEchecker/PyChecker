:mod:`stix.common` Module
==================================

.. module:: stix.common

Classes
-------

.. autoclass:: EncodedCDATA
	:show-inheritance:
	:members:
