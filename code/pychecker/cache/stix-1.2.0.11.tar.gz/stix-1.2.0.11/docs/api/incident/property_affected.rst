:mod:`stix.incident.property_affected` Module
=============================================

.. module:: stix.incident.property_affected

Classes
-------

.. autoclass:: PropertyAffected
	:show-inheritance:
	:members:

.. autoclass:: NonPublicDataCompromised
	:show-inheritance:
	:members:
