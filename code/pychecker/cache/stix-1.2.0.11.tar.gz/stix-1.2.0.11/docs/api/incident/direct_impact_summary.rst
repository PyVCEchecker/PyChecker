:mod:`stix.incident.direct_impact_summary` Module
=================================================

.. module:: stix.incident.direct_impact_summary

Classes
-------

.. autoclass:: DirectImpactSummary
	:show-inheritance:
	:members:
