:mod:`stix.incident.impact_assessment` Module
=============================================

.. module:: stix.incident.impact_assessment

Classes
-------

.. autoclass:: ImpactAssessment
	:show-inheritance:
	:members:
