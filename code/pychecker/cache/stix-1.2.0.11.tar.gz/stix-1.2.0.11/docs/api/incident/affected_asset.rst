:mod:`stix.incident.affected_asset` Module
==========================================

.. module:: stix.incident.affected_asset

Classes
-------

.. autoclass:: AffectedAsset
	:show-inheritance:
	:members:

.. autoclass:: AssetType
	:show-inheritance:
	:members:
