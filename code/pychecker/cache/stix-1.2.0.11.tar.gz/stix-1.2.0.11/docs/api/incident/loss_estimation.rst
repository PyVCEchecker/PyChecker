:mod:`stix.incident.loss_estimation` Module
===========================================

.. module:: stix.incident.loss_estimation

Classes
-------

.. autoclass:: LossEstimation
	:show-inheritance:
	:members:
