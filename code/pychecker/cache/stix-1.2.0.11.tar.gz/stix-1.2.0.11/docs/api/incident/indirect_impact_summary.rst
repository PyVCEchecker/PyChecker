:mod:`stix.incident.indirect_impact_summary` Module
===================================================

.. module:: stix.incident.indirect_impact_summary

Classes
-------

.. autoclass:: IndirectImpactSummary
	:show-inheritance:
	:members:
