:mod:`stix.incident.external_id` Module
=======================================

.. module:: stix.incident.external_id

Classes
-------

.. autoclass:: ExternalID
	:show-inheritance:
	:members:
