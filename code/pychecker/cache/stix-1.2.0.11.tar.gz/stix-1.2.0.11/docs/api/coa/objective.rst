:mod:`stix.coa.objective` Module
==================================

.. module:: stix.coa.objective

Classes
-------

.. autoclass:: Objective
	:show-inheritance:
	:members:
