:mod:`stix.ttp.resource` Module
==================================

.. module:: stix.ttp.resource

Classes
-------

.. autoclass:: Resource
	:show-inheritance:
	:members:
