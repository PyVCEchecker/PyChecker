:mod:`stix.ttp.victim_targeting` Module
=======================================

.. module:: stix.ttp.victim_targeting

Classes
-------

.. autoclass:: VictimTargeting
	:show-inheritance:
	:members:
