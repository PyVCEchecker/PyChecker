:mod:`stix.ttp.behavior` Module
==================================

.. module:: stix.ttp.behavior

Classes
-------

.. autoclass:: Behavior
	:show-inheritance:
	:members:
