:mod:`stix.ttp.related_ttps` Module
===================================

.. module:: stix.ttp.related_ttps

Classes
-------

.. autoclass:: RelatedTTPs
	:show-inheritance:
	:members:
