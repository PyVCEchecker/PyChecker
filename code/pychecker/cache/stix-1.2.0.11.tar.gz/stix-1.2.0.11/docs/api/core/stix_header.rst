:mod:`stix.core.stix_header` Module
===================================

.. module:: stix.core.stix_header

Classes
-------

.. autoclass:: STIXHeader
	:show-inheritance:
	:members:
