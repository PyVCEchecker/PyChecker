:mod:`stix.core.ttps` Module
====================================

.. module:: stix.core.ttps

Classes
-------

.. autoclass:: TTPs
	:show-inheritance:
	:members:
