:mod:`stix.utils.nsparser` Module
==================================

.. module:: stix.utils.nsparser

Constants
---------

.. autodata:: NS_CAMPAIGN_OBJECT

.. autodata:: NS_CAPEC_OBJECT

.. autodata:: NS_CIQIDENTITY_OBJECT

.. autodata:: NS_COA_OBJECT

.. autodata:: NS_CVRF_OBJECT

.. autodata:: NS_ET_OBJECT

.. autodata:: NS_GENERICSTRUCTUREDCOA_OBJECT

.. autodata:: NS_GENERICTM_OBJECT

.. autodata:: NS_INCIDENT_OBJECT

.. autodata:: NS_INDICATOR_OBJECT

.. autodata:: NS_IOC_OBJECT

.. autodata:: NS_IOCTR_OBJECT

.. autodata:: NS_MARKING_OBJECT

.. autodata:: NS_OVALDEF_OBJECT

.. autodata:: NS_OVALVAR_OBJECT

.. autodata:: NS_REPORT_OBJECT

.. autodata:: NS_SIMPLEMARKING_OBJECT

.. autodata:: NS_SNORTTM_OBJECT

.. autodata:: NS_STIX_OBJECT

.. autodata:: NS_STIXCAPEC_OBJECT

.. autodata:: NS_STIXCIQADDRESS_OBJECT

.. autodata:: NS_STIXCVRF_OBJECT

.. autodata:: NS_STIXMAEC_OBJECT

.. autodata:: NS_STIXOPENIOC_OBJECT

.. autodata:: NS_STIXOVAL_OBJECT

.. autodata:: NS_STIXCOMMON_OBJECT

.. autodata:: NS_STIXVOCABS_OBJECT

.. autodata:: NS_TA_OBJECT

.. autodata:: NS_TLPMARKING_OBJECT

.. autodata:: NS_TOUMARKING_OBJECT

.. autodata:: NS_TTP_OBJECT

.. autodata:: NS_XAL_OBJECT

.. autodata:: NS_XNL_OBJECT

.. autodata:: NS_XPIL_OBJECT

.. autodata:: NS_YARATM_OBJECT
