:mod:`stix.utils` Module
==============================

.. module:: stix.utils

Functions
---------


.. autofunction:: is_cdata

.. autofunction:: strip_cdata

.. autofunction:: cdata

.. autofunction:: raise_warnings

.. autofunction:: silence_warnings

.. autofunction:: xml_bool



