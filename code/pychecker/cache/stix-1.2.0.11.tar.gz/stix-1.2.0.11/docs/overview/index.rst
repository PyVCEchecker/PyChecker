Overview
========

This page provides a quick overview needed to understand the inner workings
of the **python-stix** library. If you prefer a more hands-on approach, browse
the :doc:`/examples/index`.

.. toctree::
    :maxdepth: 2
    :titlesonly:
    :glob:

    id_namespaces
    controlled_vocabularies
