.. _acknowledgements:

Acknowledgements
=================
Many thanks to the following individuals for their support in the development of ``batman``:

- Jacob Bean
- Kevin Stevenson
- Ethan Kruse
- Geert Jan Talens
- Thomas Beatty
- Brett Morris
- Eric Agol
- Karl Fogel
- Jason Eastman
- Ian Crossfield
- Mark Omohundro
- Michael Hippke
- Hannu Parviainen
- Michael Zhang
- Andrew Mayo
- Heather Cegla
- Patricio Cubillos
- Sebastian Zieba
- Dan Hey
