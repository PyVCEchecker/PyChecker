.. _api:

API
===
.. module:: batman

.. autoclass:: batman.TransitParams
   :inherited-members:

.. autoclass:: batman.TransitModel
   :inherited-members:

