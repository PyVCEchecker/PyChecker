batman: Bad-Ass Transit Model cAlculatioN
=========================================

The ``batman`` package for Python makes super fast calculation of transit light curves easy.  Check out the docs at https://www.cfa.harvard.edu/~lkreidberg/batman/.
