Authors
=======

Mainteiner(s)
-------------

These people were/are mainteiners of this project.

-  2013-current `Colin Duquesnoy <https://github.com/ColinDuquesnoy>`__ - colin.duquesnoy@gmail.com - original author.

-  2018-current `Daniel Pizetta <https://github.com/dpizetta>`__ - daniel.pizetta@usp.br - bug fixes, improvements, features.

-  2019-current `Gonzalo Peña-Castellanos <https://github.com/goanpeca>`__ - bug fixes, improvements, features.

-  2019-current `Carlos Cordoba <https://github.com/ccordoba12>`__


Contributor(s)
--------------

These people contribute to bug fixes, improvements and so on. Please,
insert your information after the last one.

-  Year - Name - ``<contact>`` - contribution.

-  2018 - `mowoolli <https://github.com/mowoolli>`__ - bug fixes.
-  2018 - Xingyun Wu - ``xingyun.wu@foxmail.com`` - bug fixes.
-  2018 - `KcHNST <https://github.com/KcHNST>`__ - bug fixes.
-  2019 - `goanpeca <https://github.com/goanpeca>`__ - bug fixes, improvements, features.
-  2020 - `tsilia <https://github.com/tsilia>`__ - bug fixes.
-  2021 - `isabela-pf <https://github.com/isabela-pf>`__ - new palette design.
-  2021 - `juanis2112 <https://github.com/juanis2112>`__ - improvements.
-  2021 - `ccordoba12 <https://github.com/ccordoba12>`__ - mainteiner/improvements.

And all people that reported bugs, thank you all!
