Python Amazon Simple Product API
================================

.. automodule:: amazon.api
   :members:
