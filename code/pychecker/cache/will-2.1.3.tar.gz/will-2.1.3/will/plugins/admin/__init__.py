MODULE_DESCRIPTION = "Administrative actions"
