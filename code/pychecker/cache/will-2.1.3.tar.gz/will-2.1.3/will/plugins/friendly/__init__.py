MODULE_DESCRIPTION = "Old-fashioned friendliness"
