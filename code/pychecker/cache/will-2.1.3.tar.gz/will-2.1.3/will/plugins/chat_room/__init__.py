MODULE_DESCRIPTION = "HipChat actions"
