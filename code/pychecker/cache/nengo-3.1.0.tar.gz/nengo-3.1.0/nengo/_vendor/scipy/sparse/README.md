linalg_expm
-----------
This code for the matrix exponential is taken from `scipy.sparse`.
