from nengo.exceptions import MovedError


def probe_all(*args, **kwargs):
    """Moved to ``nengo_extras.probe``."""

    raise MovedError(location="nengo_extras.probe")
