*****************************
Semantic Pointer Architecture
*****************************

.. deprecated:: 3.0
   Use the `NengoSPA <https://www.nengo.ai/nengo-spa/>`_ project instead.
