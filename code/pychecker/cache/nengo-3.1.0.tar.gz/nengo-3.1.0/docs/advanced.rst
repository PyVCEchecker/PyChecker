***************
Advanced topics
***************

.. toctree::
   :maxdepth: 2

   connections
   nengorc
   improving-performance
   utils
