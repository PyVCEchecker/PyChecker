.. include:: ../CITATION.rst
