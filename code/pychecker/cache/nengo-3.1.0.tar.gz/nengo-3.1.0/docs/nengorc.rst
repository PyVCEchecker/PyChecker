*******************
Nengo configuration
*******************

.. highlight:: text

.. automodule:: nengo.rc
   :noindex:
