*******************
Project information
*******************

.. toctree::
   :maxdepth: 2

   changelog
   citation
   history
   converting
   license
