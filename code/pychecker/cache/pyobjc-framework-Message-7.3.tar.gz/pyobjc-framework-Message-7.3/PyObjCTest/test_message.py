import Message  # noqa: F401
from PyObjCTools.TestSupport import TestCase


class TestMessage(TestCase):
    pass
