drf-nested-routers
======================================

|build-status-image| |pypi-version|

Overview
--------

Nested resources for the Django Rest Framework

Documentation
-------------

Please see the README on the Github repo page: `<http://github.com/alanjds/drf-nested-routers/>`_

.. |build-status-image| image:: https://secure.travis-ci.org/alanjds/drf-nested-routers.svg?branch=master
   :target: http://travis-ci.org/alanjds/drf-nested-routers?branch=master
.. |pypi-version| image:: https://img.shields.io/pypi/v/drf-nested-routers.svg
   :target: https://pypi.python.org/pypi/drf-nested-routers
