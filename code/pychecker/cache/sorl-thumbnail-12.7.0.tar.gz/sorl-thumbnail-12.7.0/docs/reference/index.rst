*********
Reference
*********

.. toctree::
   :maxdepth: 2

   image
   settings

