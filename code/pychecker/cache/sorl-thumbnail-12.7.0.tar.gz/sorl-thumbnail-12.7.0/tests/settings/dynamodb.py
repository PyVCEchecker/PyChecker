from .default import *


THUMBNAIL_KVSTORE = 'sorl.thumbnail.kvstores.dynamodb_kvstore.KVStore'
THUMBNAIL_DYNAMODB_NAME = 'test'
AWS_REGION_NAME = 'eu-central-1'
AWS_ACCESS_KEY_ID = 'use'
AWS_SECRET_ACCESS_KEY = 'yours'
