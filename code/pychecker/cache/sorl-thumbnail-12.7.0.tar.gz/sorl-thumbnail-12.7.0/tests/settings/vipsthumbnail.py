from .default import *


THUMBNAIL_ENGINE = 'sorl.thumbnail.engines.vipsthumbnail_engine.Engine'
