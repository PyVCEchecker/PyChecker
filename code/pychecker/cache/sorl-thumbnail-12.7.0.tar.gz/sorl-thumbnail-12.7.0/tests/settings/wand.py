from .default import *


THUMBNAIL_ENGINE = 'sorl.thumbnail.engines.wand_engine.Engine'
