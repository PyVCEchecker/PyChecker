|Jazzband|

This is a `Jazzband <https://jazzband.co/>`__ project. By contributing
you agree to abide by the `Contributor Code of
Conduct <https://jazzband.co/about/conduct>`__ and follow the
`guidelines <https://jazzband.co/about/guidelines>`__.

.. |Jazzband| image:: https://jazzband.co/static/img/jazzband.svg
   :target: https://jazzband.co/
