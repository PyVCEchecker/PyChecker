from sorl.thumbnail.fields import ImageField
from sorl.thumbnail.shortcuts import get_thumbnail, delete

