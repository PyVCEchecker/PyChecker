from django.apps import AppConfig


class DynamicFormsetsConfig(AppConfig):
    name = 'djongo.dynamic_formsets'
    verbose_name = 'Dynamic Formsets'
