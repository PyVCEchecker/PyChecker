# This version of Djongo was made possible by
# the generous contributions from:
#
#       * Zachary Sizemore
#       * Wayne Van Son
#       * Norman Niemer
#       * Renz Ladia
#       * thestick613

__version__ = '1.3.3'
