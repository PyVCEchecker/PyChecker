[![Jazzband](https://jazzband.co/static/img/jazzband.svg)](https://jazzband.co/)

This is a [Jazzband](https://jazzband.co/) project. By contributing you agree to abide
by the [Contributor Code of Conduct](https://jazzband.co/about/conduct) and follow the
[guidelines](https://jazzband.co/about/guidelines).

If you'd like to contribute, simply fork 
[the repository](https://github.com/jazzband/tablib), commit your changes to a feature
branch, and send a pull request to `master`. Make sure you add yourself to
[AUTHORS](https://github.com/jazzband/tablib/blob/master/AUTHORS).
