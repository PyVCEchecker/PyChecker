Microsoft Azure CLI 'consumption' Command Module
================================================

This package is for the 'consumption' module.
i.e. 'az consumption'


