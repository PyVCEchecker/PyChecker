See the documentation: https://jeltef.github.io/PyLaTeX/latest/contributing.html
