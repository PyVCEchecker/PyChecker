===========
 dictutils
===========

.. automodule:: oslo_utils.dictutils
   :members:
