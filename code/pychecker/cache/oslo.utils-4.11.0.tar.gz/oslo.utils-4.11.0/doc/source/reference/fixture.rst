=============
 fixture
=============

.. automodule:: oslo_utils.fixture
   :members:
