=============
 secretutils
=============

.. automodule:: oslo_utils.secretutils
   :members: constant_time_compare
