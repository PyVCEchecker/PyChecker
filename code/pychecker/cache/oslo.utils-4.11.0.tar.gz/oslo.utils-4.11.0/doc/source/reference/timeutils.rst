===========
 timeutils
===========

.. automodule:: oslo_utils.timeutils
   :members:
   :special-members: __enter__, __exit__
