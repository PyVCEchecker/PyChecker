============
Installation
============

At the command line::

    $ pip install oslo.utils

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv oslo.utils
    $ pip install oslo.utils