def test_demo():
    x = 1
    y = 2
    assert (x
            >
            y), "oh noez, x <= y"
