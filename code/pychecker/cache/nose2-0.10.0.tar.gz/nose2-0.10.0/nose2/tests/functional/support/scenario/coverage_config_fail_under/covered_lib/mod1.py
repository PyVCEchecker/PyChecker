def covered_func():
    a = 1
    a = a + 8
    return a


def uncovered_func():
    b = 1
    b = b + 8
    return b
