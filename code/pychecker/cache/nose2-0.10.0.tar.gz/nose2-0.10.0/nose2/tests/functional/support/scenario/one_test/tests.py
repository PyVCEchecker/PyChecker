import nose2
import unittest


class Test(unittest.TestCase):

    def test(self):
        pass

if __name__ == '__main__':
    nose2.main()