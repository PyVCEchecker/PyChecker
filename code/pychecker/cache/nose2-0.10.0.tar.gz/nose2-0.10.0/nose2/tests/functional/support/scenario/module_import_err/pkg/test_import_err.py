raise ValueError('booms')

import unittest


def test():
    pass


class Test(unittest.TestCase):

    def test(self):
        pass
