import unittest


class TestDunderTest(unittest.TestCase):
    __test__ = False

    def test_a(self):
        pass
