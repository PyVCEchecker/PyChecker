import unittest


class Test(unittest.TestCase):

    def test(self):
        raise Exception("this should not execute")
