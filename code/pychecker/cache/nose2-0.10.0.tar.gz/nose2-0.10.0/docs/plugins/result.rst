======================
Reporting test results
======================

.. autoplugin :: nose2.plugins.result.ResultReporter
