=========
Profiling
=========

.. autoplugin :: nose2.plugins.prof.Profiler
