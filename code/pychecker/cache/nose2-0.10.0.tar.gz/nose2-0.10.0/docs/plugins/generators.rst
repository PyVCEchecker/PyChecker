=======================
Loader: Test Generators
=======================

.. autoplugin :: nose2.plugins.loader.generators.Generators
