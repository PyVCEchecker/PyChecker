===========================
Loader: Parameterized Tests
===========================

.. autoplugin :: nose2.plugins.loader.parameters.Parameters
