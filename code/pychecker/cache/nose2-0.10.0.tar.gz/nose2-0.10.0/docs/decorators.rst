==========
Decorators
==========

nose2 ships with various decorators that assist you to write your tests.

Setup & Teardown
================

.. autofunction :: nose2.tools.decorators.with_setup
.. autofunction :: nose2.tools.decorators.with_teardown