Plugin class reference
======================

The plugin system in nose2 is based on the plugin system in
unittest2's ``plugins`` branch.


Plugin base class
-----------------

.. autoclass :: nose2.events.Plugin
   :members:


Plugin interface classes
------------------------

.. autoclass :: nose2.events.PluginInterface
   :members:

.. autoclass :: nose2.events.Hook
   :members:
