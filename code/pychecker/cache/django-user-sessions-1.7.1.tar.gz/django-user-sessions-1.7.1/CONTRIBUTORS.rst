Repository owner:

* Bouke Haarsma

Contributors:

* Christopher Grebs
* roelwivion
* Tomasz Zieliński

Translators:

* Bashar Al-Abdulhadi
* elnappo
* joke2k
* Kunda
* mozillazg
