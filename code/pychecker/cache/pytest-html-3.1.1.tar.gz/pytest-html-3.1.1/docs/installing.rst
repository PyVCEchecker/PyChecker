Installation
============

Requirements
------------

pytest-html will work with Python >=3.6 or PyPy3.

Installing pytest-html
----------------------

To install pytest-html using `pip`_:

.. code-block:: bash

  $ pip install pytest-html

To install from source:

.. code-block:: bash

  $ pip install -e .

.. _pip: https://pip.pypa.io/
