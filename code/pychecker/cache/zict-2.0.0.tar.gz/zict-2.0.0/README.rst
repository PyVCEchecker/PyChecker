Zict
====

|Build Status|

Mutable Mapping interfaces.  See documentation_.

.. _documentation: http://zict.readthedocs.io/en/latest/
.. |Build Status| image:: https://travis-ci.org/dask/zict.svg?branch=master
   :target: https://travis-ci.org/dask/zict
