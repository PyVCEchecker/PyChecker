#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2016-5月26

@author: hustcc
'''


DEFAULT_LOCALE = 'en'  # default lang
