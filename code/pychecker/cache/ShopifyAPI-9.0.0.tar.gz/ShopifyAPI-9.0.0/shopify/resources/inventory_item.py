from ..base import ShopifyResource


class InventoryItem(ShopifyResource):
    pass
