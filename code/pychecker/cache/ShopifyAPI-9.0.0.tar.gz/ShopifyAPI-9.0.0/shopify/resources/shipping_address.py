from ..base import ShopifyResource


class ShippingAddress(ShopifyResource):
    pass
