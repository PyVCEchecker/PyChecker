from ..base import ShopifyResource


class Theme(ShopifyResource):
    pass
