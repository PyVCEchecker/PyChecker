from ..base import ShopifyResource


class Publication(ShopifyResource):
    pass
