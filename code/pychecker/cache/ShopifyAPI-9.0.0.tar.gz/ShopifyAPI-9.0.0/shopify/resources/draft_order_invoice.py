from ..base import ShopifyResource


class DraftOrderInvoice(ShopifyResource):
    pass
