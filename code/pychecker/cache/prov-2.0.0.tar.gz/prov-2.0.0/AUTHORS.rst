=======
Credits
=======

Development Lead
----------------

* `Trung Dong Huynh <http://about.me/dong.huynh>`__ (`@trungdong <https://twitter.com/trungdong/>`__)

Contributors
------------

* Satrajit Ghosh (:py:mod:`prov.serializers.provrdf` module)
* Lion Krischer (:py:mod:`prov.serializers.provxml` module and Python 3 support)
* Sam Millar
