============
Installation
============

At the command line::

    $ easy_install prov

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv prov
    $ pip install prov