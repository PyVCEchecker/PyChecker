VERSION = '9999.9.9'

error = """The ``fake-factory`` package is now called ``Faker``.

Please update your requirements.
"""
raise ImportError(error)
