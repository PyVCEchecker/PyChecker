============
Installation
============

At the command line::

    $ pip install debtcollector

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv debtcollector
    $ pip install debtcollector
