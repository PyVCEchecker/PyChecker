XStatic-Font-Awesome
--------------

Font Awesome icons packaged for setuptools (easy_install) / pip.

This package is intended to be used by **any** project that needs these files.

It intentionally does **not** provide any extra code except some metadata
**nor** has any extra requirements. You MAY use some minimal support code from
the XStatic base package, if you like.

You can find more info about the xstatic packaging way in the package `XStatic`.

