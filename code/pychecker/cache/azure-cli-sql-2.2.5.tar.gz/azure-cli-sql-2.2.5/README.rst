Microsoft Azure CLI 'SQL' Command Module
========================================

