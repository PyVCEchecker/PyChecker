"""
Tests for XBlock
"""
