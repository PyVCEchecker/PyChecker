"""
Tests for Django integration with XBlock
"""
