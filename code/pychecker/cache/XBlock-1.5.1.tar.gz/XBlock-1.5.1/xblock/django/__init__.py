"""
Contains utilities for integrating XBlock with Django.
"""
