# flake8: noqa
# `g2_primatives.py` was a typo of `g2_primitives.py`
# Make an alias for backward compatibility
from py_ecc.bls.g2_primitives import *
