## shim readme clean to simplify vendorizing of readme.rst
clean = lambda x:x
