
"""
A sample unimportable module
"""

raise ImportError()

__version__ = "0.1"
