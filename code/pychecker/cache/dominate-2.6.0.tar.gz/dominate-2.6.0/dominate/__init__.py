from ._version import __version__
version = __version__

from .document import document
