Internal API Reference
----------------------

### `encoding`

```eval_rst
.. automodule:: ipfsapi.encoding
    :members:
    :show-inheritance:

```

### `http`

```eval_rst
.. automodule:: ipfsapi.http
    :members:
    :show-inheritance:

```

### `multipart`

```eval_rst
.. automodule:: ipfsapi.multipart
    :members:
    :show-inheritance:

```

### `utils`

```eval_rst
.. automodule:: ipfsapi.utils
    :members:
    :show-inheritance:

```
