============
Installation
============

parsy can be installed with pip::

    pip install parsy


Python 3.3 or greater is required.

