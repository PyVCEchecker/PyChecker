RemotePyInterpreter

RemotePyInterpreter is a full featured out of process
Python interpreter in a NSTextView.

The source of this application demonstrates
- Advanced usage of NSTextView
- Text completion (Only in OS X 10.3)
- Asynchronous TCP networking with NSFileHandle
- One crazy repr/eval-based IPC protocol

Bob Ippolito
bob@redivi.com
