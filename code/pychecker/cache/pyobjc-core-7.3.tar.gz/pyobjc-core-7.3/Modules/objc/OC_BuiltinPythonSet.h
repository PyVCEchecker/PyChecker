#import "pyobjc.h"

@interface OC_BuiltinPythonSet : OC_PythonSet {
}
@end
