#import "pyobjc.h"
#import "OC_PythonData.h"

@interface OC_BuiltinPythonData : OC_PythonData {
}
@end
