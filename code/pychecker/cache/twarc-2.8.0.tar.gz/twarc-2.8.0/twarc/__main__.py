from twarc.command2 import twarc2

if __name__ == "__main__":
    twarc2(prog_name="python -m twarc2")
