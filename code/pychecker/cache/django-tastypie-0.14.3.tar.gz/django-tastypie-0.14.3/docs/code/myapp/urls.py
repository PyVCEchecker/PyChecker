from tastypie.api import Api


my_api = Api()
