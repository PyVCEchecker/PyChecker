from .admin import ImageCroppingMixin
from .fields import ImageCropField, ImageRatioField
from .widgets import ImageCropWidget

__version__ = "1.6.1"
