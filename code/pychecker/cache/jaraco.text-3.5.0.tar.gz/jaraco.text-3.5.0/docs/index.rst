Welcome to |project| documentation!
===================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: jaraco.text
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

