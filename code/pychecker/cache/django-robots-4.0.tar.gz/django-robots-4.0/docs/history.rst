.. _history:

=======
History
=======

.. include:: ../CHANGES.rst
    :start-line: 5
