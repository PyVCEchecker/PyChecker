import nameko.cli.main


if __name__ == "__main__":
    nameko.cli.main.main()
