.. _getting_in_touch:

Getting in touch
================

If you have questions for the Nameko community or developers, there are a number of ways to get in touch:

GitHub
------

To raise a bug or issue against the project, visit the `GitHub <https://github.com/nameko/nameko>`_ page.

Mailing list
------------

For help, comments or questions, please use the `mailing list
<https://groups.google.com/forum/#!forum/nameko-dev>`_ on google groups.
