License
=======

Nameko is licensed under the Apache License, Version 2.0. Please see LICENSE in the project root for details.
