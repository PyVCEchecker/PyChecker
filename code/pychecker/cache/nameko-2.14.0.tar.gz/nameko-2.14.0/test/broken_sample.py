import non_existent  # noqa: F401
