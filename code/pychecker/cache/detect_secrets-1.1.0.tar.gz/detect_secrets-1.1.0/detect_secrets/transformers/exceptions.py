class ParsingError(ValueError):
    """Generalized parsing error raised by transformers."""
    pass
