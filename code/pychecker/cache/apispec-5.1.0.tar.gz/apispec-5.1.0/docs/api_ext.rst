Built-in Plugins
================

apispec.ext.marshmallow
-----------------------

.. automodule:: apispec.ext.marshmallow
    :members:

apispec.ext.marshmallow.schema_resolver
+++++++++++++++++++++++++++++++++++++++

.. automodule:: apispec.ext.marshmallow.schema_resolver
    :members:

apispec.ext.marshmallow.openapi
+++++++++++++++++++++++++++++++

.. automodule:: apispec.ext.marshmallow.openapi
    :members:

apispec.ext.marshmallow.field_converter
+++++++++++++++++++++++++++++++++++++++

.. automodule:: apispec.ext.marshmallow.field_converter
    :members:

apispec.ext.marshmallow.common
++++++++++++++++++++++++++++++
.. automodule:: apispec.ext.marshmallow.common
    :members:
