*******
Authors
*******

Leads
=====

- Steven Loria `@sloria <https://github.com/sloria>`_
- Jérôme Lafréchoux `@lafrech <https://github.com/lafrech>`_

Contributors (chronological)
============================

- Josh Johnston `@Trii <https://github.com/Trii>`_
- Vlad Frolov `@frol <https://github.com/frol>`_
- Josh Carp `@jmcarp <https://github.com/jmcarp>`_
- Andrew Pashkin `@AndrewPashkin <https://github.com/AndrewPashkin>`_
- João Taveira Araújo `@jta <https://github.com/jta>`_
- Giacomo Tagliabue `@itajaja <https://github.com/itajaja>`_
- Ben Beadle `@benbeadle <https://github.com/benbeadle>`_
- Martin Latrille `@martinlatrille <https://github.com/martinlatrille>`_
- Lucas Costa `@lucascosta <https://github.com/lucascosta>`_
- Jared Deckard `@deckar01 <https://github.com/deckar01>`_
- Eric Bobbitt `@ericb <https://github.com/ericb>`_
- Nick Phillips `@incognick <https://github.com/incognick>`_
- Ashish Ranjan `@ranjanashish <https://github.com/ranjanashish>`_
- Jérôme Lafréchoux `@lafrech <https://github.com/lafrech>`_
- Anders Steinlein `@asteinlein <https://github.com/asteinlein>`_
- Yuri Heupa `@YuriHeupa <https://github.com/YuriHeupa>`_
- Matija Besednik `@matijabesednik <https://github.com/matijabesednik>`_
- Boris Serebrov `@serebrov <https://github.com/serebrov>`_
- Daniel Radetsky `@dradetsky <https://github.com/dradetsky>`_
- Lucas Coutinho `@lucasrc <https://github.com/lucasrc>`_
- `@lamiskin <https://github.com/lamiskin>`_
- Florian Scheffler `@nebularazer <https://github.com/nebularazer>`_
- Yoichi NAKAYAMA `@yoichi <https://github.com/yoichi>`_
- Vadim Radovel `@NightBlues <https://github.com/NightBlues>`_
- Douglas Anderson `@djanderson <https://github.com/djanderson>`_
- Marat Sharafutdinov `@decaz <https://github.com/decaz>`_
- Daniel Radetsky `@dradetsky <https://github.com/dradetsky>`_
- Evgeny Seliverstov `@theirix <https://github.com/theirix>`_
- Michael Bangert `@Bangertm <https://github.com/Bangertm>`_
- Bastien Sevajol `@buxx <https://github.com/buxx>`_
- Durmus Karatay `@ukaratay <https://github.com/ukaratay>`_
- Julien Danjou `@jd <https://github.com/jd>`_
- Daisuke Taniwaki `@dtaniwaki <https://github.com/dtaniwaki>`_
- `@mathewmarcus <https://github.com/mathewmarcus>`_
- Louis-Philippe Huberdeau `@lphuberdeau <https://github.com/lphuberdeau>`_
- Urban `@UrKr <https://github.com/UrKr>`_
- Christina Long `@cvlong <https://github.com/cvlong>`_
- Felix Yan `@felixonmars <https://github.com/felixonmars>`_
- Guoli Lyu `@Guoli-Lyu <https://github.com/Guoli-Lyu>`_
- Laura Beaufort `@lbeaufort <https://github.com/lbeaufort>`_
- Marcin Lulek `@ergo <https://github.com/ergo>`_
- Jonathan Beezley `@jbeezley <https://github.com/jbeezley>`_
- David Stapleton `@dstape <https://github.com/DStape>`_
- Szabolcs Blága `@blagasz <https://github.com/blagasz>`_
- Andrew Johnson `@andrjohn <https://github.com/andrjohn>`_
- Dave `@zedrdave <https://github.com/zedrdave>`_
- Emmanuel Valette `@karec <https://github.com/karec/>`_
- Hugo van Kemenade `@hugovk <https://github.com/hugovk>`_
- Bastien Gerard `@bagerard <https://github.com/bagerard>`_
- Ashutosh Chaudhary `@codeasashu <https://github.com/codeasashu>`_
- Fedor Fominykh `@fedorfo <https://github.com/fedorfo>`_
- Colin Bounouar `@Colin-b <https://github.com/Colin-b>`_
- Mikko Kortelainen `@kortsi <https://github.com/kortsi>`_
- David Bishop `@teancom <https://github.com/teancom>`_
- Andrea Ghensi `@sanzoghenzo <https://github.com/sanzoghenzo>`_
- `@timsilvers <https://github.com/timsilvers>`_
- Kangwook Lee `@pbzweihander <https://github.com/pbzweihander>`_
- Martijn Pieters `@mjpieters <https://github.com/mjpieters>`_
- Duncan Booth `@kupuguy <https://github.com/kupuguy>`_
- Luke Whitehorn `<https://github.com/Anti-Distinctlyminty>`_
- François Magimel `<https://github.com/Linkid>`_
- Stefan van der Walt `<https://github.com/stefanv>`_
