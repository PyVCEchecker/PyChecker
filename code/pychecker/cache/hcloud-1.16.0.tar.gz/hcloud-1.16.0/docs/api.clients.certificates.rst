CertificateClient
==================


.. autoclass:: hcloud.certificates.client.CertificatesClient
    :members:

.. autoclass:: hcloud.certificates.client.BoundCertificate
    :members:

.. autoclass:: hcloud.certificates.domain.Certificate
    :members:

