Microsoft Azure CLI 'resource' Command Module
=============================================

This package is for the 'resource' module.
i.e. 'az resource'


