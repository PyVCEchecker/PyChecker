pytest-selenium
===============

pytest-selenium is a plugin for `pytest <http://pytest.org>`_ that provides
support for running `Selenium <http://seleniumhq.org/>`_ based tests.

.. toctree::
   :maxdepth: 2

   installing
   user_guide
   development
   news
