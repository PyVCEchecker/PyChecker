def mock_refresh(self):
    self.user_info = {"iden": "123"}
    self.devices = []
    self.chats = []
    self.channels = []
