"""Definition of all Allwinner chips"""
