.. _releases:

.. include:: ../CHANGELOG.rst
