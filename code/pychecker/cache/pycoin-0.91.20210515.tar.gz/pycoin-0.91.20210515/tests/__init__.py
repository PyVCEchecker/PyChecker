import doctest


def load_tests(loader, tests, ignore):
    #tests.addTests(doctest.DocTestSuite(pycoin.tx.script.microcode))
    return tests
