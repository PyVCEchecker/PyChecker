from .satoshi_streamer import SATOSHI_STREAMER

parse_struct = SATOSHI_STREAMER.parse_struct
parse_as_dict = SATOSHI_STREAMER.parse_as_dict
stream_struct = SATOSHI_STREAMER.stream_struct
pack_struct = SATOSHI_STREAMER.pack_struct
