class ValidationFailureError(Exception):
    pass


class BadSpendableError(Exception):
    pass
