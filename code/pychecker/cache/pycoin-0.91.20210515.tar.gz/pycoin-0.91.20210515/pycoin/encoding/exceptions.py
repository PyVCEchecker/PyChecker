class EncodingError(ValueError):
    pass
