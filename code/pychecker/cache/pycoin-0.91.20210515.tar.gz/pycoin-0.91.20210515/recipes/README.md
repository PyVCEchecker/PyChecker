These recipes include some command-line utilities written with many comments
and designed to be easy to follow. You can use them as a template for your own
code.