Recipes
================

These recipes include some command-line utilities written with many comments
and designed to be easy to follow. You can use them as a template for your own
code.

For now, look at the source code and its comments on `github <https://github.com/richardkiss/pycoin/tree/master/recipes/multisig>`_.
