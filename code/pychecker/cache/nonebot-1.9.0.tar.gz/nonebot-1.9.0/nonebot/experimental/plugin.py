from nonebot.plugin import on_command, on_natural_language


# backward compatibility
__all__ = [
    'on_command',
    'on_natural_language'
]
