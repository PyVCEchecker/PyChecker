from aiocqhttp import Error as CQHttpError

__all__ = [
    'CQHttpError',
]
