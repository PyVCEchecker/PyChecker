Welcome to pudb's documentation!
================================

.. include:: README.rst

Table of Contents
-----------------

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    starting
    usage
    shells
    misc
    🚀 Github <https://github.com/inducer/pudb>
    💾 Download Releases <https://pypi.org/project/pudb>

Indices and Tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
