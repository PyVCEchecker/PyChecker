from django.apps import AppConfig


class OpbeatConfig(AppConfig):
    name = 'opbeat.contrib.django'
    label = 'opbeat.contrib.django'
    verbose_name = 'Opbeat'
