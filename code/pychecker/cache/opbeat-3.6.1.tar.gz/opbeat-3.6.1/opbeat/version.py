__version__ = (3, 6, 1)
VERSION = '.'.join(map(str, __version__))
