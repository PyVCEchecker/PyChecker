# -*- coding: utf-8 -*-

from opbeat.transport.http import AsyncHTTPTransport, HTTPTransport


default = [HTTPTransport, AsyncHTTPTransport]
