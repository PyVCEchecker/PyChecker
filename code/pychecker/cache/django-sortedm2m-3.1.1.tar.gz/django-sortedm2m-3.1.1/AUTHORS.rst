Author
------

* Gregor Müllegger <gregor@muellegger.de>

Contributors
------------

* Alex Mannhold <NinjaDero@users.noreply.github.com>
* Antti Kaihola <akaihol+github@ambitone.com>
* Asif Saif Uddin <auvipy@gmail.com>
* Ben Thompson <benjaminpearce@gmail.com>
* Camilo Nova <camilo.nova@gmail.com>
* Chris Church <chris@ninemoreminutes.com>
* Christian Kohlstedde <christian@kohlsted.de>
* Clinton Blackburn <clinton.blackburn@gmail.com>
* Conrad Kramer <conrad@kramerapps.com>
* David Evans <d@drhevans.com>
* Dayne May <dmay@aio-tv.com>
* Edward Betts <edward@4angle.com>
* Federico Capoano <nemesis@ninux.org>
* Flavio Curella <flavio.curella@gmail.com>
* Florian Ilgenfritz <flo.ilgenfritz@txtr.com>
* Frankie Dintino <fdintino@gmail.com>
* Jannis Leidel <jannis@leidel.info>
* Jasper Maes <jaspermaes.jm@gmail.com>
* Joaquin Perez <mondongo@gmail.com>
* Jonathan Liuti <liuti.john@gmail.com>
* Jonny <jonny@swerveconcepts.com>
* Maarten Draijer <maarten@madra.nl>
* MadEng84 <gaetanodonghia@gmail.com>
* Marcin Ossowski <marcin.ossowski@gmail.com>
* Michal <michal@maithu.com>
* Mike Knoop <mikeknoop@gmail.com>
* Mystic-Mirage <mm@m10e.net>
* Nicolas Trésegnie <nicolas.tresegnie@gmail.com>
* Patryk Hes <patryk.hes@laboratorium.ee>
* Quantum <quantum2048@gmail.com>
* Richard Barran <richard@arbee-design.co.uk>
* Richard Mitchell <richard.j.mitchell@gmail.com>
* Rohith Asrk <rohith.asrk@gmail.com>
* Roland Geider <roland@geider.net>
* Ruben Diaz <outime@gmail.com>
* Rubén Díaz <outime@users.noreply.github.com>
* Ryszard Knop <dragoon@dragonic.eu>
* Rémy HUBSCHER <hubscher.remy@gmail.com>
* Scott Kyle <scott@appden.com>
* Sean O'Connor <sean@seanoc.com>
* Tipuch <fiorini751@gmail.com>
* Vadim Sikora <vadim.sikora@divio.ch>
* cuchac <cuchac@email.cz>
* erm0l0v <erm0l0v@ya.ru>
* hstanev <hstanev@gmail.com>
* jonny5532 <jonny@magicstring.co.uk>
* smcoll <smcoll@gmail.com>
* xavier <xavier@mutualit.org>
