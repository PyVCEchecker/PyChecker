"""
Should emit:
B016 - on lines 6, 7, and 8
"""

raise False
raise 1
raise "string"
raise Exception(False)
raise Exception(1)
raise Exception("string")
