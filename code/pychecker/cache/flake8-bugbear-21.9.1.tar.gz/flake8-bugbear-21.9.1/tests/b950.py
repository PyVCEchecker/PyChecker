# Assumes the default allowed line length of 79

"line is fine"
"                              line               is           fine          "
"                              line               is        still fine          "
"                              line               is    no longer fine by any measures, yup"
"line is fine again"
