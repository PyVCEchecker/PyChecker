class DiagnosticEvent(object):
    pass

PeekReward = DiagnosticEvent()
