ATC Thrift
==========

ATC Thrift is `Augmented Traffic Control` (ATC) Thrift Library

`atc_thrift.thrift` contains the description of the atc_thrift interface.
Change to the API should be made in this file and the client/server code should
be regenerated using:
  make
