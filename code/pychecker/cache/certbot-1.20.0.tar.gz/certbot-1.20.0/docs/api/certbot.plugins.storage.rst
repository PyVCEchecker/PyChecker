certbot.plugins.storage module
==============================

.. automodule:: certbot.plugins.storage
    :members:
    :undoc-members:
    :show-inheritance:
