certbot.compat.os module
========================

.. automodule:: certbot.compat.os
    :members: chmod, umask, chown, open, mkdir, makedirs, rename, replace, access, stat, fstat
