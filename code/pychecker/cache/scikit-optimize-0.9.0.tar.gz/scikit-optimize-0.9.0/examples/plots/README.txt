.. _plots_examples:

Plotting functions
------------------

Examples concerning the :mod:`skopt.plots` module.
