.. currentmodule:: skopt.learning

.. _learning:

Learning
========
Machine learning extensions for model-based optimization.