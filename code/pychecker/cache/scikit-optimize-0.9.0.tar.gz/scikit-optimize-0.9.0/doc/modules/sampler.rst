.. currentmodule:: skopt.sampler

.. _sampler:

Sampling methods
================
