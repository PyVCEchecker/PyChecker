.. currentmodule:: skopt.space.transformers

.. _transformers:

Transformers
============

