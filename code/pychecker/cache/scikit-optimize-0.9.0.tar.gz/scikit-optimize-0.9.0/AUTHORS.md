# Contributors

Scikit-Optimize is a community effort. Contributors include, in alphabetical order:

* [andreh7][andreh7]
* [Nuno Campos][nfcampos]
* [Mehdi Cherti][mehdidc]
* [Alexander Fabisch][AlexanderFabisch]
* [Thomas Fan][thomasjpfan]
* [Tim Head][betatim]
* [Manoj Kumar][mechcoder]
* [Gilles Louppe][glouppe]
* [Katie Malone][cmmalone]
* [Holger Nahrstaedt][holgern]
* [nel215][nel215]
* [Mikhail Pak][mp4096]
* [Iaroslav Shcherbatyi](iaroslav-ai)
* [Taylor Smith][jtsmith2]
* [Zé Vinícius][mirca]

The scikit-optimize logo was a contribution by
[Jeremy Anderson][objectadjective] and **Rose Peng**.

[AlexanderFabisch]: https://github.com/AlexanderFabisch
[mehdidc]: https://github.com/mehdidc
[nfcampos]: https://github.com/nfcampos
[betatim]: https://github.com/betatim
[mechcoder]: https://github.com/MechCoder
[glouppe]: https://github.com/glouppe
[cmmalone]: https://github.com/cmmalone
[nel215]: https://github.com/nel215
[objectadjective]: https://github.com/objectadjective
[jtsmith2]: https://github.com/jtsmith2
[andreh7]: https://github.com/andreh7
[mp4096]: https://github.com/mp4096
[thomasjpfan]: https://github.com/thomasjpfan
[mirca]: http://mirca.github.io/
[iaroslav-ai]: http://iaroslav-ai.github.io/
[holgern]: https://github.com/holgern
