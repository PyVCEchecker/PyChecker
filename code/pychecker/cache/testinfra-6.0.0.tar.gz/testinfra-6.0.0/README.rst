##################################
Testinfra test your infrastructure
##################################

This package is just a transitional package for https://github.com/pytest-dev/philpep you should install pytest-testinfra instead.
