# RENAME THIS FILE TO local_settings.py IF YOU NEED TO CUSTOMIZE SOME SETTINGS
# BUT DO NOT COMMIT

TEST_PERFORMANCE = True

# DATABASES = {
#    'default': {
#        'ENGINE': 'django.contrib.gis.db.backends.postgis',
#        'NAME': 'django_restframework_gis',
#        'USER': 'postgres',
#        'PASSWORD': 'password',
#        'HOST': '127.0.0.1',
#        'PORT': '5433'
#    },
# }
#
# INSTALLED_APPS = (
#    'django.contrib.auth',
#    'django.contrib.contenttypes',
#    'django.contrib.sessions',
#    'django.contrib.messages',
#    'django.contrib.staticfiles',
#    'django.contrib.gis',
#
#    # geodjango widgets
#    # admin
#    #'grappelli',
#    'django.contrib.admin',
#
#    # rest framework
#    'rest_framework',
#    'rest_framework_gis',
#
#    # test app
#    'django_restframework_gis_tests'
# )
