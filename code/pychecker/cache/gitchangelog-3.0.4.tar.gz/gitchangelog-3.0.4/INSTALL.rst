INSTALL
=======

If you downloaded the code from git:

    ./autogen.sh &&
    python setup.py install


