"""A dummy test module #2."""
