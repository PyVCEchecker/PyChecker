QUEUE_WAIT = 60  # seconds
