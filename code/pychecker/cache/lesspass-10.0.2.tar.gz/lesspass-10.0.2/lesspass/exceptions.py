class ExcludeAllCharsAvailable(Exception):
    pass
