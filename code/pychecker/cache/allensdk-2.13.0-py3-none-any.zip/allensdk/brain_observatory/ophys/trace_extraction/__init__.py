import warnings

warnings.warn("trace_extraction functionality has been moved from AllenSDK "
              "to https://github.com/AllenInstitute/ophys_etl_pipelines ."
              "The functionality in this AllenSDK package will be removed "
              "in v3.0.0.",
              category=DeprecationWarning,
              stacklevel=2)
