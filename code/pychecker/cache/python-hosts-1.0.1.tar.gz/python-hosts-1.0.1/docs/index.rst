============
python hosts
============

A python library for managing a hosts file.


Getting started
---------------

.. toctree::
   :maxdepth: 3

   installation
   usage


API
---

.. toctree::
   :maxdepth: 3

   python_hosts


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

