python_hosts.exception module
=============================

.. automodule:: python_hosts.exception
    :members:
    :undoc-members:
    :show-inheritance:
