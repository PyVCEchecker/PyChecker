Installation
============
*Using pip package manager*

    $ pip install python-hosts

*From source*

|    $ git clone https://github.com/jonhadfield/python-hosts
|    $ cd python-hosts
|    $ python setup.py install
|
