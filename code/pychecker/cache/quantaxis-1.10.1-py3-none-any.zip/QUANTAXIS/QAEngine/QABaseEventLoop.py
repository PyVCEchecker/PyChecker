# 

import asyncio


class QABaseEventLoop(asyncio.AbstractEventLoop):
    def __init__(self):
        pass