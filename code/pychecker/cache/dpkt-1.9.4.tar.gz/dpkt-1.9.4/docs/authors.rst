*******
Authors
*******

.. include:: ../AUTHORS

If you want to contribute to dpkt, see :doc:`contributing`.
