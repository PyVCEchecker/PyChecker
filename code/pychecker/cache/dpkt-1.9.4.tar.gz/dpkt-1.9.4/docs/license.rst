
License
=======
BSD 3-Clause License, as the upstream project
