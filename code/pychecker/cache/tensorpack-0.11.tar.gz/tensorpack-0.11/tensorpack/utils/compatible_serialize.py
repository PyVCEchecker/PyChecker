from .serialize import loads, dumps  # noqa

# keep this file for BC
