# -*- coding: utf-8 -*-
# File: model_desc.py


from ..train.model_desc import ModelDesc, ModelDescBase  # kept for BC # noqa


__all__ = []
