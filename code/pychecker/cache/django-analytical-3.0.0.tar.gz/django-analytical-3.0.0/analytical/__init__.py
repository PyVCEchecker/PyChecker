"""
Analytics service integration for Django projects
"""

__author__ = "Joost Cassee"
__email__ = "joost@cassee.net"
__version__ = "3.0.0"
__copyright__ = "Copyright (C) 2011-2020 Joost Cassee and contributors"
__license__ = "MIT"
