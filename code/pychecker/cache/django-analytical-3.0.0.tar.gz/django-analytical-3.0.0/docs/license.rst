=======
License
=======

The django-analytical package is distributed under the `MIT License`_.
The complete license term are included below.  The copyright of the
integration code snippets of individual services rest solely with the
respective service providers.

.. _`MIT License`: http://en.wikipedia.org/wiki/MIT_License


License terms
=============

.. include:: ../LICENSE.txt
