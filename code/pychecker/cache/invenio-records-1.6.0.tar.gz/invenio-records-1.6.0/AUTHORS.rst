..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alizee Pace
- Diego Rodriguez Rodriguez
- Esteban J. G. Gabancho
- Harris Tzovanakis
- Jacopo Notarstefano
- Jan Aage Lavik
- Javier Delgado
- Javier Martin Montull
- Jiri Kuncar
- Jose Benito Gonzalez Lopez
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Nicola Tarocco
- Nicolas Harraudeau
- Orestis Melkonian
- Paulina Lach
- Rémi Ducceschi
- Sami Hiltunen
- Tibor Simko
- Maximilian Moser
