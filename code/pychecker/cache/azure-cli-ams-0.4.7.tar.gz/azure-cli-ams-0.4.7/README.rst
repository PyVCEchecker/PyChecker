Microsoft Azure CLI 'ams' Command Module
============================================

This package is for the 'ams' module.
i.e. 'az ams'


