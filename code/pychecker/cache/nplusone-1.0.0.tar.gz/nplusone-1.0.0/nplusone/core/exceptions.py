# -*- coding: utf-8 -*-

class NPlusOneError(Exception):
    pass
