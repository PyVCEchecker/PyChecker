############
API examples
############

.. toctree::
   :maxdepth: 1

   gl_objects/access_requests
   gl_objects/appearance
   gl_objects/applications
   gl_objects/emojis
   gl_objects/badges
   gl_objects/branches
   gl_objects/clusters
   gl_objects/messages
   gl_objects/commits
   gl_objects/deploy_keys
   gl_objects/deploy_tokens
   gl_objects/deployments
   gl_objects/discussions
   gl_objects/environments
   gl_objects/events
   gl_objects/epics
   gl_objects/features
   gl_objects/geo_nodes
   gl_objects/groups
   gl_objects/issues
   gl_objects/keys
   gl_objects/boards
   gl_objects/labels
   gl_objects/notifications
   gl_objects/mrs
   gl_objects/mr_approvals
   gl_objects/milestones
   gl_objects/namespaces
   gl_objects/notes
   gl_objects/packages
   gl_objects/pagesdomains
   gl_objects/personal_access_tokens
   gl_objects/pipelines_and_jobs
   gl_objects/projects
   gl_objects/project_access_tokens
   gl_objects/protected_branches
   gl_objects/releases
   gl_objects/runners
   gl_objects/remote_mirrors
   gl_objects/repositories
   gl_objects/repository_tags
   gl_objects/search
   gl_objects/settings
   gl_objects/snippets
   gl_objects/system_hooks
   gl_objects/templates
   gl_objects/todos
   gl_objects/users
   gl_objects/variables
   gl_objects/sidekiq
   gl_objects/wikis
