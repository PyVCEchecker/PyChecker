``path.py`` has been renamed to `path <https://pypi.org/project/path>`_.
