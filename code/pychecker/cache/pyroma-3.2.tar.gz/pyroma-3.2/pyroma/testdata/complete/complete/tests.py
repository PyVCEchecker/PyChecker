import unittest


class PackageDataTest(unittest.TestCase):
    def test_test(self):
        # Stop pyflakes from compaining:
        pass
