default_app_config = 'django_jinja.apps.DjangoJinjaAppConfig'
