
__version_tuple__ = (0, 5, 2)
__version__ = '0.5.2'
__version_tuple_js__ = (0, 5, 2)
__version_js__ = '0.5.2'
__version_threejs__ = '0.91' # kept for embedding in offline mode, we don't care about the patch version since it should be compatible