🚨🚨🚨 The pydocumentdb package for versions 1.x and 2.x of the Azure Cosmos DB Python SDK for SQL API will be retired August 20, 2020.
See the [release and retirement documentation](https://docs.microsoft.com/en-us/azure/cosmos-db/sql-api-sdk-python#release--retirement-dates) for more information.

Please use the latest version of the Python SDK with new package name, [azure-cosmos](https://pypi.org/project/azure-cosmos/).🚨🚨🚨