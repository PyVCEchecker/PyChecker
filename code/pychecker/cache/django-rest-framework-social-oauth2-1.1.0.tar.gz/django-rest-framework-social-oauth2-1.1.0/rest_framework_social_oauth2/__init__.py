"""python-social-auth and oauth2 support for django-rest-framework"""
__version__ = "1.1.0"


