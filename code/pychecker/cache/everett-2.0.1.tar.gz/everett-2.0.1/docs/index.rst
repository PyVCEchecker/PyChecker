.. include:: ../README.rst


Contents
========

.. toctree::
   :maxdepth: 2

   configuration
   components
   documenting
   testing
   recipes
   api
   history
   dev


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

