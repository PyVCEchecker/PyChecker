=======
Testing
=======

Often you want to adjust configuration in your tests. Everett
facilitates testing by providing an override mechanism.

.. autofunction:: everett.manager.config_override
   :noindex:
