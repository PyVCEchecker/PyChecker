JOSE protocol implementation in Python using cryptography

.. image:: https://github.com/certbot/josepy/actions/workflows/check.yaml/badge.svg
  :target: https://github.com/certbot/josepy/actions/workflows/check.yaml

.. image:: https://codecov.io/gh/certbot/josepy/branch/master/graph/badge.svg
  :target: https://codecov.io/gh/certbot/josepy

.. image:: https://readthedocs.org/projects/josepy/badge/?version=latest
  :target: http://josepy.readthedocs.io/en/latest/?badge=latest

Originally developed as part of the ACME_ protocol implementation.

.. _ACME: https://pypi.python.org/pypi/acme
