JSON Web Signature
------------------

.. automodule:: josepy.jws
   :members:
