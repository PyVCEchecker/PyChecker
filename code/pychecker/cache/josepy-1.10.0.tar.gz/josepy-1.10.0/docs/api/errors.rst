Errors
------

.. automodule:: josepy.errors
   :members:
