JSON Web Algorithms
-------------------

.. automodule:: josepy.jwa
   :members:
