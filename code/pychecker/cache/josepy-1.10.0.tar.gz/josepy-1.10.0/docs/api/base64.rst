JOSE Base64
-----------

.. automodule:: josepy.b64
   :members:
