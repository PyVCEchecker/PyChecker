# This file is executed via setup.py and imported via __init__.py

__version__ = "0.5.6"
# For Python versioning scheme, see:
# https://www.python.org/dev/peps/pep-0440/#version-scheme
