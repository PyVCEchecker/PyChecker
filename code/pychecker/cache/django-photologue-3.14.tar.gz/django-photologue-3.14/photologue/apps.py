from django.apps import AppConfig


class PhotologueConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'photologue'
