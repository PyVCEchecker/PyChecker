import os

__version__ = '3.14'

PHOTOLOGUE_APP_DIR = os.path.dirname(os.path.abspath(__file__))
