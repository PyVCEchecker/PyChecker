module.exports = {
  plugins: {
    autoprefixer: {},
    cssnano: {},
    'postcss-nested': {}
  }
}
