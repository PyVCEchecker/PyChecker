"""Tests for graphql.subscription"""
