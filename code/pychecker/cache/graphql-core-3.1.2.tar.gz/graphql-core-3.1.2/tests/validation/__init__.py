"""Tests for graphql.validation"""

from pytest import register_assert_rewrite  # type: ignore

register_assert_rewrite("tests.validation.harness")
