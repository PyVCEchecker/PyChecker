Subscription
============

.. currentmodule:: graphql.subscription

.. automodule:: graphql.subscription

.. autofunction:: subscribe
.. autofunction:: create_source_event_stream

