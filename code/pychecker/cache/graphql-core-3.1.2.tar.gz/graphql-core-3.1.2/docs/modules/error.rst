Error
=====

.. currentmodule:: graphql.error

.. automodule:: graphql.error

.. autoexception:: GraphQLError
   :members:

.. autoexception:: GraphQLSyntaxError

.. autofunction:: format_error
.. autofunction:: located_error
.. autofunction:: print_error
