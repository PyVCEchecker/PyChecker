Execution
=========

.. currentmodule:: graphql.execution

.. automodule:: graphql.execution

.. autofunction:: execute
.. autofunction:: default_field_resolver

.. autoclass:: ExecutionContext
.. autoclass:: ExecutionResult

.. autofunction:: get_directive_values

