Microsoft Azure CLI 'eventgrid' Command Module
=======================================================

This package is for the 'eventgrid' module.
i.e. 'az eventgrid'


