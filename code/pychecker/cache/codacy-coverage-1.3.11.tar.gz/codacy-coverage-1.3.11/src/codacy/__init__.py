from __future__ import absolute_import
from . import reporter


def main():
    return reporter.run()
