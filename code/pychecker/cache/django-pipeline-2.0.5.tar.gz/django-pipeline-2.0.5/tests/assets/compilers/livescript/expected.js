(function(){
  var times;
  times = function(x, y){
    return x * y;
  };
}).call(this);
