import gcloud.aio.auth.iam as iam  # pylint: disable=unused-import


def test_importable():
    assert True
