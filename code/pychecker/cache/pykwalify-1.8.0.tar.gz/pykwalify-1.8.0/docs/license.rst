Licensing
---------

MIT, See docs/License.txt for details

Copyright (c) 2013-2021 Johan Andersson
