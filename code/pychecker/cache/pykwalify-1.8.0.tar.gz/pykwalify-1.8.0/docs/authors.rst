Authors
=======


Code
----

 - Grokzen (https://github.com/Grokzen)
 - Markbaas (https://github.com/markbaas)
 - Gonditeniz (https://github.com/gonditeniz)
 - Comagnaw (https://github.com/comagnaw)
 - Cogwirrel (https://github.com/cogwirrel)


Testing
-------

 - Glenn Schmottlach (https://github.com/gschmottlach-xse)



Documentation
-------------

 - Grokzen (https://github.com/Grokzen)
 - Scott Lowe (https://github.com/scottclowe)
