# python_version >= '3'
#: Okay
Γ = 1
#: N816
γΓ = 1
#: Okay
Γ1 = 1
#: Okay
Γ_ = 1
#: Okay
Γ_1 = 1
#: Okay
Γ1_ = 1
#: N816
γΓ1 = 1
#: N816
_γ1Γ = 1
