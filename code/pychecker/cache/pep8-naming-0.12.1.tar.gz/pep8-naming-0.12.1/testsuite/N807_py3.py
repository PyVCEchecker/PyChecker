# python_version >= '3'
#: Okay
class C:
    def γ(self):
        pass
#: Okay
def __β(self):
    pass
#: Okay
def β__(self):
    pass
#: N807
def __β__(self):
    pass
#: N807
def __β6__(self):
    pass
#: Okay
class C:
    def γ1(self):
        pass
