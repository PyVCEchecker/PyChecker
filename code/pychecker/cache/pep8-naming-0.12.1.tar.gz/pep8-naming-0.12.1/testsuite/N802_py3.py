# python_version >= '3'
#: Okay
def γ(x):
    pass
#: Okay
def γ6(x):
    pass
