#: N802:2:5
@foo
def fn_with_decorator_Error():
    pass
#: N801:2:7
@foo
class class_with_decorator_Error:
    pass
