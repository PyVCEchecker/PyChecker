# python_version < '3'
#: Okay
def test(a, b, (good, verygood)):
    pass
#: N803
def bad(a, b, (OHH, NOO)):
    pass
