# python_version >= '3.8'
#: Okay
lambda f: (TheName := namedtuple('TheName', 'a b c')), TheName
#: N816:1:15:
lambda line: (BaD_WaLRuS := re.match(pattern, line)) and BaD_WaLRuS.group(1)
