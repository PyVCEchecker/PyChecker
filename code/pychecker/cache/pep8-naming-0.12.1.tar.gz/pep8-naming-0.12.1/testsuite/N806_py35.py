# python_version >= '3.5'
#: Okay
async def test():
    good = 1
#: N806
async def f():
    async with expr as ASYNC_VAR:
        pass
