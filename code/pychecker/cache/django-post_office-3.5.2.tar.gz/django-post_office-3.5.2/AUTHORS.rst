Author:

* Selwin Ong (@selwin)

Contributors:

* Gilang Chandrasa (@gchandrasa)
* Steven -only- (@SeiryuZ)
* Wouter de Vries (@wadevries)
* Yuri Prezument (@yprez)
* Ștefan Daniel Mihăilă (@stefan-mihaila)
* Wojciech Banaś (@fizista)
* Maestro Health
* Jacob Rief (@jacobrief)
* Alexandr Artemyev (@mogost)
