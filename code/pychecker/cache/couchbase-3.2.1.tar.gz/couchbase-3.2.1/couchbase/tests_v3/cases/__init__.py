import os

sdk_testcases = os.path.join(os.path.dirname(__file__), "..", "sdk-testcases")
