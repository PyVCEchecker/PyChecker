bottleneck package
==================

Subpackages
-----------

.. toctree::

   bottleneck.benchmark
   bottleneck.move
   bottleneck.nonreduce
   bottleneck.nonreduce_axis
   bottleneck.reduce
   bottleneck.slow
   bottleneck.src
   bottleneck.tests

Module contents
---------------

.. automodule:: bottleneck
   :members:
   :undoc-members:
   :show-inheritance:
