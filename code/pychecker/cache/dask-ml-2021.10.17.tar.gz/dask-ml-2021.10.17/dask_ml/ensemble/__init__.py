from ._blockwise import BlockwiseVotingClassifier, BlockwiseVotingRegressor

__all__ = [
    "BlockwiseVotingClassifier",
    "BlockwiseVotingRegressor",
]
