dask\_ml.compose.make\_column\_transformer
==========================================

.. currentmodule:: dask_ml.compose

.. autofunction:: make_column_transformer