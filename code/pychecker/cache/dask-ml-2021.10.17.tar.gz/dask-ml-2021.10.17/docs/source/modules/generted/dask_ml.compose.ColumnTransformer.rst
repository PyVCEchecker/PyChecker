:mod:`dask_ml.compose`.ColumnTransformer
===============================================

.. currentmodule:: dask_ml.compose

.. autoclass:: ColumnTransformer

   
   .. automethod:: __init__
   

.. include:: dask_ml.compose.ColumnTransformer.examples

.. raw:: html

    <div class="clearer"></div>