Dask is a community maintained project. We welcome contributions in the form of bug reports, documentation, code, design proposals, and more. 

Please see https://ml.dask.org/contributing.html for more information.

Also for general information on how to contribute to Dask projects see https://docs.dask.org/en/latest/develop.html.
