"""Template tags used by watson search."""

from __future__ import unicode_literals
