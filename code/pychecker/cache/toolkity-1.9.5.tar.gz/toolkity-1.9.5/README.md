

参考资料 

[拒绝重复造轮子！python实用工具类及函数大推荐！](https://zhuanlan.zhihu.com/p/31644562)

[厉害了word哥，交互式实时监控调整python程序执行！](https://zhuanlan.zhihu.com/p/32386023)

[深入python协程的实现，带你一层一层揭开协程的神秘面纱！](https://zhuanlan.zhihu.com/p/33739573)
