
This package contains utility functions used by devpi-server and devpi-client.

See http://doc.devpi.net for more information.
