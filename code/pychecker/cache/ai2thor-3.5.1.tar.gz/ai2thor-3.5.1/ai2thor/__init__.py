# Copyright Allen Institute for Artificial Intelligence 2017

__version__ = None
try:
    from ai2thor._version import __version__
except ImportError:
    pass
