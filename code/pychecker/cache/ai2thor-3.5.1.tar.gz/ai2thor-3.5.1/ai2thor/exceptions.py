class UnityCrashException(Exception):
    pass


class RestartError(RuntimeError):
    pass
