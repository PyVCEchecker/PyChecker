# GENERATED FILE - DO NOT EDIT
DEFAULT_QUALITY = 'Ultra'
QUALITY_SETTINGS = {'DONOTUSE': 0,
 'High': 5,
 'High WebGL': 8,
 'Low': 2,
 'Medium': 3,
 'MediumCloseFitShadows': 4,
 'Ultra': 7,
 'Very High': 6,
 'Very Low': 1}