Usage: python benchmark/run.py structured_data_classification report.csv
