from django.apps import AppConfig


class DjPaginationConfig(AppConfig):
    name = "dj_pagination"