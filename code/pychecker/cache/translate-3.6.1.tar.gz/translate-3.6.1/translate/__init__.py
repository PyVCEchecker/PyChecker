#!/usr/bin/env python
# encoding: utf-8

from .translate import Translator  # noqa
from .version import __version__  # noqa

__all__ = ['Translator', '__version__']
