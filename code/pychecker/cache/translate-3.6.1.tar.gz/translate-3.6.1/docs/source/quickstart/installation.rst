Installation
============

Requirements
------------

Python 2.x, 3.x


To install via pip:

.. code-block:: bash

    $ pip install translate


Or, you can download/clone the source and make manually:

.. code-block:: bash

    $ git clone git@github.com:terryyin/translate-python.git
    $ cd translate-python
    $ python setup.py install
