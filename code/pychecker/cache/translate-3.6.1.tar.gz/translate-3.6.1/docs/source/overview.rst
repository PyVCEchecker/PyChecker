Overview
========

Translate is a simple but powerful translation tool written in python with with support for multiple translation providers. It can be used as python module or as command line tool

TODO: Add more content
