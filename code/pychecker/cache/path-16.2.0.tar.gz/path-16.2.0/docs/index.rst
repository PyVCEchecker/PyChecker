Welcome to |project| documentation!
===================================

.. toctree::
   :maxdepth: 1

   api
   history

.. tidelift-referral-banner::

Thanks to Mahan Marwat for transferring the ``path`` name on
Read The Docs from `path <https://github.com/mahanmarwat/path>`_
to this project.


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
