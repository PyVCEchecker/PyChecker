Microsoft Azure CLI 'acs' Command Module
========================================

This package is for the 'acs' module.
i.e. 'az acs'
