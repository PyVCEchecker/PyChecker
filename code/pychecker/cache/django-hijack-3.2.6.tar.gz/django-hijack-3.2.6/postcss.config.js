module.exports = { plugins: ['autoprefixer'] }
