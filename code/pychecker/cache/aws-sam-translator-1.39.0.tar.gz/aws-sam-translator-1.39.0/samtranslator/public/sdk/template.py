# flake8: noqa

from samtranslator.sdk.template import SamTemplate
