DesignSpace Format
==================

Please refer to the [designSpaceDocument](https://github.com/LettError/designSpaceDocument) repository for an up to data specification of the file.

