"""
dj-stripe middleware
"""
from django.utils.deprecation import MiddlewareMixin


class SubscriptionPaymentMiddleware(MiddlewareMixin):
    pass
