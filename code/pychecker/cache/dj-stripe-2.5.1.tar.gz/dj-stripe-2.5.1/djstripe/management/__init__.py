"""
.. module:: djstripe.management.

   :synopsis: dj-stripe - management module, contains commands.
"""
