beem\.instance
==============

.. automodule:: beem.instance
    :members:
    :undoc-members:
    :show-inheritance: