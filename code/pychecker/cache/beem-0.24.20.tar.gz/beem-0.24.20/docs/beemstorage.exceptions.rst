beemstorage\.exceptions
=======================

.. automodule:: beemstorage.exceptions
    :members:
    :undoc-members:
    :show-inheritance: