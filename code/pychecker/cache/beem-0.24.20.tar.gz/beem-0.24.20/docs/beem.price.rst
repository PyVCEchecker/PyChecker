beem\.price
===========

.. automodule:: beem.price
    :members:
    :undoc-members:
    :show-inheritance: