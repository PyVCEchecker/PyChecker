beem\.vote
==========

.. automodule:: beem.vote
    :members:
    :undoc-members:
    :show-inheritance: