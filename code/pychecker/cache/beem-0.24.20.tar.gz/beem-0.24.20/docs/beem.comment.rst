beem\.comment
=============

.. automodule:: beem.comment
    :members:
    :undoc-members:
    :show-inheritance: