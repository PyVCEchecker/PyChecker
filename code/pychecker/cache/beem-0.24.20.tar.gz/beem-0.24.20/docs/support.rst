*********************
Support and Questions
*********************

Help and discussion channel for beem can be found here:

* https://discord.gg/4HM592V
