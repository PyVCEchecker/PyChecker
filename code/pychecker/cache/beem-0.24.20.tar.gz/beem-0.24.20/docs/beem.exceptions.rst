beem\.exceptions
================

.. automodule:: beem.exceptions
    :members:
    :undoc-members:
    :show-inheritance: