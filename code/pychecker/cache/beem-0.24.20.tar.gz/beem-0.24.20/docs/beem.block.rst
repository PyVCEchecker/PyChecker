beem\.block
===========

.. automodule:: beem.block
    :members:
    :undoc-members:
    :show-inheritance: