beem\.snapshot
==============

.. automodule:: beem.snapshot
    :members:
    :undoc-members:
    :show-inheritance:
