beemapi\.exceptions
===================

.. automodule:: beemapi.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
