beembase\.operationids
======================

.. automodule:: beembase.operationids
    :members:
    :noindex:
    :undoc-members:
    :show-inheritance: