beembase\.operations
====================

.. automodule:: beembase.operationids
    :members:
    :undoc-members:
    :show-inheritance: