"""beemgrapheneapi."""
import sys
sys.modules[__name__] = __import__('beemapi')
print("beemgrapheneapi is deprecated, use beemapi instead!")
