Microsoft Azure CLI 'eventhubs' Command Module
=======================================================

This package is for the 'eventhubs' module.
i.e. 'az eventhubs'


