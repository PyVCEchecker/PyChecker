vistir.backports.tempfile module
================================

.. automodule:: vistir.backports.tempfile
    :members:
    :undoc-members:
    :show-inheritance:
