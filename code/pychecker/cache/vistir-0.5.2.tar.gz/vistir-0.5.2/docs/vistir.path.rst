vistir.path module
==================

.. automodule:: vistir.path
    :members:
    :undoc-members:
    :show-inheritance:
