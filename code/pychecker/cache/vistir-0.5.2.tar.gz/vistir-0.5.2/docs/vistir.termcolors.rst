vistir.termcolors module
========================

.. automodule:: vistir.termcolors
    :members:
    :undoc-members:
    :show-inheritance:
