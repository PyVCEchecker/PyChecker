vistir.backports.functools module
=================================

.. automodule:: vistir.backports.functools
    :members:
    :undoc-members:
    :show-inheritance:
