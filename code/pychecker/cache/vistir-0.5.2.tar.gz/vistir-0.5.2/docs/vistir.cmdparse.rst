vistir.cmdparse module
======================

.. automodule:: vistir.cmdparse
    :members:
    :undoc-members:
    :show-inheritance:
