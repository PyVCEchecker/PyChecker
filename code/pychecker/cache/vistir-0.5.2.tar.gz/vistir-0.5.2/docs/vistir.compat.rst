vistir.compat module
====================

.. automodule:: vistir.compat
    :members:
    :undoc-members:
    :show-inheritance:
