vistir.contextmanagers module
=============================

.. automodule:: vistir.contextmanagers
    :members:
    :undoc-members:
    :show-inheritance:
