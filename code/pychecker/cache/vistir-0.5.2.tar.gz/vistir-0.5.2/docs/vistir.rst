vistir package
==============

.. automodule:: vistir
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    vistir.backports

Submodules
----------

.. toctree::

   vistir.cmdparse
   vistir.compat
   vistir.contextmanagers
   vistir.misc
   vistir.path

