vistir.misc module
==================

.. automodule:: vistir.misc
    :members:
    :undoc-members:
    :show-inheritance:
