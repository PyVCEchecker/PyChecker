vistir.cursor module
====================

.. automodule:: vistir.cursor
    :members:
    :undoc-members:
    :show-inheritance:
