vistir.backports package
========================

.. automodule:: vistir.backports
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   vistir.backports.functools
   vistir.backports.tempfile

