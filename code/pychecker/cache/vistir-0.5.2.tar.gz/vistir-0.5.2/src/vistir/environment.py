# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from .compat import IS_TYPE_CHECKING

MYPY_RUNNING = IS_TYPE_CHECKING
