=======================================
daiquiri -- Python logging setup helper
=======================================

.. image:: https://circleci.com/gh/jd/daiquiri.svg?style=svg
   :target: https://circleci.com/gh/jd/daiquiri

.. image:: https://img.shields.io/pypi/v/daiquiri.svg
    :target: https://pypi.python.org/pypi/daiquiri
    :alt: Latest Version

The daiquiri library provides an easy way to configure logging. It also
provides some custom formatters and handlers.

You can read the whole documentation at http://daiquiri.readthedocs.io/

* Free software: Apache license
* Source: https://github.com/jd/daiquiri
