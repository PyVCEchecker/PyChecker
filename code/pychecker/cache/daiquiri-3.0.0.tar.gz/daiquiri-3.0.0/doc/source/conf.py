master_doc = "index"
project = "Daiquiri"
extensions = ["sphinx.ext.autodoc"]
