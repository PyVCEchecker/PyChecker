Dask is a community maintained project. We welcome contributions in the form of bug reports, documentation, code, design proposals, and more.

For general information on how to contribute see https://docs.dask.org/en/latest/develop.html.

## Project specific notes

For testing remote API calls this project uses [VCR](https://vcrpy.readthedocs.io/en/latest/). See the docs for more information https://gcsfs.readthedocs.io/en/latest/developer.html.
