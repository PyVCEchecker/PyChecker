def register():
    """
    Backward compatibility
    """
    pass
