gcsfs
=====

|Build Status| |Doc Status|

Pythonic file-system for Google Cloud Storage


For documentation, go to readthedocs_.

.. _readthedocs: http://gcsfs.readthedocs.io/en/latest/

.. |Build Status| image:: https://github.com/dask/gcsfs/workflows/CI/badge.svg
    :target: https://github.com/dask/gcsfs/actions
    :alt: Build Status
.. |Doc Status| image:: https://readthedocs.org/projects/gcsfs/badge/?version=latest
    :target: https://gcsfs.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status
