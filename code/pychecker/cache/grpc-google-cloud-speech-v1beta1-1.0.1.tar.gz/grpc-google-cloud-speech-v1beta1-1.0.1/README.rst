gRPC library for grpc-google-cloud-speech-v1beta1

grpc-google-cloud-speech-v1beta1 contains the IDL-generated library for the
service:

cloud-speech - version v1beta1

in the googleapis_ repository.


.. _`googleapis`: https://github.com/google/googleapis
