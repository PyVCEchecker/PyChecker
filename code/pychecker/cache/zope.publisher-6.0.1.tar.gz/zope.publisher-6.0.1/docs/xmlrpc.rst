.. include:: ../src/zope/publisher/xmlrpc.txt

Interfaces
==========

.. automodule:: zope.publisher.interfaces.xmlrpc

Implementation
==============

.. automodule:: zope.publisher.xmlrpc
