.. include:: ../src/zope/publisher/configure.txt


ZCML Directives
===============

This package also defines some ZCML directives for defining the
default skin (``browser:defaultSkin``) and default view
(``browser:defaultView``).

.. automodule:: zope.publisher.zcml
