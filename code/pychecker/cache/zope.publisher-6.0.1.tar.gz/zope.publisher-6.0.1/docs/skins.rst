.. include:: ../src/zope/publisher/skinnable.txt


Implementation
==============

.. automodule:: zope.publisher.skinnable
