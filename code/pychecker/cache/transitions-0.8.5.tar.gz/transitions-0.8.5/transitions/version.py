""" Contains the current version of transition which is used in setup.py and can also be used
    to determine transitions's version during runtime.
"""

__version__ = '0.8.5'
