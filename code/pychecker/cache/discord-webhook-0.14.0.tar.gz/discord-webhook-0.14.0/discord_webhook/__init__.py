__all__ = ["DiscordWebhook", "DiscordEmbed"]

from .webhook import DiscordWebhook, DiscordEmbed
