with open() as fin:
    fin.read()
