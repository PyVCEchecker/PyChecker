Getting Started
===============

.. include:: ../README.rst
   :start-line: 7
