New Domains
===========

.. automodule:: sphinxcontrib.bibtex.domain
.. automodule:: sphinxcontrib.bibtex.foot_domain
