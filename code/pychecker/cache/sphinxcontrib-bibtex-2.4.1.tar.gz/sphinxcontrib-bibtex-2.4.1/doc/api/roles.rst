New Roles
=========

.. automodule:: sphinxcontrib.bibtex.roles
.. automodule:: sphinxcontrib.bibtex.foot_roles
