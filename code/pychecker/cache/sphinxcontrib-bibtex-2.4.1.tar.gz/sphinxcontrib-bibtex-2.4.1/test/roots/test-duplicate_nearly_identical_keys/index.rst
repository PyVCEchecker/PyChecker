:cite:`Tèst`
:cite:`Tést`
:cite:`Têst`

.. bibliography:: test.bib