.. bibliography::
   :list: thisisintentionallyinvalid
