doc12
=====

:cite:`Sh:12`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
