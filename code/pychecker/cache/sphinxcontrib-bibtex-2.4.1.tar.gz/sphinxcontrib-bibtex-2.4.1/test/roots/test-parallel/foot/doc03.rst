doc03
=====

:footcite:`Sh:1`

.. footbibliography::
