doc10
=====

:cite:`Sh:10`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
