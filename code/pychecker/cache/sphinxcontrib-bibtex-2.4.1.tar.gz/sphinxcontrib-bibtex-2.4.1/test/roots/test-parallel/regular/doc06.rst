doc06
=====

:cite:`Sh:6`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
