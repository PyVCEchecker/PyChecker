doc08
=====

:cite:`Sh:8`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"

.. bibliography::
   :filter: "regular/doc11" in docnames
