doc03
=====

:cite:`Sh:3`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
