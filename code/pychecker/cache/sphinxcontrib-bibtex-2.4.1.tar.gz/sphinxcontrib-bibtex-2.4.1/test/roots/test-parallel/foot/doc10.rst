doc10
=====

:footcite:`Sh:1`

.. footbibliography::
