doc01
=====

:cite:`Sh:1`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
