doc17
=====

:footcite:`Sh:1`

.. footbibliography::
