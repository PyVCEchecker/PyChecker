doc07
=====

:cite:`Sh:7`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"

.. bibliography::
   :filter: "regular/doc15" in docnames
