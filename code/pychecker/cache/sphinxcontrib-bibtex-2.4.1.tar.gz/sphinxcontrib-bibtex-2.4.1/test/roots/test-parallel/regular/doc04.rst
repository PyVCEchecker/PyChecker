doc04
=====

:cite:`Sh:4`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"
