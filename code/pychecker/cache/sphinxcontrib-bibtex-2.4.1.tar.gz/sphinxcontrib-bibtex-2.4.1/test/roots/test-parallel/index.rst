index
=====

.. toctree::

    regular/index
    foot/index
