doc09
=====

:cite:`Sh:9`

.. bibliography::
   :list: enumerated
   :filter: title % "Godel case"

.. bibliography::
   :labelprefix: A
   :filter: "regular/doc13" in docnames
