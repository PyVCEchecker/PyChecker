doc23
=====

:cite:`GlSh:23`

