doc05
=====

:footcite:`Sh:1`

.. footbibliography::
