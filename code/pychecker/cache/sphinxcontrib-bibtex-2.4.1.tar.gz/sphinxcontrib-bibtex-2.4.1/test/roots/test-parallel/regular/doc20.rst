doc20
=====

:cite:`ScSh:20`

