footcite
========

.. automodule:: some_module_footcite
   :members:

.. footbibliography::
