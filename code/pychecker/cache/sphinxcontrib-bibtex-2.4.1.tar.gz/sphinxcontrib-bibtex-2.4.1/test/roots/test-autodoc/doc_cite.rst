cite
====

.. automodule:: some_module_cite
   :members:

.. bibliography::
   :style: alpha
