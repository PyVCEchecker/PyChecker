index
=====

.. toctree::

   doc_cite
   doc_footcite
