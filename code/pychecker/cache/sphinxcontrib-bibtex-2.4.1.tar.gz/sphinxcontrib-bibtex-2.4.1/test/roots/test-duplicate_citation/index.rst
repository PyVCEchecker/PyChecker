.. bibliography:: test.bib
   :all:

.. bibliography:: test.bib
   :all:
