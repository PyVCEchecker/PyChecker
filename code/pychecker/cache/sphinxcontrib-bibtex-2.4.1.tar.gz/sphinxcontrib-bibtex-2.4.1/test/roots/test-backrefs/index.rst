First reference: :cite:`Test1,Test2,Test3`.

Second reference: :cite:`Test2,Test3`.

Third reference: :cite:`Test3`.

.. bibliography:: test.bib
   :all:
