.. bibliography:: test.bib
   :list: enumerated
   :all:

.. bibliography:: test2.bib
   :list: enumerated
   :start: continue
   :all:

.. bibliography:: test3.bib
   :list: enumerated
   :start: 23
   :all:

