Introduction
------------

This has been discussed in the literature :cite:p:`2003:evensen`.

:cite:ct:`2003:evensen` has discussed this at length.

Bibliography
------------

.. bibliography::
