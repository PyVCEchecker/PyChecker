Custom Ids
==========

Regular Citations
-----------------

First citation :cite:`2009:mandel`.
Second citation :cite:`2003:evensen`.
Third citation :cite:`1986:lorenc`.

.. bibliography::
   :filter: False

   2009:mandel
   2003:evensen

.. bibliography::
   :filter: False

   1986:lorenc

Footnote Citations
------------------

First citation :footcite:`2009:mandel`.
Second citation :footcite:`2003:evensen`.

.. footbibliography::

And first citation again :footcite:`2009:mandel`.
Third citation :footcite:`1986:lorenc`.

.. footbibliography::
