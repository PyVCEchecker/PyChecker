.. bibliography::
   :list: bullet
   :all:
