doc1
----

:cite:`tag1-2009:mandel`

.. bibliography::
   :labelprefix: B
   :keyprefix: tag1-
