.. bibliography::
   :filter: $

.. bibliography::
   :filter: yield author

.. bibliography::
   :filter: author is title

.. bibliography::
   :filter: False % title

.. bibliography::
   :filter: title % False

.. bibliography::
   :filter: ~title

.. bibliography::
   :filter: "2000" <= year <= "2005"

.. bibliography::
   :filter: author + title

.. bibliography::
   :filter: author; title
