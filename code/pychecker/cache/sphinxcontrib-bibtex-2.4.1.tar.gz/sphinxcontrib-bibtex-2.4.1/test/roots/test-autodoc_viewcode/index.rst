.. automodule:: somemodule
   :members:
