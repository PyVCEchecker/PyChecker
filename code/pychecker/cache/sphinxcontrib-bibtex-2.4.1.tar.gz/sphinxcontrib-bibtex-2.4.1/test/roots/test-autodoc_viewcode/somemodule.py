"""Some module."""


class someclass:
    """Some class."""
    pass
