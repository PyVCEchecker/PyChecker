.. Sphinx bibtex extension test documentation master file, created by
   sphinx-quickstart on Mon Mar 21 14:37:33 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Sphinx bibtex extension test's documentation!
========================================================

Citation :cite:`1996:fukuda` :cite:`dreze:2000` to other document.
Regular citation test [Test01]_ to other document.
Mix with a footnote [#note]_.

Contents:

.. toctree::
   :maxdepth: 2

   bibliography
   fnbibliography

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. [#note] A footnote.
