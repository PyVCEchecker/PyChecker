.. bibliography::
   :list: bullet
   :filter: author % "Test"
