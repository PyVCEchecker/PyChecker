Doc2
====

.. bibliography:: test2.bib
   :style: plain
   :all:
