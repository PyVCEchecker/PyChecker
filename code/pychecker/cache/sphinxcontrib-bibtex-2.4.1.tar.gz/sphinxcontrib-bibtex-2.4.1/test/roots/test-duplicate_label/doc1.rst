Doc1
====

.. bibliography:: test1.bib
   :style: plain
   :all:
