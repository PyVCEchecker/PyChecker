extensions = ['test.natbib']
exclude_patterns = ['_build']
natbib = {
    'file': 'test.bib',
}
