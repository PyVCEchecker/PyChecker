.. bibliography::
   :thisisintentionallyinvalid:
