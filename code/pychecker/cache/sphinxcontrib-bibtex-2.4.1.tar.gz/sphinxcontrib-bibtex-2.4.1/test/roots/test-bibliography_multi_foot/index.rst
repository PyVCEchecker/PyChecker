First citation :footcite:`2009:mandel`.

.. footbibliography::

Second citation :footcite:`2003:evensen`.
And first citation again :footcite:`2009:mandel`.

.. footbibliography::

Third citation :footcite:`1986:lorenc`.

.. footbibliography::
