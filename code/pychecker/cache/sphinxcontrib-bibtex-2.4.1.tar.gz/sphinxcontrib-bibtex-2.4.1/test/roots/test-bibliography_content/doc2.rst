doc2
====

:cite:`x-test4,test5`

.. bibliography::
   :filter: False

   test5
   test6
