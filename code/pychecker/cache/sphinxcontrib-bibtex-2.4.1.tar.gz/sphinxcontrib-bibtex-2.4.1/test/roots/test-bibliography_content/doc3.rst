doc3
====

.. bibliography::
   :keyprefix: x-
   :filter: False

   test4
