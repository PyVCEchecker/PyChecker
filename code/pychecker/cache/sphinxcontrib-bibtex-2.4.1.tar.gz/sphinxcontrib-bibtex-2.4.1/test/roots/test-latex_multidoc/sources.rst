Bibliography
============

.. bibliography:: sources.bib
   :all:
