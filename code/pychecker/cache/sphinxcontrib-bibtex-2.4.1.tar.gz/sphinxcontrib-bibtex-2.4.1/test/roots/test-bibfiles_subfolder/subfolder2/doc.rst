Doc2
====

.. bibliography:: ../bibfiles/test.bib
   :all:
   :list: bullet
