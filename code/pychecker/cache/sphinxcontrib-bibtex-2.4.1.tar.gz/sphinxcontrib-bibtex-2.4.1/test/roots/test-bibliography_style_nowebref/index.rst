.. bibliography::
   :all:
   :list: bullet
