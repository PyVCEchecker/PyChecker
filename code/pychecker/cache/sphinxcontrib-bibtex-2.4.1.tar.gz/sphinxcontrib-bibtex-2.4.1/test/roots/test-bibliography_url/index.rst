.. bibliography::
   :all:
