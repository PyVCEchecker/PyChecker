Doc2
====

:cite:`Test2`

.. bibliography:: test2.bib
   :all:
   :style: plain
   :labelprefix: B
