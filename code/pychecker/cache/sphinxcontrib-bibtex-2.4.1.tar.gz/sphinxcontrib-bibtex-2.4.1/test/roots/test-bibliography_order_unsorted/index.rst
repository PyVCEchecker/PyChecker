:cite:`first`
:cite:`second`

.. bibliography::
   :style: unsrt
