.. bibliography::
   :style: plain
   :all:
