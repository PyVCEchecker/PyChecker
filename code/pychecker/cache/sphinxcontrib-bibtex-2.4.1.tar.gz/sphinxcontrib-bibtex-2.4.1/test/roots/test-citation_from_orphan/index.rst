Contents
========

.. bibliography::
   :style: plain
