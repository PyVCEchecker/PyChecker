In
--

.. bibliography::
   :list: bullet
   :filter: "bla" in docnames
