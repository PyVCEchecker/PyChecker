Title
-----

.. bibliography::
   :list: bullet
   :filter: title and title % "jakka"
