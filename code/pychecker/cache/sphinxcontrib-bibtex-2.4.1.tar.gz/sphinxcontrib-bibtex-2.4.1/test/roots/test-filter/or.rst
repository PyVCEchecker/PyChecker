Or
--

.. bibliography::
   :list: bullet
   :filter: author % "First" or type == "article"
