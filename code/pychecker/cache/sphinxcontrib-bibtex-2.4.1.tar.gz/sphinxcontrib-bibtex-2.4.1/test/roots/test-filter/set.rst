Set
---

.. bibliography::
   :list: bullet
   :filter: {"doc1", "doc2"} <= docnames
