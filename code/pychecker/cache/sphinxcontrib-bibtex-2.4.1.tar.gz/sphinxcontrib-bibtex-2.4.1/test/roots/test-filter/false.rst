False
-----

.. bibliography::
   :list: bullet
   :filter: False
