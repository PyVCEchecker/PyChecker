rdflib.namespace package
========================

Module contents
---------------

.. automodule:: rdflib.namespace
   :members:
   :undoc-members:
   :show-inheritance:
