rdflib.plugins.sparql package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   rdflib.plugins.sparql.results

Submodules
----------

rdflib.plugins.sparql.aggregates module
---------------------------------------

.. automodule:: rdflib.plugins.sparql.aggregates
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.algebra module
------------------------------------

.. automodule:: rdflib.plugins.sparql.algebra
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.datatypes module
--------------------------------------

.. automodule:: rdflib.plugins.sparql.datatypes
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.evaluate module
-------------------------------------

.. automodule:: rdflib.plugins.sparql.evaluate
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.evalutils module
--------------------------------------

.. automodule:: rdflib.plugins.sparql.evalutils
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.operators module
--------------------------------------

.. automodule:: rdflib.plugins.sparql.operators
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.parser module
-----------------------------------

.. automodule:: rdflib.plugins.sparql.parser
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.parserutils module
----------------------------------------

.. automodule:: rdflib.plugins.sparql.parserutils
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.processor module
--------------------------------------

.. automodule:: rdflib.plugins.sparql.processor
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.sparql module
-----------------------------------

.. automodule:: rdflib.plugins.sparql.sparql
   :members:
   :undoc-members:
   :show-inheritance:

rdflib.plugins.sparql.update module
-----------------------------------

.. automodule:: rdflib.plugins.sparql.update
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: rdflib.plugins.sparql
   :members:
   :undoc-members:
   :show-inheritance:
