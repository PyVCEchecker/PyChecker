rdflib.plugins package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   rdflib.plugins.parsers
   rdflib.plugins.serializers
   rdflib.plugins.shared
   rdflib.plugins.sparql
   rdflib.plugins.stores

Module contents
---------------

.. automodule:: rdflib.plugins
   :members:
   :undoc-members:
   :show-inheritance:
