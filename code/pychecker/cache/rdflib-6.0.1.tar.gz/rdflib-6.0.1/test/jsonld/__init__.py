from rdflib import plugin
from rdflib import serializer
from rdflib import parser

assert plugin
assert serializer
assert parser
import json
