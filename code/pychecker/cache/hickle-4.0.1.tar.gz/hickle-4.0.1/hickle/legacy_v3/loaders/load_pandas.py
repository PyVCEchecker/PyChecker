import pandas as pd

# TODO: populate with classes to load
class_register = []