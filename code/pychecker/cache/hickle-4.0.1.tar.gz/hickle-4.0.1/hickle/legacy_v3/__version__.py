# -*- coding: utf-8 -*-

"""
Hickle Version
==============
Stores the different versions of the *Hickle* package.

"""


# %% VERSIONS
# Default/Latest/Current version
__version__ = '3.4.8'
