# -*- coding: utf-8 -*-

"""
Hickle Version
==============
Stores the different versions of the *hickle* package.

"""


# %% VERSIONS
# Default/Latest/Current version
__version__ = '4.0.1'
