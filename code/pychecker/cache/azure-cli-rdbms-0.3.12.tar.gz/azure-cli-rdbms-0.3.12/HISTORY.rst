.. :changelog:

Release History
===============

0.3.12
++++++
* Minor fixes

0.3.11
++++++
* Add postgres and mysql support for geo replication

0.3.10
++++++
* Minor fixes

0.3.9
+++++
* Add postgresql replica commands and restart server command

0.3.8
+++++
* Minor fixes: Get default location from resource group when not provided for creating servers and add validation for retention days. 

0.3.7
+++++
* Improve help message and command parameters

0.3.6
+++++
* Minor fixes

0.3.5
+++++
* Add mariadb vnet commands

0.3.4
+++++
* Add mysql replica commands

0.3.3
+++++
* Minor fixes

0.3.2
+++++
* Add support for MariaDB service

0.3.1
+++++
* Minor fixes

0.3.0
+++++
* BREAKING CHANGE: 'show' commands log error message and fail with exit code of 3 upon a missing resource.

0.2.5
+++++
* Added 'postgres/myql server vnet-rule' commands.

0.2.4
+++++
* Minor fix allowing elastic server update using skuname.

0.2.3
+++++
* Minor fixes.

0.2.2
+++++
* Minor help fix.

0.2.1
+++++
* Introduce georestore command.
* Remove storage size restriction from create command.
* `sdist` is now compatible with wheel 0.31.0

0.2.0
+++++
* Release with new business model GA API version 2017-12-01.

0.1.1
++++++
* Minor changes.

0.1.0
++++++
* Preview release with new business model API 2017-12-01-preview.

0.0.12
++++++
* Minor fixes.

0.0.11
++++++
* Minor fixes.

0.0.10
++++++
* Update for CLI core changes.

0.0.9
+++++
* Minor fixes.

0.0.8
++++++
* minor fixes

0.0.7 (2017-09-22)
++++++++++++++++++
* minor fixes

0.0.6 (2017-08-28)
++++++++++++++++++
* minor fixes

0.0.5 (2017-07-07)
++++++++++++++++++
* minor fixes

0.0.4 (2017-06-21)
++++++++++++++++++
* No changes.

0.0.3 (2017-06-13)
++++++++++++++++++
* Minor fixes.

0.0.2 (2017-05-30)
++++++++++++++++++

* Add support for list server across a subscription.
* [RDBMS]Support list servers across a subscription (#3417)
* %s not processed becasue of missing % server_type (#3393)
* Fix doc source map and add CI task to verify (#3361)
* Fix MySQL and PostgreSQL help (#3369)

0.0.1 (2017-05-09)
++++++++++++++++++

* Preview release.
