Microsoft Azure CLI 'MySQL and PostgreSQL' Command Module
=========================================================
This package is for the 'rdbms' module.
i.e. 'az mariadb', 'az mysql' and 'az postgres'

