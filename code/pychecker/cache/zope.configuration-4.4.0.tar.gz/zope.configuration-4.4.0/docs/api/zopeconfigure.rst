==================================
 zope.configuration.zopeconfigure
==================================

.. automodule:: zope.configuration.zopeconfigure
