======================================
 zope.configuration.interfaces
======================================

.. automodule:: zope.configuration.interfaces
