# I'm bad. I want to be bad. Don't try to change me.

raise ImportError()
