=====================================
pem: Easy PEM file parsing in Python.
=====================================

Release v\ |release| (:doc:`What's new? <changelog>`).


.. include:: ../README.rst
   :start-after: teaser-begin


User's Guide
------------

.. toctree::
   :maxdepth: 1

   core
   twisted
   api


Project Information
-------------------

.. toctree::
   :maxdepth: 1

   license
   contributing
   backward-compatibility
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
