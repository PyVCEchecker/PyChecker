License and Hall of Fame
========================

*pem* is licensed under the permissive `MIT <https://choosealicense.com/licenses/mit/>`_ license.
The full license text can be also found in the `source code repository <https://github.com/hynek/pem/blob/main/LICENSE>`_.

.. _authors:

.. include:: ../AUTHORS.rst
