"""
The `compat` module provides support for backwards compatibility with older
versions of Django and Python.
"""
