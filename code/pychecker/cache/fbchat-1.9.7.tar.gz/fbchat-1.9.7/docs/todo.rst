.. _todo:

Todo
====

This page will be periodically updated to show missing features and documentation


Missing Functionality
---------------------

- Implement ``Client.searchForMessage``
    - This will use the GraphQL request API
- Implement chatting with pages properly
- Write better FAQ
- Explain usage of GraphQL


Documentation
-------------

.. todolist::
