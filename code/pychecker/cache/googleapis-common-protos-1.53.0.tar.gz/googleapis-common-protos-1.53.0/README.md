
# Google APIs common protos

[![pypi](https://img.shields.io/pypi/v/googleapis-common-protos.svg)](https://pypi.org/project/googleapis-common-protos/)


googleapis-common-protos contains the python classes generated from the common
protos in the [googleapis/api-common-protos](https://github.com/googleapis/api-common-protos) repository.
