import warnings

from pilkit.processors.utils import *

warnings.warn('imagekit.processors.utils is deprecated use pilkit.processors.utils instead', DeprecationWarning)
