Microsoft Azure CLI 'extension' Command Module
==============================================

This package is for the 'extension' module.
i.e. 'az extension'


