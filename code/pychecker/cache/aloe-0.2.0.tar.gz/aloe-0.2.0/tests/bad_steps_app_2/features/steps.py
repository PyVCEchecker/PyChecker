"""
This step definition file intentionally raises an exception on importing.
"""

raise ValueError("Bad file.")
