"""
Unrelated module from the step definition test app.
"""

# If this module is imported by Aloe, it will cause an error.
raise Exception("This module should not be loaded when searching for steps.")
