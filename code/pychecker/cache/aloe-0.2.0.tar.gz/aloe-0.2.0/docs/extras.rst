Optional Extras
===============

.. toctree::
    :maxdepth: 2

Factory Boy Integration
-----------------------

.. toctree::
    :maxdepth: 2

.. automodule:: aloe.steps.factoryboy
    :members:

Sphinx Extensions
-----------------

.. toctree::
    :maxdepth: 2

.. automodule:: aloe_sphinx

.. include:: links.rst
