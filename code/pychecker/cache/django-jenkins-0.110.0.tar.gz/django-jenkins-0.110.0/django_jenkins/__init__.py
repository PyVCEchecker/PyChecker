default_app_config = 'django_jenkins.apps.JenkinsConfig'
