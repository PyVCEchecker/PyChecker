def test():
    print('Not for coverage')