# -*- coding: utf-8 -*-
from django.test import TestCase


class DirDiscoveryTest(TestCase):
    def test_should_be_dicoverd(self):
        """
        Yep!
        """
