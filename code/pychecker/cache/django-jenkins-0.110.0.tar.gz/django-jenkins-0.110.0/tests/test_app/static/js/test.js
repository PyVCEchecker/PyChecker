/*jshint unused:true */

function toggle() {
    var unused, x = true;
    if (x) {
        x = false;
    }
}