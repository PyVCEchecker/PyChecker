"""This file is used by the ``LoadContextNodeTestCase`` test."""
FOO = 'bar'
BAR = 'foo'
