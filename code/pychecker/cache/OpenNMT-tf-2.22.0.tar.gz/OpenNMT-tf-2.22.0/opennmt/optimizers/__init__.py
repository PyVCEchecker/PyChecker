"""Module defining custom optimizers."""

from opennmt.optimizers.utils import make_optimizer, register_optimizer
