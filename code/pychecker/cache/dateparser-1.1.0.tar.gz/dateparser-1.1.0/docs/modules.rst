API reference
=============

.. toctree::
   :maxdepth: 4

   dateparser
