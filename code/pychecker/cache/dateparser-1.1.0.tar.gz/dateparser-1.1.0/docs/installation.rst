============
Installation
============

At the command line::

    $ pip install dateparser

Or, if you don't have pip installed::

    $ easy_install dateparser

If you want to install from the latest sources, you can do::

    $ git clone https://github.com/scrapinghub/dateparser.git
    $ cd dateparser
    $ python setup.py install
