Part of `edX code`_.

.. _`edX code`: http://code.edx.org/

edx-opaque-keys  |build-status| |coverage-status|
=================================================

Opaque-keys provides the ability to create and introspect course and xblock identities through a
clear and consistent API. See the code's docstrings for more information.

See the `edx-platform wiki documentation`_ for more detail.

.. |build-status| image:: https://travis-ci.com/edx/opaque-keys.svg?branch=master
   :target: https://travis-ci.com/edx/opaque-keys
.. |coverage-status| image:: https://coveralls.io/repos/edx/opaque-keys/badge.svg?branch=master
   :target: https://coveralls.io/r/edx/opaque-keys
.. _`edx-platform wiki documentation`: https://github.com/edx/edx-platform/wiki/Opaque-Keys-(Locators)
