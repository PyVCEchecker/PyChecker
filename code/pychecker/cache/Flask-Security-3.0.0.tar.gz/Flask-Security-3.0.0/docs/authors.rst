.. include:: ../AUTHORS
