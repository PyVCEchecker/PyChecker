from pyquaternion.quaternion import Quaternion
