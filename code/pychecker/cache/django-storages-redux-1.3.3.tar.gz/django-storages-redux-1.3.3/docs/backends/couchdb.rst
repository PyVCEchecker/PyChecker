CouchDB
=======

A custom storage system for Django with CouchDB backend.

