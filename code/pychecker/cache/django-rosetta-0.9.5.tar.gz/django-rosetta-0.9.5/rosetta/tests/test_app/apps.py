from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = 'rosetta.tests.test_app'
    verbose_name = 'Rosetta test app'
