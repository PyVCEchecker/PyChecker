def dummy(request):
    pass
