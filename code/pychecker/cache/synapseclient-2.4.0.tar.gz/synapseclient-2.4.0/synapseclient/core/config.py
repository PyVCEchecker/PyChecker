"""
Store configuration for the synapseclient package.
"""

single_threaded = False
