..
   This file is part of IDUtils
   Copyright (C) 2015-2019 CERN.

   IDUtils is free software; you can redistribute it and/or modify
   it under the terms of the Revised BSD License; see LICENSE file for
   more details.

   In applying this license, CERN does not waive the privileges and immunities
   granted to it by virtue of its status as an Intergovernmental Organization
   or submit itself to any jurisdiction.


Authors
=======

- Adrian Pawel Baran
- Alan Rubin
- Alexander Ioannidis
- Antoine Lambert
- Bruno Marmol
- Guillaume Viger
- Jiri Kuncar
- Lars Holm Nielsen
- Pedro Gaudencio
- Tibor Simko
