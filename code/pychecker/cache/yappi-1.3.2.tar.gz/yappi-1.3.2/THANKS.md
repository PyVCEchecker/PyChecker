# THANKS

Thanks to all the great community of Python, especially to the [Python E-Mail Group](http://groups.google.com/group/comp.lang.python) group for answering my 
silly questions.

Special Thanks to:

- A. Jesse Jiryu Davis ([@ajdavis](https://github.com/ajdavis))
- Dave Peticolas
- tooker
- mjanos5
- Mark Stuart
- Nicolas Wack
- Bulent Evren
- Nir Soffer ([@nirs](https://github.com/nirs))
- Dev Aggarwal ([@devxpy](https://github.com/devxpy))
- Chris Frohoff ([@frohoff](https://github.com/frohoff))
- Ali Oguzhan Yildiz ([@alioguzhan](https://github.com/alioguzhan))
- dmontagu ([@dmontagu](https://github.com/dmontagu))
- euri10 ([@euri10](https://github.com/euri10))
- sm-Fifteen ([@sm-Fifteen](https://github.com/sm-Fifteen))
- Suhail Muhammed ([@Suhail-MOHD](https://github.com/Suhail-MOHD))

Special thanks to the authors of cProfile module `Brett Rosen` and `Ted Czotter`. 
Some parts/ideas of Yappi are taken from the source code of cProfile.


