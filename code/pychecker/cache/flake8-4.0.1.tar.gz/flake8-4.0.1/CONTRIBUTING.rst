Please refer to `Contributing to Flake8
<http://flake8.pycqa.org/en/latest/internal/contributing.html>`_
on our website.
