default_app_config = 'river.apps.RiverApp'
