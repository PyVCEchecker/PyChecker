from django.apps import AppConfig


class TextCkeditorConfig(AppConfig):
    name = 'djangocms_text_ckeditor'
    verbose_name = 'django CMS Text CKEditor'
