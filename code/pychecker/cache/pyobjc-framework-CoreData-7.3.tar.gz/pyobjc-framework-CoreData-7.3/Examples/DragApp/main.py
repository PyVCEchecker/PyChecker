import DragAppAppDelegate  # noqa: F401
import DragSupportDataSource  # noqa: F401
from PyObjCTools import AppHelper

if __name__ == "__main__":
    AppHelper.runEventLoop()
