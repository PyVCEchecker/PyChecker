import MyDocument  # noqa: F401
import Note  # noqa: F401
from PyObjCTools import AppHelper

if __name__ == "__main__":
    AppHelper.runEventLoop()
