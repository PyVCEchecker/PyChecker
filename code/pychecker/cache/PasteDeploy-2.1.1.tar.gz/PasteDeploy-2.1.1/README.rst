This tool provides code to load WSGI applications and servers from
URIs. These URIs can refer to Python eggs for INI-style configuration
files.  `Paste Script <https://github.com/cdent/pastescript>`_ provides
commands to serve applications based on this configuration file.

The latest version is available on `GitHub
<https://github.com/Pylons/pastedeploy/>`_ (or download a wheel or tarball from
`PyPI <https://pypi.org/project/PasteDeploy/#files>`_).

For the latest changes see the `news file
<https://docs.pylonsproject.org/projects/pastedeploy/en/latest/news.html>`_.
