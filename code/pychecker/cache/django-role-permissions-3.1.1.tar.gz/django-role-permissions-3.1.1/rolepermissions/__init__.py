__version__ = '3.1.1'


default_app_config = 'rolepermissions.apps.RolePermissions'
