external
========

This directory vendors backport packages which break conda "noarch" packaging
otherwise. Please see https://github.com/rigetti/pyquil/issues/724 for details.

The licenses for the software contained in this directory can be found in the
top-level NOTICE.md file.
