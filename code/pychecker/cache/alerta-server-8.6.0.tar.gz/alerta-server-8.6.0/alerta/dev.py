from datetime import datetime

BUILD_NUMBER = 'DEV'
BUILD_DATE = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
BUILD_VCS_NUMBER = 'HEAD'
