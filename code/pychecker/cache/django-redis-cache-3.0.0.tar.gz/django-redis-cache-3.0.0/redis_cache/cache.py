# for backwards compat
from redis_cache import RedisCache
from redis_cache import ShardedRedisCache
from redis_cache.backends.base import ImproperlyConfigured
from redis_cache.connection import pool
