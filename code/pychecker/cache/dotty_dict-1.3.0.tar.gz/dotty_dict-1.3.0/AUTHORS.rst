=======
Credits
=======

***********
Development
***********

* Paweł Zadrożny @pawelzny <pawel.zny@gmail.com>


************
Contributors
************

* Linus Groh @linusg
* Andreas Motl @amotl
* Aneesh Devasthale @aneeshd16
* Szymon Piotr Krasuski @Dysproz

Read more how to contribute on :ref:`Contributing`.
