# -*- coding: utf-8 -*-
from dotty_dict.dotty_dict import Dotty, dotty

__author__ = 'Paweł Zadrożny'
__copyright__ = 'Copyright (c) 2017, Paweł Zadrożny'
__email__ = 'pawel.zny@gmail.com'
__version__ = '1.3.0'
__all__ = ['Dotty', 'dotty']
