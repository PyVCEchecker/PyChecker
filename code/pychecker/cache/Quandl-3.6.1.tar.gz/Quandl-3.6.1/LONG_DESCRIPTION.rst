Official Quandl API Client for Python
=========================================

A Python library for Quandl's RESTful API.


Setup
=====

You can install this package by using the pip tool and installing:

    $ pip install quandl

Or:

    $ easy_install quandl

Usage
=====

You can read more about developing and using the library here: https://github.com/quandl/quandl-python