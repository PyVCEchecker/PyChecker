Microsoft Azure CLI 'Content Delivery Network (CDN)' Command Module
===================================================================

This package is for the 'Content Delivery Network (CDN)' module.
i.e. 'az cdn'
