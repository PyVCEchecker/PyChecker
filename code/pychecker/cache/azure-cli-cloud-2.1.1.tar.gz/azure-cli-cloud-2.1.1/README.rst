Microsoft Azure CLI 'cloud' Command Module
==========================================

This package is for the 'cloud' commands.
