from openapi_core.exceptions import OpenAPIError


class SecurityError(OpenAPIError):
    pass
