"""OpenAPI X-Model extension package"""
