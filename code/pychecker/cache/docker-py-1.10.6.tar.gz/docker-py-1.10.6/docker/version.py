version = "1.10.6"
version_info = tuple([int(d) for d in version.split("-")[0].split(".")])
