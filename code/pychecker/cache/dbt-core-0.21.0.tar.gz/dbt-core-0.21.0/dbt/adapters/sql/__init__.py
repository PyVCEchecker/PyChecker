# these are all just exports, #noqa them so flake8 will be happy
from dbt.adapters.sql.connections import SQLConnectionManager  # noqa
from dbt.adapters.sql.impl import SQLAdapter  # noqa
