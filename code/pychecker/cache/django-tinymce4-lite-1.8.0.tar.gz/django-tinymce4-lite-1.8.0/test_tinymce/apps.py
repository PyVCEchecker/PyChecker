from django.apps import AppConfig


class TestsConfig(AppConfig):
    name = 'test_tinymce'
