name = 'tinymce4-lite'
authors = 'Joost Cassee, Aljosa Mohorovic, Roman Miroshnychenko'
version = '1.8.0'
release = version
