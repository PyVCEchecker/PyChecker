Installation
============

**pydash** requires Python >= 3.6. It has no external dependencies.

To install from `PyPi <https://pypi.python.org/pypi/pydash>`_:

::

    pip install pydash
