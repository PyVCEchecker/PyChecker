Kudos
*****

Thank you to `Lodash <http://lodash.com/>`_ for providing such a great library to port.