GenericSetup Credits
====================

- Martijn Pieters wrote the original version of this software while working at
  Zope Corporation.  He developed his version as part of the "Bonzai" CMS
  which Zope corp.  built for Boston.com using its Zope4Media Print product.

- Tres Seaver factored the code out of the Bonzai CMS, first into a
  ``CMFSetup`` package, and later into the current form, with no dependencies
  on CMF products.

- Yvo Schubbe refactored the XML export / import support mercilessly, and
  has made numerous bugfixes and enhancements to the product.

- Jens Vagelpohl has made numerous bug fixes and enhancements to the product.

- The package is now maintained by the CMF developers, with lots of input
  from the Plone developers.
