(See docs/index.rst in the source distribution).
