.. _release-notes:

Release notes
=============

The |version| release of |project| supports Python 3.5, 3.6, 3.7 and
Django 2.0, 2.1, 2.2, 3.0, and 3.1.
