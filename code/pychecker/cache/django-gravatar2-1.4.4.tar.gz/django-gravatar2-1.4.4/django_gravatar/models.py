"""Stub models.py"""
