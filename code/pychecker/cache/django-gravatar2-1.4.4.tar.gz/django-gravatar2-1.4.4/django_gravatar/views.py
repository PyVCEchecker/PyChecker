"""Stub views.py"""
