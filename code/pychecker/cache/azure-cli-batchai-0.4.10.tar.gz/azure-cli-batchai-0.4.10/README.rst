Microsoft Azure CLI Batch AI Module
=========================================

This package is for the `batchai` module.
