=========
 fixture
=========

.. automodule:: oslo_service.fixture
   :members:
   :undoc-members:
   :show-inheritance:
