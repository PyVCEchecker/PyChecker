==============
 periodic_task
==============

.. automodule:: oslo_service.periodic_task
   :members:
   :undoc-members:
   :show-inheritance:
