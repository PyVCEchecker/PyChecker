soco.soap module
================

.. automodule:: soco.soap
    :member-order: bysource
    :members:
