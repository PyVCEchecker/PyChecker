soco.exceptions module
======================

.. automodule:: soco.exceptions
    :member-order: bysource
    :members:
