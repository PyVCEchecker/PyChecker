.. _events_asyncio:

The events_asyncio module
=========================

The :mod:`soco.events_asyncio` module has been provided for those wanting to
use asyncio for event handling. The :mod:`soco.events_asyncio`
page contains an example of how to use the module.
