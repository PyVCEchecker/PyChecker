:tocdepth: 1

#######
Authors
#######

.. include:: ../AUTHORS.rst
