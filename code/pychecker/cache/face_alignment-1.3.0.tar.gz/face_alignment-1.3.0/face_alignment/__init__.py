# -*- coding: utf-8 -*-

__author__ = """Adrian Bulat"""
__email__ = 'adrian@adrianbulat.com'
__version__ = '1.3.0'

from .api import FaceAlignment, LandmarksType, NetworkSize
