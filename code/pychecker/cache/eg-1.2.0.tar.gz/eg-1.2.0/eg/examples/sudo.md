# sudo

execute ls as the super user

    sudo ls

execute ls as the user tyrion

    sudo -u tyrion ls



# Basic Usage

Execute a command as the super-user:

    sudo <command>

Execute a command as another user:

    sudo -u <user> <command>


