# mkdir

create a directory

    mkdir directory


create a directory with all permissions enabled

    mkdir -m 777 unprotected_directory



# Basic Usage

Create a directory:

    mkdir <directory>


