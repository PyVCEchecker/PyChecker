# head

print the first 10 lines of a file to stdout

    head file.txt


print the first 20 lines of file1.txt and file2.txt

    head -n 20 file1.txt file2.txt


print the first 10 bytes of a file

    head -c 10 file.txt



# Basic Usage

Print the first lines of a file:

    head <file>


