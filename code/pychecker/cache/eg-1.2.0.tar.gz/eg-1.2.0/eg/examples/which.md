# which

find where on the path ls is found

    which ls


find all the occurrences of ls on the path, not just the first

    which -a ls



# Basic Usage

Find where on an executable will be found if it were executed:

    which <command>


