# mv

rename a file

    mv old_name.txt new_name.txt


move a file to a different directory

    mv foo.txt new_location/foo.txt


move a file but prompt before overwriting

    mv -i foo.txt dirWithFoo/



# Basic Usage

`mv` lets you rename and move files:

    mv <old_location> <new_location>


