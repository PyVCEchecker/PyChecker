# su

switch to user cersei

    su cersei


open a shell session as root

    sudo su



# Basic Usage

Switch to a new user:

    su <username>


Switch to root:

    sudo su


