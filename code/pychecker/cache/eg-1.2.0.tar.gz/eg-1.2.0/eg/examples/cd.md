# cd

change do target-directory

    cd target-directory


change to home directory

    cd ~


change to previous directory

    cd -



# Basic Usage

Change your current working directory to the target directory:

    $ cd <target-directory>
    $ pwd
    <target-directory>


