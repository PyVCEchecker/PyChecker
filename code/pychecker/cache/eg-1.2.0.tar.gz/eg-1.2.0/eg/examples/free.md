# free

show memory usage

    free


show memory usage in megabytes

    free -m



# Basic Usage

Show the memory usage on the system:

    free


