# set

display all variables set in the shell

    set

enable command history

    set -o history

disable command history

    set +o history



# Basic Usage

Enable a shell option:

    set -o <option>


Disable a shell option:

    set +o <option>


