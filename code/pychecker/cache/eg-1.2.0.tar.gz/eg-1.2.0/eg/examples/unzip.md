# unzip

unzip a zipped file

    unzip compressed.zip


unzip a zipped file to path/to/output/dir/

    unzip compressed.zip -d path/to/output/dir/



# Basic Usage

Unzip a zipped file:

    unzip <zipped-file>


