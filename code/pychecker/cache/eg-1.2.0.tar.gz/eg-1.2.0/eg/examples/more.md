# more

page file to stdout

    more file.txt


page file starting at line 25

    more +25 file.txt


page file starting at first line containing "pattern"

    more +/"pattern" file.txt



# Basic Usage

Show the file on `stdout`, paging the input:

    more <file>


Once in `more` use `j` to scroll down, `k` to scroll up, and `q` to quit.


