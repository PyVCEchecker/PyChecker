# expand

replace tabs with four spaces

    expand -t 4 removeTabs.txt



# Basic Usage

Replace tabs with a given number of spaces:

    expand -t <num-spaces> <intput-file>


