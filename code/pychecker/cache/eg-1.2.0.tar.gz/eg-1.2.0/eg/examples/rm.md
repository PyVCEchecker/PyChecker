# rm

delete a file

    rm file.txt


delete a directory and its contents

    rm -r directory



# Basic Usage

Remove a file from the file system:

    rm <file>


Remove a directory with the recursive (`-r`) flag:

    rm -r <directory>


