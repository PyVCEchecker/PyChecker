# whatis

search for entries containing a command

    whatis ls



# Basic Usage

Search a database for entries matching the word or command:

    whatis <command>


