# cat

show file.txt

    cat file.txt


show file.txt with line numbers

    cat -n file.txt


show file with blank lines squeezed to single space

    cat -s double_spaced.txt



# Basic Usage

Show the input file on `stdout`:

    cat <file>


