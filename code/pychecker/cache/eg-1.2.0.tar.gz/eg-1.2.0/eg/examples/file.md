# file

determine the file type of foo.txt

    file foo.txt


keep going and show all the matching file types, not just the first

    file -k index.html


show type by looking inside compressed files

    file -z compressed.gzip


try to classify special files like disk partitions

    file -s /dev/disk0



# Basic Usage

Determine the type of a file:

    file <file>


