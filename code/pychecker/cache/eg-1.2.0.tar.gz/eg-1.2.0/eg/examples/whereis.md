# whereis

find all occurrences of a command in the standard binary locations

    whereis ls



# Basic Usage

Find all the occurrences of an executable or command in the standard binary
locations:

    whereis <command>


