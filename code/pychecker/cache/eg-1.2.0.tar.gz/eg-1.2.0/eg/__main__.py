from eg import core


core.run_eg()
