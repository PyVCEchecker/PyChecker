from .special import *
from .slugify import *


__author__ = 'Val Neekman @ Neekware Inc. [@vneekman]'
__description__ = 'A Python slugify application that also handles Unicode'
__version__ = '5.0.2'
