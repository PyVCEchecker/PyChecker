__version__ = "0.59"
__version_info__ = tuple(__version__.split("."))
