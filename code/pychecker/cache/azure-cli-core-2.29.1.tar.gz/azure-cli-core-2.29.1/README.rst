Microsoft Azure CLI Core Module
==================================

Release History
===============

See `Release History on GitHub <https://github.com/Azure/azure-cli/blob/dev/src/azure-cli-core/HISTORY.rst>`__.
