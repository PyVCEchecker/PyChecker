Welcome to |project| documentation!
===================================

.. toctree::
   :maxdepth: 1

   history

.. include:: ../README.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

