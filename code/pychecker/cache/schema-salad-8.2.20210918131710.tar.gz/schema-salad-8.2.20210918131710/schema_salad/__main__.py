"""Default entry point for the schema-salad module."""

import sys

from . import main

sys.exit(main.main())
