package ${package}.utils;

public class SavableImpl implements Savable {
  public SavableImpl(Object doc, String baseUri, LoadingOptions loadingOptions, String docRoot) {}
}
