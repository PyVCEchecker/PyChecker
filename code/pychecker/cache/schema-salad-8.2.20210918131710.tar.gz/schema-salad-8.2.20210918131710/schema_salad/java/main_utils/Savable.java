package ${package}.utils;

public interface Savable {
  // TODO: implement writable interface
  // public abstract void save(boolean top, String baseUrl, boolean relativeUris);
}
