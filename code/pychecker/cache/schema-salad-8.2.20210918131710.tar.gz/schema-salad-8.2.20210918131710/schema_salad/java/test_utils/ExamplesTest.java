package ${package}.utils;

public class ExamplesTest {
${example_tests}
}
