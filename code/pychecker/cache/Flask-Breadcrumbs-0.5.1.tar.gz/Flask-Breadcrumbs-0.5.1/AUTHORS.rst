Authors
=======

Flask-Breadcrumbs is developed for use in
`Invenio <http://inveniosoftware.org>`_ digital library software.

Contact us at `info@inveniosoftware.org <mailto:info@inveniosoftware.org>`_

* Krzysztof Lis <krzysztof.lis@cern.ch>
* Jiri Kuncar <jiri.kuncar@cern.ch>
* Tibor Simko <tibor.simko@cern.ch>
* Pierre Lucas <pierre.lucas@altie.fr>
* Joshua Arnott <josh@snorfalorpagus.net>
* Florian Merges <fmerges@fstarter.org>
* Nicholas Rutherford <zgithub@isomorphism.ca>
* Tianhui Michael Li <>
