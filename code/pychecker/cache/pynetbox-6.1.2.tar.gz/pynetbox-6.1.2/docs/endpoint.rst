Endpoint
========

.. autoclass:: pynetbox.core.endpoint.Endpoint
  :members:

.. autoclass:: pynetbox.core.endpoint.DetailEndpoint
  :members: