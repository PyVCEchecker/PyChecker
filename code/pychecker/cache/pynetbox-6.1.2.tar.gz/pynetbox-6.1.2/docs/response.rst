Response
========

.. autoclass:: pynetbox.core.response.Record
  :members:

.. autoclass:: pynetbox.core.response.RecordSet
  :members:
