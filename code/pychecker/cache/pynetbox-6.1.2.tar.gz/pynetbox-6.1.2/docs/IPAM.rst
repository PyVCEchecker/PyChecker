IPAM
========

.. autoclass:: pynetbox.models.ipam.Prefixes
  :members: