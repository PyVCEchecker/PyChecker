from __future__ import absolute_import
from .colors import *
from .csscolors import *
from .version import __version__
