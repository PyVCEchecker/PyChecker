import pytest


@pytest.fixture(autouse=True)
def setup(memory_mocker):
    pass
