from .common import (  # noqa
    generate_lll_for_function,
    is_default_func,
    is_initializer,
)
