import enumfields


def test_version():
    assert isinstance(enumfields.__version__, str)
