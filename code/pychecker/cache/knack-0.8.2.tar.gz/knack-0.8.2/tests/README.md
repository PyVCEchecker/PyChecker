Running all tests
-----------------

```
python -m unittest discover tests
```

Running specific test
---------------------

```
python <test_file.py> Class.method
```



