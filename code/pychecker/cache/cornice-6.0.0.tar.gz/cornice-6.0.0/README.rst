=======
Cornice
=======

|readthedocs| |pypi| |travis| |master-coverage|

.. |travis| image:: https://travis-ci.org/Cornices/cornice.svg?branch=master
    :target: https://travis-ci.org/Cornices/cornice

.. |readthedocs| image:: https://readthedocs.org/projects/cornice/badge/?version=latest
    :target: https://cornice.readthedocs.io/en/latest/
    :alt: Documentation Status

.. |master-coverage| image::
    https://coveralls.io/repos/Cornices/cornice/badge.svg?branch=master
    :alt: Coverage
    :target: https://coveralls.io/r/Cornices/cornice

.. |pypi| image:: https://img.shields.io/pypi/v/cornice.svg
    :target: https://pypi.python.org/pypi/cornice


**Cornice** provides helpers to build & document Web Services with Pyramid.

The full documentation is available at: https://cornice.readthedocs.io
