"""Behave BDD integration for Django"""

__author__ = 'Mitchel Cabuloy'
__maintainer__ = 'Mitchel Cabuloy, Peter Bittner'
__email__ = 'mixxorz@gmail.com'
__url__ = 'https://github.com/behave/behave-django'
__license__ = 'MIT'
__version__ = '1.4.0'
