Core API (albumentations.core)
==============================

Composition
-----------
.. automodule:: albumentations.core.composition
    :members:

Transforms interface
--------------------
.. automodule:: albumentations.core.transforms_interface
    :members:

Serialization
--------------------
.. automodule:: albumentations.core.serialization
    :members:
