# I have
* [ ] Tested with the latest release
* [ ] Tested with the current master branch
* [ ] Searched for similar existing issues

## Expected behaviour

## Actual behaviour

## Steps to reproduce the behaviour

1.

## Configuration

* Operating system version:
* Search engine version:
* Python version:
* pysolr version:
