# encoding: utf-8

from __future__ import absolute_import, print_function, unicode_literals

from .test_admin import *  # NOQA
from .test_client import *  # NOQA
from .test_cloud import *  # NOQA
