Arpeggio - Parser interpreter based on PEG grammars

Author: Igor R. Dejanović <igor DOT dejanovic AT gmail DOT com>


# Contributors

- Bug reports/ideas: https://github.com/textX/Arpeggio/issues?utf8=%E2%9C%93&q=is%3Aissue
- Code/docs contributions:
  - https://github.com/textX/Arpeggio/graphs/contributors
  - https://github.com/textX/Arpeggio/pulls?utf8=%E2%9C%93&q=is%3Apr+
