Authors and contributors, in no particular order:

* Ron Weiss
* Shiqiao Du
* Jaques Grobler
* David Cournapeau
* Fabian Pedregosa
* Gael Varoquaux
* Andreas Mueller
* Bertrand Thirion
* Daniel Nouri
* Gilles Louppe
* Jake Vanderplas
* John Benediktsson
* Lars Buitinck
* Mikhail Korobov
* Robert McGibbon
* Stefano Lattarini
* Vlad Niculae
* csytracy
* Alexandre Gramfort
* Sergei Lebedev
* Daniela Huppenkothen
* Christopher Farrow
* Alexandr Yanenko
* Antony Lee
