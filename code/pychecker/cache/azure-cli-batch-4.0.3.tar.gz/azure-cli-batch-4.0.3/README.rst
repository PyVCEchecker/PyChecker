Microsoft Azure CLI 'batch' Command Module
==========================================

This package is for the 'batch' module.
i.e. 'az batch'


