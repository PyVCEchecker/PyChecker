``sphinxcontrib.httpdomain``
============================

.. image:: https://badge.fury.io/py/sphinxcontrib-httpdomain.svg
   :target: https://pypi.org/project/sphinxcontrib-httpdomain/
   :alt: Latest PyPI version

.. image:: https://readthedocs.org/projects/sphinxcontrib-httpdomain/badge/
   :target: https://sphinxcontrib-httpdomain.readthedocs.io/
   :alt: Documentation Status

.. image:: https://travis-ci.org/sphinx-contrib/httpdomain.svg?branch=main
   :alt: Build Status
   :target: https://travis-ci.org/sphinx-contrib/httpdomain

This contrib extension, ``sphinxcontrib.httpdomain``, provides a Sphinx
domain for describing HTTP APIs.

You can find the documentation from the following URL:

https://sphinxcontrib-httpdomain.readthedocs.io/
