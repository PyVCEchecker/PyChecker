"""All the checks are organized into modules and places here."""
