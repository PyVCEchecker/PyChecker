"""Various consistency checks."""
