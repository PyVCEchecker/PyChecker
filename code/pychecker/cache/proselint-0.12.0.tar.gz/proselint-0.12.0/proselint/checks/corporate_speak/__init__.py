"""Corporate-speak."""
