"""Avoid skunked terms."""
