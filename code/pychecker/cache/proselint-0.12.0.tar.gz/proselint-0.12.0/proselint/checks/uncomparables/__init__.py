"""Comparing an uncomparable."""
