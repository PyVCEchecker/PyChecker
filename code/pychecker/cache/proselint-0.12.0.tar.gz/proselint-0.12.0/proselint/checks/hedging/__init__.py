"""Hedging."""
