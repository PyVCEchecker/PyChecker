"""Airlinese."""
