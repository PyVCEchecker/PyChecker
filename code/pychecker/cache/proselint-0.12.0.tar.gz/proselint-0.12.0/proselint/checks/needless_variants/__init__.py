"""Needless variants."""
