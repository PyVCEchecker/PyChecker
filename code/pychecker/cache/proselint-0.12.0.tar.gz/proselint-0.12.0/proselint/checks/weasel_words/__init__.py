"""Weasel words."""
