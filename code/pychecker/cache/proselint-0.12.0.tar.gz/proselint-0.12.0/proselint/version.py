"""Proselint version number."""

__version__ = "0.12.0"
