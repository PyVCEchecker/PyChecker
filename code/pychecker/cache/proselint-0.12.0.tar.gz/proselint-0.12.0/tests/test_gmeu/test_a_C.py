#!/usr/bin/env python

"""Test GMEU entry 'a', part C.

This entry is about pronunciation of the word 'a' and is unlikely to be
relevant to usage in written language.
"""
