from browser import document


def setup_page():
    document["topHeader"].textContent = "Brython Examples:"
