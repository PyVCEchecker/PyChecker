### <img src="https://seleniumbase.io/img/logo3a.png" title="SeleniumBase" width="32" /> GitHub Integrations

> **Table of Contents / Navigation:**
> - [**Actions/Workflows**](https://github.com/seleniumbase/SeleniumBase/blob/master/integrations/github/workflows/ReadMe.md)
> - [**Extras/Action-Integrations**](https://github.com/seleniumbase/SeleniumBase/blob/master/integrations/github/workflows/extras.md)
