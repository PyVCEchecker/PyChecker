### <img src="https://seleniumbase.io/img/logo3a.png" title="SeleniumBase" width="28" /> SeleniumBase Workflows

> **Table of Contents / Navigation:**
> - [**CI build**](workflows/python-package.yml)
