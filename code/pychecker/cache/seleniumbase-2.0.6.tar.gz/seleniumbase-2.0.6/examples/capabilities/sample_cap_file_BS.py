# Desired capabilities example file for BrowserStack
# Generate from https://www.browserstack.com/automate/capabilities
desired_cap = {
    "os": "OS X",
    "os_version": "High Sierra",
    "browser": "Chrome",
    "browser_version": "77.0",
    "browserstack.local": "false",
    "browserstack.selenium_version": "3.141.59",
}
