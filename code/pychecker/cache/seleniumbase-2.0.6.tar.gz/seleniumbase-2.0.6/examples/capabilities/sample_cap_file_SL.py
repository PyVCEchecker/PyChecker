# Desired capabilities example file for Sauce Labs
# Generate from https://wiki.saucelabs.com/display/DOCS/Platform+Configurator#/
capabilities = {
    "browserName": "firefox",
    "browserVersion": "70.0",
    "platformName": "macOS 10.13",
    "sauce:options": {},
}
