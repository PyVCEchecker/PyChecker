from seleniumbase import BaseCase


class NullTests(BaseCase):
    def test_null(self):
        pass
