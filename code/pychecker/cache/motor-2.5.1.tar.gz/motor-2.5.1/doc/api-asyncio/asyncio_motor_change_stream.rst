:class:`~motor.motor_asyncio.AsyncIOMotorChangeStream`
======================================================

.. currentmodule:: motor.motor_asyncio

.. autoclass:: AsyncIOMotorChangeStream
  :members:
