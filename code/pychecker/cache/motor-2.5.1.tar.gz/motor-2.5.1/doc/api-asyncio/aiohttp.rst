:mod:`motor.aiohttp` - Integrate Motor with the aiohttp web framework
=====================================================================

.. currentmodule:: motor.aiohttp

.. automodule:: motor.aiohttp
   :members:
   :no-inherited-members:
