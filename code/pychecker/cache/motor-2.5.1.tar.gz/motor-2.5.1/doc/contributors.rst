Contributors
============
The following is a list of people who have contributed to
**Motor**. If you belong here and are missing please let us know
(or send a pull request after adding yourself to the list):

- A\. Jesse Jiryu Davis
- Eren Güven
- Jorge Puente Sarrín
- Rémi Jolin
- Andrew Svetlov
- Nikolay Novik
- Prashant Mital
- Shane Harvey
- Bulat Khasanov
- William Zhou
