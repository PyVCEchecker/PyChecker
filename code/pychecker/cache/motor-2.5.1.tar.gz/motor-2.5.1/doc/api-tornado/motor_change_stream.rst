:class:`~motor.motor_tornado.MotorChangeStream`
===============================================

.. currentmodule:: motor.motor_tornado

.. autoclass:: MotorChangeStream
  :members:
