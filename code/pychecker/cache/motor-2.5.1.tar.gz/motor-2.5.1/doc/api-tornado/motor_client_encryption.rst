:class:`~motor.motor_tornado.MotorClientEncryption`
===================================================

.. currentmodule:: motor.motor_tornado

.. autoclass:: MotorClientEncryption
  :members: