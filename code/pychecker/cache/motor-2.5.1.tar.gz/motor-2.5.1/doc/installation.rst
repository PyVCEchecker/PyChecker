Installation
============

Install Motor from PyPI_ with pip_::

  $ python3 -m pip install motor

Pip automatically installs Motor's prerequisite packages.
See :doc:`requirements`.

To install Motor from sources, you can clone its git repository and do::

  $ python3 -m pip install .

.. _PyPI: http://pypi.python.org/pypi/motor

.. _pip: http://pip-installer.org
