"""
These procedures implement internal functions for the GNU libc that commonly appears on linux systems
"""
