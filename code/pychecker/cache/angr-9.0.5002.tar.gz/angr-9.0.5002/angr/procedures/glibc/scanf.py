
from ..libc.scanf import scanf
from ..libc.fscanf import fscanf

class __isoc99_scanf(scanf):
    pass

class __isoc99_fscanf(fscanf):
    pass
