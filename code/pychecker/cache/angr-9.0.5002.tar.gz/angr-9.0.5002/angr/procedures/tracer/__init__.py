"""
These procedures implement system calls for the cgc DECREE platform, in a
specific way for tracing.
"""
