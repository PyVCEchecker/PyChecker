"""
These functions implement those found in the various versions of msvcr.dll
(Microsoft Visual C/C++ Runtime)
"""
