"""
These procedures implement functions described in the C standard library specification
"""
