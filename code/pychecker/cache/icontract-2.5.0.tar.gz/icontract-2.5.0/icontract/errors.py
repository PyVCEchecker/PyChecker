"""Define public errors and exceptions."""


class ViolationError(AssertionError):
    """Indicate a violation of a contract."""
