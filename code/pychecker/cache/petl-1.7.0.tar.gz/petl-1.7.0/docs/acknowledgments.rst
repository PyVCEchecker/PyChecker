Acknowledgments
===============

This is community-maintained software. The following people have contributed to
the development of this package:

* Alexander Stauber
* Alistair Miles (`alimanfoo <https://github.com/alimanfoo>`_)
* Andreas Porevopoulos (`sv1jsb <https://github.com/sv1jsb>`_)
* Andrew Kim (`andrewakim <https://github.com/andrewakim>`_)
* Brad Maggard (`bmaggard <https://github.com/bmaggard>`_)
* Caleb Lloyd (`caleblloyd <https://github.com/caleblloyd>`_)
* César Roldán (`ihuro <https://github.com/ihuro>`_)
* Chris Lasher (`gotgenes <https://github.com/gotgenes>`_)
* Dean Way (`DeanWay <https://github.com/DeanWay>`_)
* Dustin Engstrom (`engstrom <https://github.com/engstrom>`_)
* Florent Xicluna (`florentx <https://github.com/florentx>`_)
* Henry Rizzi (`henryrizzi <https://github.com/henryrizzi>`_)
* Jonathan Camile (`deytao <https://github.com/deytao>`_)
* Jonathan Moss (`a-musing-moose <https://github.com/a-musing-moose>`_)
* Kenneth Borthwick
* Krisztián Fekete (`krisztianfekete <https://github.com/krisztianfekete>`_)
* Matt Katz (`mattkatz <https://github.com/mattkatz>`_)
* Matthew Scholefield (`MatthewScholefield <https://github.com/MatthewScholefield>`_)
* Michael Rea (`rea725 <https://github.com/rea725>`_)
* Olivier Macchioni (`omacchioni <https://github.com/omacchioni>`_)
* Olivier Poitrey (`rs <https://github.com/rs>`_)
* Pablo Castellano (`PabloCastellano <https://github.com/PabloCastellano>`_)
* Paul Jensen (`psnj <https://github.com/psnj>`_)
* Paulo Scardine (`scardine <https://github.com/scardine>`_)
* Peder Jakobsen (`pjakobsen <https://github.com/pjakobsen>`_)
* Phillip Knaus (`phillipknaus <https://github.com/phillipknauss>`_)
* Richard Pearson (`podpearson <https://github.com/podpearson>`_)
* Robert DeSimone (`icenine457 <https://github.com/icenine457>`_)
* Robin Moss (`LupusUmbrae <https://github.com/LupusUmbrae>`_)
* Roger Woodley (`rogerkwoodley <https://github.com/rogerkwoodley>`_)
* Tucker Beck (`dusktreader <https://github.com/dusktreader>`_)
* Viliam Segeďa (`vilos <https://github.com/vilos>`_)
* Zach Palchick (`palchicz <https://github.com/palchicz>`_)
* `adamsdarlingtower <https://github.com/adamsdarlingtower>`_
* `hugovk <https://github.com/hugovk>`_
* `imazor <https://github.com/imazor>`_
* `james-unified <https://github.com/james-unified>`_
* `Mgutjahr <https://github.com/Mgutjahr>`_
* `shayh <https://github.com/shayh>`_
* `thatneat <https://github.com/thatneat>`_
* `titusz <https://github.com/titusz>`_
* `zigen <https://github.com/zigen>`_

Development of petl has been supported by an open source license for
`PyCharm <https://www.jetbrains.com/pycharm/>`_.
