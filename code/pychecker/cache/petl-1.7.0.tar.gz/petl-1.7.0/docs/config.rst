Configuration
===============================

.. automodule:: petl.config
    :members:

