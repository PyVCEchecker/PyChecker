Contributing
============

Please see the [project documentation](http://petl.readthedocs.io/en/stable/contributing.html) for information about contributing to petl.
