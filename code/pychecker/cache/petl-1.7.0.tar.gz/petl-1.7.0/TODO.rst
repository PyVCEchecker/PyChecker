v1.0
====

DONE refector config, especially look and display defaults
look_limit
look_index_header
display_limit
display_index_header
sort_buffersize

DONE change so index_header is False by default in representations

DONE redo all docstring examples

DONE add subsection to changes in 1.0 about 'u' functions removed

DONE add subsection to changes in 1.0 about config

DONE make sure use field names rather than naked header

DONE integrate dbtests with other tests

DONE add documentation about contributing

DONE add running stats

DONE revise documentation about dependencies, add information about optional
dependencies

DONE port petlx.array

DONE port petlx.dataframe

DONE port petlx.xls

DONE port petlx.xlsx

DONE port petlx.hdf5

DONE port petlx.sql

DONE merge sqlite3 module into db module

DONE port petlx.interval

DONE port petlx.index

DONE add documentation to changes section about ported xls, xlsx, array,
dataframe, hdf5, sql, intervals, merged sqlite3 ...

DONE validate module: implementation, documentation

DONE look truncate

DONE display truncate

DONE review all issues
