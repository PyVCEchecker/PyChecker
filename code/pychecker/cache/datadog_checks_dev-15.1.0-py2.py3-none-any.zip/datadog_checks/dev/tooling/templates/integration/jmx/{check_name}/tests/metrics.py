{license_header}
from datadog_checks.dev.jmx import JVM_E2E_METRICS_NEW

METRICS = [
    # integration metrics
] + JVM_E2E_METRICS_NEW
