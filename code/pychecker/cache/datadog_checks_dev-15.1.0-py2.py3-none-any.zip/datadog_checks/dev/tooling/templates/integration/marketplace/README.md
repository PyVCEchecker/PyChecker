# {integration_name}

## Overview
High level overview of what this integration does
Usually includes a screenshot

All `###` headers are optional to showcase what this integration includes

### Metrics

### Events

### Monitors

### Dashboards

## Setup
Specific step-by-step configuration instructions for this integration.

## Support
Information about how and where to go for support for this integration
