Dictionary Exporter
===================

.. automodule:: anytree.exporter.dictexporter
