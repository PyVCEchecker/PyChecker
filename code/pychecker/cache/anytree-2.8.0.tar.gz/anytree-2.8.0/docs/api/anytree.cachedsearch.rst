Cached Searching
================

.. automodule:: anytree.cachedsearch
