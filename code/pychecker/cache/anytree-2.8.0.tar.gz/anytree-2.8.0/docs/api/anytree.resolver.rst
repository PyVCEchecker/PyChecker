Node Resolution
===============

.. automodule:: anytree.resolver
