Dictionary Importer
===================

.. automodule:: anytree.importer.dictimporter
