from social_core.backends.yahoo import YahooOpenId, YahooOAuth, YahooOAuth2
