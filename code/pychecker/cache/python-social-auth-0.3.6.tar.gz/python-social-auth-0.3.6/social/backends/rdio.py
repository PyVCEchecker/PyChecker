from social_core.backends.rdio import BaseRdio, RdioOAuth1, RdioOAuth2
