from social_core.backends.withings import WithingsOAuth
