from social_core.backends.bitbucket import BitbucketOAuthBase, \
    BitbucketOAuth2, BitbucketOAuth
