from social_core.backends.vend import VendOAuth2
