from social_core.backends.beats import BeatsOAuth2
