from social_core.backends.khanacademy import BrowserBasedOAuth1, \
    KhanAcademyOAuth1
