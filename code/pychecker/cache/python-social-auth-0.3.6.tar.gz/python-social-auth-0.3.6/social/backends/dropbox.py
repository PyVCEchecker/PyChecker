from social_core.backends.dropbox import DropboxOAuth, DropboxOAuth2
