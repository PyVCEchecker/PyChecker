from social_core.backends.untappd import UntappdOAuth2
