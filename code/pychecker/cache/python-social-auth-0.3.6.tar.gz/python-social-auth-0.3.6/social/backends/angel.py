from social_core.backends.angel import AngelOAuth2
