from social_core.backends.open_id import OpenIdAuth, \
    OpenIdConnectAssociation, OpenIdConnectAuth
