from social_core.backends.arcgis import ArcGISOAuth2
