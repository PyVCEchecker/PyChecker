from social_core.backends.strava import StravaOAuth
