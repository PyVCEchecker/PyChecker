from social_core.backends.amazon import AmazonOAuth2
