from social_core.backends.pixelpin import PixelPinOAuth2
