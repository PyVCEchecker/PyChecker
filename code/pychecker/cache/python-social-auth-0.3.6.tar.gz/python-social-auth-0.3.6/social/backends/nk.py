from social_core.backends.nk import NKOAuth2
