from social_core.backends.suse import OpenSUSEOpenId
