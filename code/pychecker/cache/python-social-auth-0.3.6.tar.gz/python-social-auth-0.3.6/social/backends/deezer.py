from social_core.backends.deezer import DeezerOAuth2
