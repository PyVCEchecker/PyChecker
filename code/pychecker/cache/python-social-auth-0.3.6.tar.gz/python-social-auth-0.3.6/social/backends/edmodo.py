from social_core.backends.edmodo import EdmodoOAuth2
