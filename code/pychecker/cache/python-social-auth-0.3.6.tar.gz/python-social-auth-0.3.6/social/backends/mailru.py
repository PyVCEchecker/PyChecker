from social_core.backends.mailru import MailruOAuth2
