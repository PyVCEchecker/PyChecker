from social_core.backends.saml import SAMLIdentityProvider, \
    DummySAMLIdentityProvider, SAMLAuth
