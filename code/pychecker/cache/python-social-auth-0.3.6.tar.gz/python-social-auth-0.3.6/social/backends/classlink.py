from social_core.backends.classlink import ClasslinkOAuth
