from social_core.backends.qq import QQOAuth2
