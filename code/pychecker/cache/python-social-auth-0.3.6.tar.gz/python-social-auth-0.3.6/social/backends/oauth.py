from social_core.backends.oauth import OAuthAuth, BaseOAuth1, BaseOAuth2
