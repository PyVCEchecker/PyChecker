from social_core.backends.vk import VKontakteOpenAPI, VKOAuth2, VKAppOAuth2, \
    vk_api
