from social_core.backends.slack import SlackOAuth2
