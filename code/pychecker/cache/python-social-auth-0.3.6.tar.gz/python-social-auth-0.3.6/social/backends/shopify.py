from social_core.backends.shopify import ShopifyOAuth2
