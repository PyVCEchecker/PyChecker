from social_core.backends.lastfm import LastFmAuth
