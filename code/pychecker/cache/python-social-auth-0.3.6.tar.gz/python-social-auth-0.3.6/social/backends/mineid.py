from social_core.backends.mineid import MineIDOAuth2
