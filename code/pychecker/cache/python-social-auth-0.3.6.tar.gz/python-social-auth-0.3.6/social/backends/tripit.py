from social_core.backends.tripit import TripItOAuth
