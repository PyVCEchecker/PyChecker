from social_core.backends.gae import GoogleAppEngineAuth
