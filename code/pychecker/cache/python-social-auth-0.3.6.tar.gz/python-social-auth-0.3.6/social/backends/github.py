from social_core.backends.github import GithubOAuth2, GithubMemberOAuth2, \
    GithubOrganizationOAuth2, GithubTeamOAuth2
