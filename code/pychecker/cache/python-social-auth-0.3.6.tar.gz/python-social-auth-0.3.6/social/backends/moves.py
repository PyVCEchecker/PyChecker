from social_core.backends.moves import MovesOAuth2
