from social_core.backends.azuread import AzureADOAuth2
