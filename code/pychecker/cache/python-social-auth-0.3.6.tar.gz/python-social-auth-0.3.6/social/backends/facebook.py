from social_core.backends.facebook import FacebookOAuth2, FacebookAppOAuth2
