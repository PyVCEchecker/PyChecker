from social_core.backends.fedora import FedoraOpenId
