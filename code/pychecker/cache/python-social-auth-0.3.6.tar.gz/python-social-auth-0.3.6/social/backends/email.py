from social_core.backends.email import EmailAuth
