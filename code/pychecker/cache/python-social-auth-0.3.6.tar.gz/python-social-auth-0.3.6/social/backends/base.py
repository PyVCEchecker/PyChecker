from social_core.backends.base import BaseAuth
