from social_core.backends.jawbone import JawboneOAuth2
