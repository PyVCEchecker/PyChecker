from social_core.backends.orbi import OrbiOAuth2
