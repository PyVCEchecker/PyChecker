from social_core.backends.twitter import TwitterOAuth
