from social_core.backends.dribbble import DribbbleOAuth2
