from social_core.backends.tumblr import TumblrOAuth
