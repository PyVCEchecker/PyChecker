from social_core.backends.flickr import FlickrOAuth
