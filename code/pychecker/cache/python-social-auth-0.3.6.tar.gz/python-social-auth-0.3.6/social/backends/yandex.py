from social_core.backends.yandex import YandexOpenId, YandexOAuth2, YaruOAuth2
