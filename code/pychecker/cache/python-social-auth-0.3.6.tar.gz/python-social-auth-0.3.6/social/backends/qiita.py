from social_core.backends.qiita import QiitaOAuth2
