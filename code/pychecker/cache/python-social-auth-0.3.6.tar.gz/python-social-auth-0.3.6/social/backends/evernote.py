from social_core.backends.evernote import EvernoteOAuth, EvernoteSandboxOAuth
