from social_core.backends.yammer import YammerOAuth2, YammerStagingOAuth2
