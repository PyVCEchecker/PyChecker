from social_core.backends.coding import CodingOAuth2
