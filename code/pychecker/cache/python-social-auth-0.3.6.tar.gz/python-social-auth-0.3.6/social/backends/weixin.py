from social_core.backends.weixin import WeixinOAuth2, WeixinOAuth2APP
