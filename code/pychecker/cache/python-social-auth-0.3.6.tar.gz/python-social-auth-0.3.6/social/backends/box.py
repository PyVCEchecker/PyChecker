from social_core.backends.box import BoxOAuth2
