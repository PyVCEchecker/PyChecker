from social_core.backends.goclioeu import GoClioEuOAuth2
