from social_core.backends.odnoklassniki import OdnoklassnikiOAuth2, \
    OdnoklassnikiApp, odnoklassniki_oauth_sig, odnoklassniki_iframe_sig, \
    odnoklassniki_api
