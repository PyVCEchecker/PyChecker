from social_core.backends.mendeley import MendeleyMixin, MendeleyOAuth, \
    MendeleyOAuth2
