from social_core.backends.ubuntu import UbuntuOpenId
