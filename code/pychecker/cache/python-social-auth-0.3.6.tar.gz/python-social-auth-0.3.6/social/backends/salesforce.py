from social_core.backends.salesforce import SalesforceOAuth2, \
    SalesforceOAuth2Sandbox
