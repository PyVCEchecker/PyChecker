from social_core.backends.linkedin import BaseLinkedinAuth, LinkedinOAuth, \
    LinkedinOAuth2
