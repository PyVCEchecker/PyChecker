from social_core.backends.coursera import CourseraOAuth2
