from social_core.backends.ngpvan import ActionIDOpenID
