from social_core.backends.docker import DockerOAuth2
