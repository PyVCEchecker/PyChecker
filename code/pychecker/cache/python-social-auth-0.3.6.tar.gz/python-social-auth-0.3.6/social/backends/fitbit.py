from social_core.backends.fitbit import FitbitOAuth1, FitbitOAuth2
