from social_core.backends.douban import DoubanOAuth, DoubanOAuth2
