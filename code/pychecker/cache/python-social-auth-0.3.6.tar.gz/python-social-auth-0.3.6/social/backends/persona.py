from social_core.backends.persona import PersonaAuth
