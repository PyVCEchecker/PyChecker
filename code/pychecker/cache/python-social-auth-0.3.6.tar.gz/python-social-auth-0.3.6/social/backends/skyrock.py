from social_core.backends.skyrock import SkyrockOAuth
