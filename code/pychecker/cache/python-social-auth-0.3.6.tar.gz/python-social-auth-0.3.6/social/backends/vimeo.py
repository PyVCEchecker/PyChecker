from social_core.backends.vimeo import VimeoOAuth1, VimeoOAuth2
