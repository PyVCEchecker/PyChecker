from social_core.backends.xing import XingOAuth
