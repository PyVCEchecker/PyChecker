from social_core.backends.weibo import WeiboOAuth2
