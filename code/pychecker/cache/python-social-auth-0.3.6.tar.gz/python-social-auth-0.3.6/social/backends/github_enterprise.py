from social_core.backends.github_enterprise import GithubEnterpriseMixin, \
    GithubEnterpriseOAuth2, GithubEnterpriseOrganizationOAuth2, \
    GithubEnterpriseTeamOAuth2
