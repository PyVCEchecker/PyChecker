from social_core.backends.naver import NaverOAuth2
