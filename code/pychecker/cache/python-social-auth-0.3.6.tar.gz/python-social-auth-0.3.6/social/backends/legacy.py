from social_core.backends.legacy import LegacyAuth
