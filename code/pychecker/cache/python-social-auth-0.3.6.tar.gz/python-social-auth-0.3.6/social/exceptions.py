from social_core.exceptions import SocialAuthBaseException, WrongBackend, \
    MissingBackend, NotAllowedToDisconnect, AuthException, AuthFailed, \
    AuthCanceled, AuthUnknownError, AuthTokenError, AuthMissingParameter, \
    AuthStateMissing, AuthStateForbidden, AuthAlreadyAssociated, \
    AuthTokenRevoked, AuthForbidden, AuthUnreachableProvider, InvalidEmail
