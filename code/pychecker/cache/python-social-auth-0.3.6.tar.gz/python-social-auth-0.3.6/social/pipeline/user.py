from social_core.pipeline.user import USER_FIELDS, get_username, create_user, \
    user_details
