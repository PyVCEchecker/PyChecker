from social_core.pipeline.social_auth import social_details, social_uid, \
    auth_allowed, social_user, associate_user, associate_by_email, \
    load_extra_data
