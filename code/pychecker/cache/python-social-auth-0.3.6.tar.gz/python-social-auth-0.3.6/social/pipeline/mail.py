from social_core.pipeline.mail import mail_validation
