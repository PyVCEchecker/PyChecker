from social_core.pipeline.partial import save_status_to_session, partial
