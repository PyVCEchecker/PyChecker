from social_core.pipeline.utils import SERIALIZABLE_TYPES, partial_to_session, \
    partial_from_session
