from social_core.pipeline import DEFAULT_AUTH_PIPELINE, \
    DEFAULT_DISCONNECT_PIPELINE
