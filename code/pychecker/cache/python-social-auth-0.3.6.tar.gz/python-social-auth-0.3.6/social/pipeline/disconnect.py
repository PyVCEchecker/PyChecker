from social_core.pipeline.disconnect import allowed_to_disconnect, \
    get_entries, revoke_tokens, disconnect
