from social_core.strategy import BaseTemplateStrategy, BaseStrategy
