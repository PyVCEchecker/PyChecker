from social_cherrypy.strategy import CherryPyJinja2TemplateStrategy, \
    CherryPyStrategy
