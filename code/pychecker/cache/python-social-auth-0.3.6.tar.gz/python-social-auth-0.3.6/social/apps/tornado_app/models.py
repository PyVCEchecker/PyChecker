from social_tornado.models import TornadoStorage, init_social
