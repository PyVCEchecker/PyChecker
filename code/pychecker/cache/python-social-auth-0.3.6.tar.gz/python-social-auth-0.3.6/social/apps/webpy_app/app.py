from social_webpy.app import BaseViewClass, auth, complete, disconnect
