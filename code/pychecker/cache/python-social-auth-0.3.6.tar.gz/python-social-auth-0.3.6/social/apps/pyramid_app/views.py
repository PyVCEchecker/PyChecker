from social_pyramid.views import auth, complete, disconnect
