from social_flask_peewee.models import FlaskStorage, init_social
