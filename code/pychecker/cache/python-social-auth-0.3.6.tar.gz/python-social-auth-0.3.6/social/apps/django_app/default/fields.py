from social_django.fields import JSONField
