from social_django.urls import urlpatterns, app_name
