from social_django.context_processors import LazyDict, backends, login_redirect
