from social_django.views import auth, complete, disconnect, _do_login
