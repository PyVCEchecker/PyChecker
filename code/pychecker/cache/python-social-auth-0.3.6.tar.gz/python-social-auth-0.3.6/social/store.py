from social_core.store import OpenIdStore, OpenIdSessionWrapper
