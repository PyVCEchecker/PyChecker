Fields
======

.. automodule:: autoslug.fields
   :members:
