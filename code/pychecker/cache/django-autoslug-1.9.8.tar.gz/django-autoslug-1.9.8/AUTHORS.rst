Authors
~~~~~~~

The django-autoslug library is currently maintained by:

* Justin Mayer <https://justinmayer.com/>

It was originally created by:

* Andy Mikhailenko <neithere@gmail.com>

Here is a probably incomplete list of contributors -- people
who have submitted patches, reported bugs, added translations and
generally made django-autoslug better:

* Steve Steiner
* Blake Imsland
* Ollie Rutherfurd
* Mikhail Korobov
* Remco Wendt
* Johan Charpentier
* Nicolás Echániz
* Aaron VanDerlip
* Thomas Woolford
* Jannis Leidel
* Caio Ariede
* Venelin Stoykov
* Bertrand Bordage
* Davor Teskera
* Florian Apolloner
* Fabio Caccamo
* Thomas Schreiber
* Mike Urbanski
* Vadim Iskuchekov
* kane-c
* Julien Dubiel
* Tony Shtarev
* Éloi Rivard
* Peter Baumgartner
* Jernej Kos
* Sutrisno Efendi
* Your Name Here ;)
