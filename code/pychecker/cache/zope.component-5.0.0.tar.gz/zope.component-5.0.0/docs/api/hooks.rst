==========================================================
 ``zope.component.hooks``: The current component registry
==========================================================

.. seealso:: :doc:`../hooks` for narrative documentation and examples.

.. automodule:: zope.component.hooks
   :noindex:
