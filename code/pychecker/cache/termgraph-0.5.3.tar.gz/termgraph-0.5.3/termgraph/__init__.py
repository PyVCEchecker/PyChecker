import sys
from os.path import dirname
sys.path.append(dirname(__file__))
from termgraph import *