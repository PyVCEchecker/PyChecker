# glom outreach

## Interesting stack overflow questions to answer

Some of these may be more amenable to remapping.

1. https://stackoverflow.com/questions/1602934/check-if-a-given-key-already-exists-in-a-dictionary 2,627,182
1. https://stackoverflow.com/questions/38987/how-to-merge-two-dictionaries-in-a-single-expression 1,391,000
1. https://stackoverflow.com/questions/952914/how-to-make-a-flat-list-out-of-list-of-lists 1,388,600
1. https://stackoverflow.com/questions/4984647/accessing-dict-keys-like-an-attribute 128,380
1. https://stackoverflow.com/questions/6027558/flatten-nested-python-dictionaries-compressing-keys 75,500
1. https://stackoverflow.com/questions/651794/whats-the-best-way-to-initialize-a-dict-of-dicts-in-python 66,390
1. https://stackoverflow.com/questions/2213923/removing-duplicates-from-a-list-of-lists 60,962
1. https://stackoverflow.com/questions/9285086/access-dict-key-and-return-none-if-doesnt-exist 33,140
1. https://stackoverflow.com/questions/10632839/transform-list-of-tuples-into-a-flat-list-or-a-matrix 23,128
1. https://stackoverflow.com/questions/16204076/pep8-compliant-deep-dictionary-access 2,647
1. https://stackoverflow.com/questions/21297475/set-a-value-deep-in-a-dict-dynamically 1,017
1. https://stackoverflow.com/questions/22377725/python-linq-like-methods 947
1. https://stackoverflow.com/questions/11515620/safely-access-objects-in-python-without-try-catch 368
1. https://stackoverflow.com/questions/48262059/recursively-flatten-nested-list-in-python 89
1. https://stackoverflow.com/questions/23106895/how-to-use-a-string-to-safely-access-deep-python-properties 55

## Completed answers

If you're reading this, upvote!

1. https://stackoverflow.com/a/54656024/178013
1. https://stackoverflow.com/a/53354398/178013
1. https://stackoverflow.com/questions/53108624/using-python-module-glom-extract-irregular-nested-lists-into-a-flattened-list-o
1. https://stackoverflow.com/questions/54078102/get-value-of-nested-attribute-by-filtering-list-on-other-attribute-with-python-g
1. https://stackoverflow.com/questions/38220370/is-there-a-way-to-execute-jq-from-python/55017219#55017219 <- great answer!
