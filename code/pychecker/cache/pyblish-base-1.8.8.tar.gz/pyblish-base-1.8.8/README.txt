Pyblish
=======

Plug-in driven automation framework for content.

Built for platform, software and language agnosticism. Free, community-driven and licensed under LGPLv3.

`See our website`_ for more information

.. _`See our website`: http://pyblish.com
