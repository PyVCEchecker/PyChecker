import warnings
from .util import *

warnings.warn("main.py deprecated; use util.py")
