Microsoft Azure CLI 'DevTestLabs' Command Module
================================================
