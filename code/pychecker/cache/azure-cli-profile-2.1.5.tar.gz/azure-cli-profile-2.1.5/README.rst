Microsoft Azure CLI 'profile' Command Module
============================================

This package is for the 'profile' module.
e.g. 'az account'
e.g. 'az login'
e.g. 'az logout'


