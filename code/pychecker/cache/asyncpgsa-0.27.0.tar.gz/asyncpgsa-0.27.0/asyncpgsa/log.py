import logging

query_logger = logging.getLogger('asyncpgsa.query')
