"""
This is for unit testing things that use this library.
This module creates mocks for all the objects used in this library.
"""

from .mockpool import MockSAPool
from .mockpgsingleton import MockPG


