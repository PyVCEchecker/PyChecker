Microsoft Azure CLI 'network' Command Module
============================================

This package is for the 'network' module.
i.e. 'az network'
