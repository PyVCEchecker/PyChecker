from .heap import SkewHeap, PairingHeap
from .list import LinkedList, Stack, Queue, Deque as ListDeque
from .trie import Vector
from .finger import Deque
#from .dict import Dict
#from .tree import FingerTree
