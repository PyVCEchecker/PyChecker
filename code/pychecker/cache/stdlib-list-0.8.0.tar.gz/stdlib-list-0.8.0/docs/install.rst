Installation
============

The easy way is via ``pip``:

::

    pip install stdlib-list

The hard way is to clone this repository, go into the directory into which you cloned this repo, and do a

::

    python setup.py install
