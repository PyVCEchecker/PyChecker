import unittest

from tests.test_basic import *
from tests.test_platform import *

if __name__ == "__main__":
    unittest.main()
