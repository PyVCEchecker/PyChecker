class NotificationError(Exception):
	pass
