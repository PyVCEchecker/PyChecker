from .base import BaseConfig


class AppModelConfig(BaseConfig):
	"""Future home of the Application Model conf adapter

	Supports multiple applications in the database.
	"""

	pass
