==============================================
 Python Bindings for the OpenStack Images API
==============================================

This is a client for the OpenStack Images API. There's :doc:`a Python
API <reference/api/modules>` (the :mod:`glanceclient` module) and a
:doc:`command-line script <cli/glance>` (installed as
:program:`glance`).

.. toctree::
   :maxdepth: 2

   reference/index
   cli/index

