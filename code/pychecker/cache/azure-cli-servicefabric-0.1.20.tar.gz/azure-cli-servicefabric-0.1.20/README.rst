Microsoft Azure CLI Service Fabric Module
=========================================

This package is for the `sf` module. It contains commands that can be used
to manage Service Fabric clusters.