.. :changelog:

Release History
===============

0.1.20
++++++
* Minor fixes.

0.1.19
++++++
* Upgrade azure-mgmt-storage from 3.1.1 to 3.3.0

0.1.18
++++++
* Minor fixes.

0.1.17
++++++
* Minor fixes.

0.1.16
++++++
* Minor fixes.

0.1.15
++++++
* Minor fixes.

0.1.14
++++++
* sf cluster list: Fix issue 'ClusterListResult is not iterable.

0.1.13
++++++
* Minor fixes.

0.1.12
++++++
* Minor fixes

0.1.11
++++++
* Updated dependencies.

0.1.10
++++++
* Minor fixes

0.1.9
+++++
* Minor fixes

0.1.8
+++++
* Minor fixes

0.1.7
+++++
* Minor fixes

0.1.6
+++++
* Minor fixes

0.1.5
+++++
* Minor fixes

0.1.4
+++++
* Minor fixes

0.1.3
+++++
* Minor fixes

0.1.2
+++++
* Update azure-mgmt-servicefabric to 0.2.0

0.1.1
+++++
* Minor fixes

0.1.0
+++++
* BREAKING CHANGE: 'show' commands log error message and fail with exit code of 3 upon a missing resource.

0.0.13
++++++
* Minor fixes.

0.0.12
++++++
* `sdist` is now compatible with wheel 0.31.0

0.0.11
++++++
* Support Autorest 3.0 based SDKs

0.0.10
++++++
* Minor fixes.

0.0.9
++++++
* Added detailed errors to validation response when creating cluster.
* Fix missing client issue with several commands.

0.0.8
++++++
* Update for CLI core changes.

0.0.7
+++++
* Minor fixes.

0.0.6
+++++
* Minor fixes.

0.0.5
+++++
* minor fixes

0.0.4 (2017-09-22)
++++++++++++++++++
* minor fixes

0.0.3 (2017-08-31)
++++++++++++++++++
* minor fixes

0.0.2 (2017-08-28)
++++++++++++++++++

* Preview release.
