.. _index:

django-smart-selects documentation
==================================

Contents
--------

.. toctree::
   :maxdepth: 2
   :numbered: 1

   installation
   settings
   usage


Indices and tables
------------------

* :ref:`search`
