class KernelSpecManager:
    pass


class NoSuchKernel(Exception):
    pass
