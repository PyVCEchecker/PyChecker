# setup import hooks
import xonsh.imphooks

xonsh.imphooks.install_import_hooks()

del xonsh
