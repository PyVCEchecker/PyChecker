.. :changelog:

Release History
===============

0.2.2
+++++
* Minor fixes

0.2.1
+++++
* Minor fixes

0.2.0
+++++
* BREAKING CHANGE: 'show' commands log error message and fail with exit code of 3 upon a missing resource.

0.1.9
++++++
* Minor fixes.

0.1.8
++++++
* Add enrollment account commands
* `sdist` is now compatible with wheel 0.31.0

0.1.7
++++++
* Update for CLI core changes.

0.1.6
+++++
* minor fixes

0.1.5 (2017-09-22)
++++++++++++++++++
* minor fixes

0.1.4 (2017-08-28)
++++++++++++++++++
* minor fixes

0.1.3 (2017-07-07)
++++++++++++++++++
* minor fixes

0.1.2 (2017-06-21)
++++++++++++++++++
* No changes.

0.1.1 (2017-06-13)
++++++++++++++++++
* Minor fixes.

0.1.0 (2017-05-30)
++++++++++++++++++

* Initial release
