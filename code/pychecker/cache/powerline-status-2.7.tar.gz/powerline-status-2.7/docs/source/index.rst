*********
Powerline
*********

.. toctree::
   :maxdepth: 3
   :glob:

   overview
   installation
   usage
   configuration
   develop
   troubleshooting
   tips-and-tricks
   license-and-credits

.. toctree::
   :maxdepth: 2

   commands

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
