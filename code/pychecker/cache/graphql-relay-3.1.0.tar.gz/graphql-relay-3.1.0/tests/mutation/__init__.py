"""Tests for graphql_relay.mutation"""
