"""Tests for graphql_relay"""
