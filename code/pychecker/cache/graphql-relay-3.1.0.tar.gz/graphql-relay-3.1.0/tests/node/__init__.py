"""Tests for graphql_relay.node"""
