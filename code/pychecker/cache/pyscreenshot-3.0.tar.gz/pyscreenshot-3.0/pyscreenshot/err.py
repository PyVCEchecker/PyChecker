class FailedBackendError(Exception):
    pass
