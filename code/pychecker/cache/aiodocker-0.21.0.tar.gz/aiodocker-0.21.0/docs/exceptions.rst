===========
Exceptions
===========

----------
Reference
----------

DockerError
============

.. autoclass:: aiodocker.exceptions.DockerError
        :members:
        :undoc-members:
