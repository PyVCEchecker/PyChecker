import pytest

pytest.register_assert_rewrite("webargs.testing")
