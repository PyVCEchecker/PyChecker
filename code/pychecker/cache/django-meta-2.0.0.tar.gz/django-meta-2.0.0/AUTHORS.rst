=======
Credits
=======

Development Lead
----------------

* Iacopo Spalletti <i.spalletti@nephila.it>

Past core developers
--------------------

* Branko Vukelic


Contributors
------------

* Adam Chainz
* Basil Shubin
* Branko Vukelic
* Cansin Yildiz
* Dmitry Fillo
* ellmetha
* EmiM
* John Carter
* Ken Cochrane
* Leif Denby
* Leonardo Cavallucci
* m-vdb
* Marco Federighi
* Mirat Can Bayrak
* Miroslav Bendík
* Murat Aydos
* mvergerdelbove
* Sergei Maertens
* Zan Anderle
