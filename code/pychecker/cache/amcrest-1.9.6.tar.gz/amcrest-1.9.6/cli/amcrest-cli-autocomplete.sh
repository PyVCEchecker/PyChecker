eval "$(register-python-argcomplete amcrest-cli)"
