class SomeClass(object):
    def somewhat_fun_method(self):
        """LULZ"""
        return "LOL"
