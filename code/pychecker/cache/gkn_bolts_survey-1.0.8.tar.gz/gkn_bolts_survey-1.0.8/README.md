# GKN bolts survey

This scrips post process tightening measures of torque and angles on bolts producing graphs who identifies the yield point.
Additional information on the tighteing procedure can be visualized.