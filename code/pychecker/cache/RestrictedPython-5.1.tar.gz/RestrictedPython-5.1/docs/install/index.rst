Install / Depend on RestrictedPython
====================================

RestrictedPython is usually not used stand alone, if you use it in context of your package add it to ``install_requires`` in your ``setup.py`` or a ``requirement.txt`` used by ``pip``.

For a standalone usage:

.. code-block:: console

    $ pip install RestrictedPython
