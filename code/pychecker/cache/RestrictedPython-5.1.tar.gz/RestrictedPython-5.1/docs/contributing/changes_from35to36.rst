Changes from Python 3.5 to Python 3.6
-------------------------------------

.. literalinclude:: ast/python3_6.ast
   :diff: ast/python3_5.ast
