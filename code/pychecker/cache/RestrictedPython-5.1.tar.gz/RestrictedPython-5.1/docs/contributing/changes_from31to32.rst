Changes from Python 3.1 to Python 3.2
-------------------------------------

.. literalinclude:: ast/python3_2.ast
   :diff: ast/python3_1.ast
