Changes from Python 3.3 to Python 3.4
-------------------------------------

.. literalinclude:: ast/python3_4.ast
   :diff: ast/python3_3.ast
