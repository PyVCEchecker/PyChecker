Changes from Python 3.0 to Python 3.1
-------------------------------------

.. literalinclude:: ast/python3_1.ast
   :diff: ast/python3_0.ast
