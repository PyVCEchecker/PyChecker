Changes from Python 2.6 to Python 2.7
-------------------------------------

.. literalinclude:: ast/python2_7.ast
   :diff: ast/python2_6.ast
