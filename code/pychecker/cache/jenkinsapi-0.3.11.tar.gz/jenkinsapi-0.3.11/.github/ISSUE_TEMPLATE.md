##### ISSUE TYPE
<!--- Pick one below and delete the rest: -->
 - Bug Report
 - Feature Idea
 - How to...

##### Jenkinsapi VERSION

##### Jenkins VERSION

##### SUMMARY
<!--- Explain the problem briefly -->

##### EXPECTED RESULTS
<!--- What did you expect to happen when running the steps above? -->

##### ACTUAL RESULTS
<!--- What actually happened? If possible run with extra verbosity (-vvvv) -->

##### USEFUL INFORMATION
<!---
For bugs, show exactly how to reproduce the problem.
For new features, show how the feature would be used.
-->

<!--- Paste example code and full stacktrace below -->
```

```
