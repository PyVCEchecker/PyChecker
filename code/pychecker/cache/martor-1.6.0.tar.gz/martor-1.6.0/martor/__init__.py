# -*- coding: utf-8 -*-

__VERSION__ = '1.6.0'
__AUTHOR__ = 'Agus Makmun (Summon Agus)'
__AUTHOR_EMAIL__ = 'summon.agus@gmail.com'
