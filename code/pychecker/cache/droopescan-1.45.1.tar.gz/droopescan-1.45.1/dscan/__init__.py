import os
PWD = os.path.dirname(__file__) + "/"
