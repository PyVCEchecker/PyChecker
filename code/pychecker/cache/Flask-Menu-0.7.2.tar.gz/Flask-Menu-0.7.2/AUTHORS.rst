Authors
=======

Flask-Menu is developed for use in `Invenio <http://inveniosoftware.org>`_
digital library software.

Contact us at `info@inveniosoftware.org <mailto:info@inveniosoftware.org>`_

* Krzysztof Lis <krzysztof.lis@cern.ch>
* Jiri Kuncar <jiri.kuncar@cern.ch>
* Tibor Simko <tibor.simko@cern.ch>
* Matthew Dillon <mrdillon@alaska.edu>
* Eirini Psallida <eirini.psallida@cern.ch>
* Florian Merges <fmerges@fstarter.org>
* Marco Neumann <marco@crepererum.net>
* Nick Whyte <nick@nickwhyte.com>
* Sami Hiltunen <sami.mikael.hiltunen@cern.ch>
* Sylvain Boily <sboily@proformatique.com>
* Marlin Forbes <marlinf@datashaman.com>
