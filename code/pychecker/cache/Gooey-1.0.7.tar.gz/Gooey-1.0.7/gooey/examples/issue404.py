from gooey import Gooey, GooeyParser


@Gooey
def main():
    parser = GooeyParser()
    args = parser.parse_args()
    print('''
Who said that? SURE you can die! You want to die?! Enough about your 
promiscuous mother, Hermes! We have bigger problems. Does anybody else feel 
jealous and aroused and worried? There, now he's trapped in a book I 
wrote: a crummy world of plot holes and spelling errors!

http://fillerama.io/
    ''')


if __name__ == '__main__':
    main()