import subprocess


subprocess.call('python ./a.py')
subprocess.call('python ./b.py')

print(a)
print(b)