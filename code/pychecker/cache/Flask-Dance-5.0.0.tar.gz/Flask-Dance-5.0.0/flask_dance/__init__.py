from .consumer import OAuth1ConsumerBlueprint, OAuth2ConsumerBlueprint

__version__ = "5.0.0"
