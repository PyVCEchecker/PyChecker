"""Test prawcore."""
import time

time.sleep = lambda x: None
