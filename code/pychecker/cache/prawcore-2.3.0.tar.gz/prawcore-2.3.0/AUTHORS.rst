prawcore is written and maintained by Bryce Boe and various contributors:

Maintainers
===========

- Bryce Boe <bbzbryce@gmail.com> `@bboe <https://github.com/bboe>`_

Contributors
============

- nmtake `@nmtake <https://github.com/nmtake>`_
- elnuno `@elnuno <https://github.com/elnuno>`_
- Zeerak Waseem <zeerak.w@gmail.com> `@ZeerakW <https://github.com/ZeerakW>`_
- jarhill0 `@jarhill0 <https://github.com/jarhill0>`_
- Watchful1 `@Watchful1 <https://github.com/Watchful1>`_
- PythonCoderAS `@PythonCoderAS <https://github.com/PythonCoderAS>`_
- LilSpazJoekp `@LilSpazJoekp <https://github.com/LilSpazJoekp>`_
- MaybeNetwork `@MaybeNetwork <https://github.com/MaybeNetwork>`_
- Add "Name <email (optional)> and github profile link" above this line.
