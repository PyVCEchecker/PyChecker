## AWS CodePipeline Actions API

This package is no longer used, and will be removed in a future version of the CDK.

