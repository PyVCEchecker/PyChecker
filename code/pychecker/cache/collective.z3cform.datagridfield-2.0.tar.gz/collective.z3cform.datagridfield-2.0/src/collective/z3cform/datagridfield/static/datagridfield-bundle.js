require(["pat-registry", "pat-datagridfield"], function (registry) {});
