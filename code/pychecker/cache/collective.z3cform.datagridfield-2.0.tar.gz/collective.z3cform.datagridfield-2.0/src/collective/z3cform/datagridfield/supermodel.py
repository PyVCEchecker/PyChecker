# -*- coding: utf-8 -*-
from collective.z3cform.datagridfield.row import DictRow
from plone.supermodel.exportimport import ObjectHandler


DictRowHandler = ObjectHandler(DictRow)
