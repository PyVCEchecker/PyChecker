Microsoft Azure CLI 'advisor' Command Module
============================================

This package is for the 'advisor' module.
i.e. 'az advisor'
