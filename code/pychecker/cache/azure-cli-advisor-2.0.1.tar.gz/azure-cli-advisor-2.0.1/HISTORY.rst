.. :changelog:

Release History
===============

2.0.1
++++++
* Minor fixes.

2.0.0
++++++
* GA release.

0.6.0
+++++
* BREAKING CHANGE: 'show' commands log error message and fail with exit code of 3 upon a missing resource.

0.5.2
++++++
* Minor fixes.

0.5.1
+++++
* `sdist` is now compatible with wheel 0.31.0

0.5.0
++++++
* BC: `advisor configuration get` has been renamed to `advisor configuration list`.
* BC: `advisor configuration set` has been renamed to `advisor configuration update`.
* BC: `advisor recommendation generate` has been removed.
* `advisor recommendation list` has a new --refresh parameter.
* `advisor recommendation show` has been added.
* Support Autorest 3.0 based SDKs

0.1.2
+++++
* Minor fixes.

0.1.1
++++++
* Update for CLI core changes.

0.1.0
+++++

* Initial release of module.
