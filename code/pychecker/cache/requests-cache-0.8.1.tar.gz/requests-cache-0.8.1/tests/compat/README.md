# Library compatibility tests
This folder contains tests for compatibility with other requests-based libraries, to at least ensure
that documented examples do not break.
