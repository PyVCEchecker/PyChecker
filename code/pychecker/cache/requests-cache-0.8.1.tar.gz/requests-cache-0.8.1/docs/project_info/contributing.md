(contributing)=
# {fa}`lightbulb` Contributing
```{include} ../../CONTRIBUTING.md
:start-line: 1
```

```{toctree}
:hidden:

codeshelter
```
