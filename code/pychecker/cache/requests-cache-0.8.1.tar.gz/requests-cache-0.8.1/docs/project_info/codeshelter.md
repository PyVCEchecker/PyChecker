﻿# Note to Code Shelter maintainers

I don't have as much time as I'd like to dedicate to this project these days,
but many people find it useful, and I'd appreciate some help with maintaining
it. I will generally be available to consult and maybe develop the occasional
feature or bugfix, but my availability is not reliable.

It would be great if you could help out with issue triage, fixing bugs and
occasionally developing new features that you think are necessary. The project
is mainly feature-complete, so I don't expect any major deviation and would
appreciate being consulted before making any drastic changes, but other than
that, you have free reign.

I have already added Code Shelter to the project's PyPI page, so feel free to
make any releases necessary.

Thank you!

– Roman Haritonov
