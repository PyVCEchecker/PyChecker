# {fa}`info-circle` Project Info

```{toctree}
:maxdepth: 2

project_info/contributing
project_info/contributors
project_info/code_of_conduct
project_info/related_projects
project_info/history
````
