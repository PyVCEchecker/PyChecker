Session
=======
.. automodule:: requests_cache.session
