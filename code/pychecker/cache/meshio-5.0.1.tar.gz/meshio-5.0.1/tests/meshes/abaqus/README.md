* `UUea.inp`: From http://www-h.eng.cam.ac.uk/help/programs/fe/abaqus/faq68/txt/UUea.inp.txt
* `nle1xf3c.inp`: From http://dsk.ippt.pan.pl/docs/abaqus/v6.13/books/eif/nle1xf3c.inp
