# Elpy Tombstone

This is an empty package. See discussion at
https://github.com/jorgenschaefer/elpy/issues/1583
