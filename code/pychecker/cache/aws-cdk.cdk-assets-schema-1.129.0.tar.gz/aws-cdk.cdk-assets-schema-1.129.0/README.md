aws-cdk.cdk-assets-schema
=========================
