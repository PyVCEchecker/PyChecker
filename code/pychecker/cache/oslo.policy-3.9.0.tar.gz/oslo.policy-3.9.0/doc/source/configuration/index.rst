=======================
 Configuration Options
=======================

oslo.policy uses oslo.config to define and manage configuration options
that allow the deployer to control where the policy files are located,
the default rule to apply, etc.

.. show-options:: oslo.policy
