.. option:: --namespace NAMESPACE

    Option namespace(s) under "oslo.policy.policies" in which to query for
    options.

.. option:: --policy-file POLICY_FILE

    Path to the policy file which need to be converted to ``yaml`` format.
