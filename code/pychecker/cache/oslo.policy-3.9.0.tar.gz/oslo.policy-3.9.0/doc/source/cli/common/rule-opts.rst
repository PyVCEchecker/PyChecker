.. option:: --format FORMAT

    Desired format for the output. Allowed values: ``json``, ``yaml``

.. option:: --namespace NAMESPACE

    Option namespace(s) under "oslo.policy.policies" in which to query for
    options.
