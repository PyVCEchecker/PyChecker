.. option:: --namespace NAMESPACE

    Option namespace under "oslo.policy.enforcer" in which to look for a
    ``policy.Enforcer``.
