.. option:: --output-file OUTPUT_FILE

    Path of the file to write to. Defaults to stdout.
