==============
 Installation
==============

At the command line::

    $ pip install oslo.policy

Or, if you want to use it in a virtualenvwrapper::

    $ mkvirtualenv oslo.policy
    $ pip install oslo.policy
