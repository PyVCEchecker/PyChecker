:py:mod:`~adafruit_ble.attributes`
====================================================

.. automodule:: adafruit_ble.attributes
   :members:
