:py:mod:`~adafruit_ble.services.standard`
=======================================================

.. automodule:: adafruit_ble.services.standard
  :members:

.. automodule:: adafruit_ble.services.standard.device_info
  :members:

.. automodule:: adafruit_ble.services.standard.hid
  :members:
