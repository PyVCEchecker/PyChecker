Scan everything
----------------

Ensure your device works with this simple test. When working, will print out advertising data of
nearby BLE devices.

.. literalinclude:: ../examples/ble_simpletest.py
    :caption: examples/ble_simpletest.py
    :linenos:

Detailed scan
----------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ble_detailed_scan.py
    :caption: examples/ble_detailed_scan.py
    :linenos:
