:py:mod:`~adafruit_ble`
=======================

.. automodule:: adafruit_ble
   :members:

.. toctree::
   :hidden:

   advertising
   attributes
   characteristics
   services
   uuid
