:py:mod:`~adafruit_ble.characteristics`
=======================================

.. automodule:: adafruit_ble.characteristics
   :members:

.. automodule:: adafruit_ble.characteristics.int
   :members:

.. automodule:: adafruit_ble.characteristics.stream
   :members:

.. automodule:: adafruit_ble.characteristics.string
   :members:
