:py:mod:`~adafruit_ble.advertising`
====================================================

.. automodule:: adafruit_ble.advertising
   :members:

.. automodule:: adafruit_ble.advertising.standard
   :members:

.. automodule:: adafruit_ble.advertising.adafruit
   :members:
