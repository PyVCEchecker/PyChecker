:py:mod:`~adafruit_ble.services`
=================================

.. automodule:: adafruit_ble.services
  :members:

.. toctree::
  :hidden:

  standard_services

.. automodule:: adafruit_ble.services.circuitpython
  :members:

.. automodule:: adafruit_ble.services.microbit
  :members:

.. automodule:: adafruit_ble.services.midi
  :members:
