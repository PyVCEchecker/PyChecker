:py:mod:`~adafruit_ble.uuid`
====================================================

.. automodule:: adafruit_ble.uuid
   :members:
