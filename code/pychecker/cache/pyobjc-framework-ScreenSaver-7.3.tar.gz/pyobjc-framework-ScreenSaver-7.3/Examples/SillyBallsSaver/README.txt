SillyBallsSaver

Example showing screen saver in Python

Based on "Silly Balls.saver" by Eric Peyton <epeyton@epicware.com>


See:    ```http://www.epicware.com/macosxsavers.html``` (dead link)
        https://developer.apple.com/documentation/screensaver/screensaverview?language=objc

The source of this application demonstrates
- Writing a ScreenSaver in PyObjC
- Building plug-in bundles in PyObjC

Jason Toffaletti <catalyst@mac.com>
