**************
Planar Drawing
**************

.. automodule:: networkx.algorithms.planar_drawing
.. autosummary::
   :toctree: generated/

   combinatorial_embedding_to_pos
