:mod:`b2sdk.sync.path`
==============================

.. automodule:: b2sdk.sync.path
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
