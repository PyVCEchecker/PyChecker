:mod:`b2sdk.stream.wrapper` StreamWrapper
=========================================

.. automodule:: b2sdk.stream.wrapper
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
