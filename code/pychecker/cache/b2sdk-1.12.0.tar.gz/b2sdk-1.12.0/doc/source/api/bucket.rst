B2 Bucket
===============================================

.. autoclass:: b2sdk.v2.Bucket()
    :inherited-members:
    :special-members: __init__
