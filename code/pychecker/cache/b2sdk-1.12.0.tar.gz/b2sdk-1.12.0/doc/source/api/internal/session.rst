:mod:`b2sdk.session` -- B2 Session
=============================================

.. automodule:: b2sdk.session
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
