:mod:`b2sdk.transfer.outbound.upload_source`
============================================

.. automodule:: b2sdk.transfer.outbound.upload_source
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
