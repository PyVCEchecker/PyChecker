:mod:`b2sdk.sync.folder`
==================================

.. automodule:: b2sdk.sync.folder
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
