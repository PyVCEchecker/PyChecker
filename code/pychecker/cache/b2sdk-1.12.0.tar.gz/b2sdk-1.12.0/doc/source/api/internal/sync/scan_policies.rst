:mod:`b2sdk.sync.scan_policies`
================================================

.. automodule:: b2sdk.sync.scan_policies
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
