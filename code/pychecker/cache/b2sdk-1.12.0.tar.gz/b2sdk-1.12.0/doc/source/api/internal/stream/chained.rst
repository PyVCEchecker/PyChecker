:mod:`b2sdk.stream.chained` ChainedStream
============================================

.. automodule:: b2sdk.stream.chained
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
