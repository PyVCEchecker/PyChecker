:mod:`b2sdk.transfer.inbound.downloader.simple` -- SimpleDownloader
===================================================================

.. automodule:: b2sdk.transfer.inbound.downloader.simple
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
