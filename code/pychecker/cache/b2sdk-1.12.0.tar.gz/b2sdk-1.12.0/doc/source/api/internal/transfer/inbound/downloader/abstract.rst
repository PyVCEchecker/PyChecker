:mod:`b2sdk.transfer.inbound.downloader.abstract` -- Downloader base class
==========================================================================

.. automodule:: b2sdk.transfer.inbound.downloader.abstract
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
