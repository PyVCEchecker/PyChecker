:mod:`b2sdk.sync.folder_parser`
================================================

.. automodule:: b2sdk.sync.folder_parser
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
