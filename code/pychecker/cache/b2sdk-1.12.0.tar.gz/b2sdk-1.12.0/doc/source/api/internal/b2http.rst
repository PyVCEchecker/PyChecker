:mod:`b2sdk.b2http` -- thin http client wrapper
===============================================

.. automodule:: b2sdk.b2http
