:mod:`b2sdk.sync.exception`
==============================================

.. automodule:: b2sdk.sync.exception
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
