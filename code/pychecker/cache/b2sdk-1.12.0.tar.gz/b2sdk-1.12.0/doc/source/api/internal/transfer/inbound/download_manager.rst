:mod:`b2sdk.transfer.inbound.download_manager` -- Manager of downloaders
========================================================================

.. automodule:: b2sdk.transfer.inbound.download_manager
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
