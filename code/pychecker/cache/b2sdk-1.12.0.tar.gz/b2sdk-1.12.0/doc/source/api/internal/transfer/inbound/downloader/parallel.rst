:mod:`b2sdk.transfer.inbound.downloader.parallel` -- ParallelTransferer
=======================================================================

.. automodule:: b2sdk.transfer.inbound.downloader.parallel
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
