B2 Api client
===============================================

.. autoclass:: b2sdk.v2.B2Api()
    :inherited-members:
    :special-members: __init__


.. autoclass:: b2sdk.v2.B2HttpApiConfig()
    :inherited-members:
    :special-members: __init__
