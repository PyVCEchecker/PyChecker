Downloaded File
===============

.. autoclass:: b2sdk.v2.DownloadedFile

.. autoclass:: b2sdk.v2.MtimeUpdatedFile

