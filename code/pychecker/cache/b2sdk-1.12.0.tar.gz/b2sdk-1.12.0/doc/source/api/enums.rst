Enums
===============================================

.. autoclass:: b2sdk.v2.MetadataDirectiveMode
   :inherited-members:

.. autoclass:: b2sdk.v2.NewerFileSyncMode
   :inherited-members:

.. autoclass:: b2sdk.v2.CompareVersionMode
   :inherited-members:

.. autoclass:: b2sdk.v2.KeepOrDeleteMode
   :inherited-members:

