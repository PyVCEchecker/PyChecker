Exceptions
====================================

.. todo::
   improve documentation of exceptions, automodule -> autoclass?

.. automodule:: b2sdk.v2.exception
    :members:
    :undoc-members:
