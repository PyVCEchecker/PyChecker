:mod:`b2sdk.sync.action`
=======================================

.. automodule:: b2sdk.sync.action
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
