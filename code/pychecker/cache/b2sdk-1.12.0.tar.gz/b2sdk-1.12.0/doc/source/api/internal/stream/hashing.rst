:mod:`b2sdk.stream.hashing` StreamWithHash
============================================

.. automodule:: b2sdk.stream.hashing
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
