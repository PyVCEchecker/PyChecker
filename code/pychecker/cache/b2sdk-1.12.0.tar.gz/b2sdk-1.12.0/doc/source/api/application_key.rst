B2 Application key
==================

.. autoclass:: b2sdk.v2.ApplicationKey()
    :inherited-members:
    :special-members: __init__


.. autoclass:: b2sdk.v2.FullApplicationKey()
    :inherited-members:
    :special-members: __init__
