Write intent
===============================================

.. autoclass:: b2sdk.v2.WriteIntent()
    :inherited-members:
    :special-members: __init__
