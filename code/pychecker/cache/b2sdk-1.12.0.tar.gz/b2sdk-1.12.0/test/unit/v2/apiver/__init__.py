######################################################################
#
# File: test/unit/v2/apiver/__init__.py
#
# Copyright 2021 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################

# configured by pytest using `--api` option
# check test/unit/conftest.py:pytest_configure for details
