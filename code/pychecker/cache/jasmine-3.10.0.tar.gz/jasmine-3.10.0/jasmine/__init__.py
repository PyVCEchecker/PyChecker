# Import core to trigger a deprecation warning
import jasmine_core
