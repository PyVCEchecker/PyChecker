.. :changelog:

Release History
===============

2.0.8
+++++
* minor fixes

2.0.7 (2017-08-11)
++++++++++++++++++

* Add deprecation warning to 'az component' commands.

2.0.6 (2017-06-21)
++++++++++++++++++

* Minor fixes.

2.0.5 (2017-05-30)
++++++++++++++++++

* Minor fixes.

2.0.4 (2017-05-09)
++++++++++++++++++

* Remove references to CLI being in preview (#3273)

2.0.3 (2017-05-02)
++++++++++++++++++

* Reinstall azure-nspkg and azure-mgmt-nspkg.

2.0.2 (2017-04-28)
++++++++++++++++++

* New packaging system

2.0.1 (2017-04-17)
++++++++++++++++++

* Apply core changes required for JSON string parsing from shell (#2705)

2.0.0 (2017-02-27)
++++++++++++++++++

* GA release


0.1.1rc2 (2017-02-22)
+++++++++++++++++++++

* Documentation updates.


0.1.1rc1 (2017-02-17)
+++++++++++++++++++++

* 'component update' now checks additional component author on PyPI


0.1.0rc2 (2017-01-30)
+++++++++++++++++++++

* Support Python 3.6.

0.1.0rc1 (2017-01-13)
+++++++++++++++++++++

* Release candidate. No code changes from 0.1.0b12.

0.1.0b12 (2017-01-07)
+++++++++++++++++++++

* Fix pip seg fault on 'az component update'

0.1.0b11 (2016-12-12)
+++++++++++++++++++++

* Preview release.
