# Copyright 2011 OpenStack Foundation.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import abc


class HealthcheckResult(object):
    """Result of a ``healthcheck`` method call should be this object."""

    def __init__(self, available, reason, details=None):
        self.available = available
        self.reason = reason
        self.details = details


class HealthcheckBaseExtension(metaclass=abc.ABCMeta):

    def __init__(self, oslo_conf, conf):
        self.oslo_conf = oslo_conf
        self.conf = conf

    @abc.abstractmethod
    def healthcheck(self, server_port):
        """method called by the healthcheck middleware

        return: HealthcheckResult object
        """

    def _conf_get(self, key, group='healthcheck'):
        if key in self.conf:
            # Validate value type
            self.oslo_conf.set_override(key, self.conf[key], group=group)
        return getattr(getattr(self.oslo_conf, group), key)
