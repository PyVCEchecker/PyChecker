.. include:: ../../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   configuration/index
   admin/index
   reference/index
   glossary

Release Notes
=============

Read also the `oslo.middleware Release Notes
<https://docs.openstack.org/releasenotes/oslo.middleware/>`_.
