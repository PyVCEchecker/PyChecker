===========
VPN Service
===========

The **VPN Service** is associated with a router. After you
create the service, it can contain multiple VPN connections.

Network v2

.. autoprogram-cliff:: openstack.neutronclient.v2
   :command: vpn service *
