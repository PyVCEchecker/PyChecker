==============
VPN IKE Policy
==============

The **IKE Policy** is used for phases one and two negotiation of the
VPN connection. You can specify both the authentication and encryption
algorithms for connections.

Network v2

.. autoprogram-cliff:: openstack.neutronclient.v2
   :command: vpn ike policy *
