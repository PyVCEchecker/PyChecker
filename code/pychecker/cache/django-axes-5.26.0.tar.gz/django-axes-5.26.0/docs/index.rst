.. _index:

django-axes documentation
=========================

Contents
--------

.. toctree::
   :maxdepth: 2
   :numbered: 1

   1_requirements
   2_installation
   3_usage
   4_configuration
   5_customization
   6_integration
   7_architecture
   8_reference
   9_development
   10_changelog


Indices and tables
------------------

* :ref:`search`
