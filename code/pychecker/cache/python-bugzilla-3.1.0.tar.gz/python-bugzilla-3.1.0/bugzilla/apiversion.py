#
# Copyright (C) 2014 Red Hat Inc.
#
# This work is licensed under the GNU GPLv2 or later.
# See the COPYING file in the top-level directory.

version = "3.1.0"
__version__ = version
