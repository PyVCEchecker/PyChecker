..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Dinos Kousidis
- Esteban J. G. Gabancho
- Jacopo Notarstefano
- Jiri Kuncar
- Jose Benito Gonzalez Lopez
- Lars Holm Nielsen
- Leonardo Rossi
- Nicolas Harraudeau
- Paulina Lach
- Sami Hiltunen
- Tibor Simko
