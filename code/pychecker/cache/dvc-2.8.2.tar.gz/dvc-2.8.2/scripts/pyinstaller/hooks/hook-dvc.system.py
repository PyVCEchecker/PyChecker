import os

if os.name == "nt":
    hiddenimports = ["win32file"]
