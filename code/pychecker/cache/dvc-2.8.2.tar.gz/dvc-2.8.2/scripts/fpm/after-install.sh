#!/bin/sh
ln -sf /usr/local/lib/dvc/dvc /usr/local/bin/dvc
