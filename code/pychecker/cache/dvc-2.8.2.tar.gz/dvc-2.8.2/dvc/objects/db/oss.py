from .base import ObjectDB


class OSSObjectDB(ObjectDB):
    """
    Temporary extra verification
    """

    DEFAULT_VERIFY = True
