from .base import ObjectDB


class GDriveObjectDB(ObjectDB):
    DEFAULT_VERIFY = True
