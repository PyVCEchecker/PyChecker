def install(self, use_pre_commit_tool):
    self.scm.install(use_pre_commit_tool)
