=====================================================
 ``amqp.connection``
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.connection

.. automodule:: amqp.connection
    :members:
    :undoc-members:
