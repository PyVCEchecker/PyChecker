=====================================================
 amqp.spec
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.sasl

.. automodule:: amqp.sasl
    :members:
    :undoc-members:
