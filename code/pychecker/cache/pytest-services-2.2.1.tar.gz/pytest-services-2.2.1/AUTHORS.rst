Authors
=======

`Anatoly Bubenkov <bubenkoff@gmail.com>`_
    idea and implementation

These people have contributed to `pytest-services`, in alphabetical order:

* `Alessio Bogon <youtux@github.com>`_
* `Dmitrijs Milajevs <dimazest@gmail.com>`_
* `Jason R. Coombs <jaraco@jaraco.com>`_
* `Joep van Dijken <joepvandijken@github.com>`_
* `Magnus Staberg <magnus@staberg.io>`_
* `Michael Shriver <mshriver@redhat.com>`_
* `Oleg Pidsadnyi <oleg.pidsadnyi@gmail.com>`_
* `Zac Hatfield-Dodds <zac@zhd.dev>`_
