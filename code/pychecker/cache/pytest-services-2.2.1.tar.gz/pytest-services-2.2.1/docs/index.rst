Welcome to pytest-services's documentation!
===========================================

.. contents::

.. include:: ../README.rst

.. include:: api/index.rst

.. include:: ../AUTHORS.rst

.. include:: ../CHANGES.rst
