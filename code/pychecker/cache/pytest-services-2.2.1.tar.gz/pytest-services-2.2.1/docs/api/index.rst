Internal API
============

.. automodule:: pytest_services.plugin
   :members:

.. automodule:: pytest_services.memcached
   :members:

.. automodule:: pytest_services.mysql
   :members:

.. automodule:: pytest_services.xvfb
   :members:

.. automodule:: pytest_services.service
   :members:

.. automodule:: pytest_services.cleanup
   :members:

.. automodule:: pytest_services.folders
   :members:

.. automodule:: pytest_services.locks
   :members:

.. automodule:: pytest_services.log
   :members:

.. automodule:: pytest_services.django_settings
   :members:
