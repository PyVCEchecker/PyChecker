__author__ = "Vitaly Babiy"
__email__ = "vbabiy86@gmail.com"
__version__ = "1.2.0"
