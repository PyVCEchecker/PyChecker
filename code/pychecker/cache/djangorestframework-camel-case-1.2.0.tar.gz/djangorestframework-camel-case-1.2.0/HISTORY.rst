.. :changelog:

History
=======

1.2.0 (2020-06-16)
------------------

- added ignore_fields
- Merge pull request #88
- Merge pull request #84
- Merge pull request #77
- Merge pull request #73

1.1.2 (2019-10-22)
------------------

- Merge pull request #63
- Merge pull request #70
- Merge pull request #71

1.1.1 (2019-09-09)
------------------

- Add json_underscoreize as CamelCaseJSONParser class attribute #44

1.1.0 (2019-09-09)
------------------

Long awaited stable release:

Changes can be viewed:
https://github.com/vbabiy/djangorestframework-camel-case/compare/e6db468...39ae6bb

0.1.0 (2013-12-20)
------------------

* First release on PyPI.
