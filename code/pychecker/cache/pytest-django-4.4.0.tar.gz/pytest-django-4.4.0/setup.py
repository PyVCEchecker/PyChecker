from setuptools import setup

setup(
    use_scm_version={
        'write_to': 'pytest_django/_version.py',
    },
)
