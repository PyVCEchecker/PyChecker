from .ip import get_client_ip  # noqa

default_app_config = 'ipware.apps.IPwareConfig'
