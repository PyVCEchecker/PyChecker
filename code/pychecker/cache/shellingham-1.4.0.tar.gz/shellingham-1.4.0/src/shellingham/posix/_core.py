import collections

Process = collections.namedtuple("Process", "args pid ppid")
