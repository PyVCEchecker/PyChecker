.. _apiref:

===============
 API Reference
===============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 1

    django-celery-beat
    django-celery-beat.models
    django-celery-beat.tzcrontab
    django-celery-beat.managers
    django-celery-beat.schedulers
    django-celery-beat.admin
    django-celery-beat.utils
    django-celery-beat.validators
