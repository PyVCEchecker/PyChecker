.. _glossary:

Glossary
========

.. glossary::
    :sorted:

    term
        Description of term
