An advanced, but easy to use foursquare API client that handles OAuth, automatic retries, and other niceties.

For usage, see: http://github.com/mLewisLogic/foursquare
