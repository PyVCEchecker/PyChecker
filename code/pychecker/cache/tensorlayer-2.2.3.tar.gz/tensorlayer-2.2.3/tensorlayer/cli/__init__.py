#! /usr/bin/python
# -*- coding: utf-8 -*-
"""The tensorlayer.cli module provides a command-line tool for some common tasks."""
