#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tests.utils.custom_networks.inceptionv4 import *
