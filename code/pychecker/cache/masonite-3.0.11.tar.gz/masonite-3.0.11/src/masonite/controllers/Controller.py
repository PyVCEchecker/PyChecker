"""Masonite Controller Base Class."""


class Controller:
    pass
