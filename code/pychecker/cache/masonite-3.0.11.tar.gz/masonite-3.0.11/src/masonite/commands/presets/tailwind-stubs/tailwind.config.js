module.exports = {
  purge: [],
  darkMode: false, // or 'media' or 'class'
  theme: {
    fontFamily: {
      "sans": "Raleway, sans-serif",  // set as sans-serif font
    },
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
