from abc import ABC


class CacheManagerContract(ABC):
    pass
