from abc import ABC


class SessionManagerContract(ABC):
    pass
