from abc import ABC


class BroadcastManagerContract(ABC):
    pass
