from abc import ABC


class UploadManagerContract(ABC):
    pass
