from abc import ABC


class StorageManagerContract(ABC):
    pass
