from abc import ABC


class MailManagerContract(ABC):
    pass
