from abc import ABC


class QueueManagerContract(ABC):
    pass
