class BaseExceptionListener:
    pass
