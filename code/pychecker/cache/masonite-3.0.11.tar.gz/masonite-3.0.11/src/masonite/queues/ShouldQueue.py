class ShouldQueue:
    pass
