api_key = None


def configure(key=None):
    global api_key
    api_key = key
