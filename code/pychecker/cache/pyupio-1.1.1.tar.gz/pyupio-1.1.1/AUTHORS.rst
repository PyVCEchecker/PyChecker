Credits
=======

Development Leads
-----------------

* Justin Womersley <justinwomersley@gmail.com>
* Rafael Pivato <rpivato@gmail.com>

Original Author
---------------

* Jannis Gebauer <ja.geb@me.com>

Contributors
------------

* Christophe Lecointe