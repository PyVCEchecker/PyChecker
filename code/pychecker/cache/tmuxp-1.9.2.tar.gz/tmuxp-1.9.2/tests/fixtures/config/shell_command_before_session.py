from .._util import loadfixture

before = loadfixture("config/shell_command_before_session.yaml")
expected = loadfixture("config/shell_command_before_session-expected.yaml")
