(index)=

# tmuxp

## tmux session manager

```{include} ../README.md

```

```{image} _static/tmuxp-demo.gif
:width: 100%

```

### Table of Contents

```{toctree}
:maxdepth: 2

about
quickstart
examples
cli
plugin_system
developing
api
history
about_tmux
glossary

```
