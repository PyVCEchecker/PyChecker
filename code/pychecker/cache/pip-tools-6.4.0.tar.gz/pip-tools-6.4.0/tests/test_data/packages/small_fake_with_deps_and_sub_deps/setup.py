from setuptools import setup

setup(
    name="small_fake_with_deps_and_sub_deps",
    version=0.1,
    install_requires=["small-fake-with-unpinned-deps"],
)
