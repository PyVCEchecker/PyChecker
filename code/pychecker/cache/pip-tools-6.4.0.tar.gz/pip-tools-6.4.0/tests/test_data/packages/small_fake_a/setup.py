from setuptools import setup

setup(name="small_fake_a", version=0.1)
