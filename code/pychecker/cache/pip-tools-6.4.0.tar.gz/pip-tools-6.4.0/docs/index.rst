.. pip-tools documentation master file, created by
   sphinx-quickstart on Tue Jun 22 00:43:50 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

====================================
Welcome to pip-tools' documentation!
====================================

.. include:: ../README.rst

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: Contents:

   contributing.md
   changelog.md


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
