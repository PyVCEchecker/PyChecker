# Is the build done yet??
Just a really simple script that changes the colour of Phillips Hue lights on the completion of a script/command

![Usage](https://storage.googleapis.com/is-the-build-done-yet/usage.png)

## Install

![Installation](https://storage.googleapis.com/is-the-build-done-yet/installation.png)

## Setup
![Setup](https://storage.googleapis.com/is-the-build-done-yet/setup.png)

## Author
Jos Craw <jos@joscraw.net>