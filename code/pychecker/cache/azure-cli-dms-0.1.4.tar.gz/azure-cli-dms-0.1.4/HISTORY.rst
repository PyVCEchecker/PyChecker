.. :changelog:

Release History
===============

0.1.4
+++++
* Minor fixes.

0.1.3
+++++
* Minor fixes.

0.1.2
+++++
* Minor fixes.

0.1.1
++++++
* Minor fixes.

0.1.0
++++++
* BREAKING CHANGE: 'show' commands log error message and fail with exit code of 3 upon a missing resource.

0.0.2
+++++
* Minor fixes.

0.0.1
+++++
* Initial release. Adds support for the SQL to Azure SQL migration scenario.
