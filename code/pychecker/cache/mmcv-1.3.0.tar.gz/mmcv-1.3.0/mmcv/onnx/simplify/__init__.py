from .core import simplify

__all__ = ['simplify']
