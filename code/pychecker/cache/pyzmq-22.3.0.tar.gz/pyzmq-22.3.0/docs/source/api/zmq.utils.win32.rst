utils.win32
===========


Module: :mod:`zmq.utils.win32`
------------------------------

.. automodule:: zmq.utils.win32

.. currentmodule:: zmq.utils.win32


:class:`allow_interrupt`
------------------------


.. autoclass:: allow_interrupt
