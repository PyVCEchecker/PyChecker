watchmedo shell-command -c 'pytest --cov --cov-report term-missing' -R -p "*.py" -W
