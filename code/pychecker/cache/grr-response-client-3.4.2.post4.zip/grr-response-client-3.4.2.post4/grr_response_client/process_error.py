#!/usr/bin/env python
# Lint as: python3
"""An exception class shared between the OSs."""


class ProcessError(Exception):
  pass
