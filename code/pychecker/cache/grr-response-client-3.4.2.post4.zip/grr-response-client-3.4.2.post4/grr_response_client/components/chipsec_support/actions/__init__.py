#!/usr/bin/env python
# Lint as: python3
"""Conditional import for Chipsec. Only Linux is supported at this stage."""
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
