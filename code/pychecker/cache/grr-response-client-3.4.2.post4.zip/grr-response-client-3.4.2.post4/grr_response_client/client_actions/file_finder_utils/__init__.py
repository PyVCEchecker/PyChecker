#!/usr/bin/env python
# Lint as: python3
"""Implementation of utilities used in the client-side file-finder."""
