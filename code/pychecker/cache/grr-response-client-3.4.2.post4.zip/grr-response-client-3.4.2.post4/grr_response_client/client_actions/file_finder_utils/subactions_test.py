#!/usr/bin/env python
# Lint as: python3
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from absl.testing import absltest

# TODO(hanuszczak): Implement basic unit tests for subactions.


class StatActionTest(absltest.TestCase):
  pass


class HashActionTest(absltest.TestCase):
  pass


class DownloadActionTest(absltest.TestCase):
  pass


if __name__ == "__main__":
  absltest.main()
