#!/usr/bin/env python
# Lint as: python3
# Copyright 2011 Google Inc. All Rights Reserved.
"""A module to load all windows client plugins."""
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
