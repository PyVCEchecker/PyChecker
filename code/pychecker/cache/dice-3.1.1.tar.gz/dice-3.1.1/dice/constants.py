# Python 2 doesn't nave enum, but this is close enough.
class DiceExtreme(object):
    EXTREME_MIN = "MIN"
    EXTREME_MAX = "MAX"


MAX_ROLL_DICE = 2 ** 20
MAX_EXPLOSIONS = 2 ** 8
VERBOSE_INDENT = 2
