from __future__ import absolute_import, print_function, unicode_literals

import sys
import dice.command

if __name__ == "__main__":
    dice.command.main(sys.argv[1:])
