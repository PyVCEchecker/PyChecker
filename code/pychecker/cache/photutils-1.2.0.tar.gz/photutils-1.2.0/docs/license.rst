.. _photutils_license:

License
=======

Photutils is licensed under a 3-clause BSD license:

.. include:: ../LICENSE.rst
