Geometry Functions (`photutils.geometry`)
=========================================

Introduction
------------

The `photutils.geometry` package contains low-level geometry functions
used mainly by `~photutils.aperture.aperture_photometry`.


Reference/API
-------------

.. automodapi:: photutils.geometry
    :no-heading:
