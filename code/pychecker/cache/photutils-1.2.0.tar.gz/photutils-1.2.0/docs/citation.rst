.. _photutils_citation:

.. include:: ../photutils/CITATION.rst
