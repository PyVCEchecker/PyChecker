Utility Functions (`photutils.utils`)
=====================================

Introduction
------------

The `photutils.utils` package contains general-purpose utility
functions.


Reference/API
-------------
.. automodapi:: photutils.utils
    :no-heading:
