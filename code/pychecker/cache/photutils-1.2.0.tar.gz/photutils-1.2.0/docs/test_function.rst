Photutils Test Function
=======================

.. autofunction:: photutils.test
