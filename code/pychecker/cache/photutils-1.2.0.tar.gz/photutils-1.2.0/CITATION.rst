See https://github.com/astropy/photutils/blob/main/photutils/CITATION.rst
