Photutils is an `Astropy <https://www.astropy.org/>`_  affiliated
package.  We follow the `Astropy Community Code of Conduct
<https://www.astropy.org/code_of_conduct.html>`_.
