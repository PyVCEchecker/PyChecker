This folder contains data files used for testing the
`photutils.isophote` subpackage.

These FITS tables contain the results of running the
stsdas$analysis/isophote task 'ellipse' on the corresponding images in
the photutils-datasets github repository:

https://github.com/astropy/photutils-datasets/isophote
