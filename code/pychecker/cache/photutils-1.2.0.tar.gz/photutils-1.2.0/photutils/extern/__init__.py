# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This subpackage contains tools that are bundled with the package but are
external to it.
"""
