# this file will automatically be changed,
# do not add anything but the version number here!
__version__ = "2.8.7"
