def test_foo():
    from time import sleep
    sleep(0.1)  # make sure we register in profiling
