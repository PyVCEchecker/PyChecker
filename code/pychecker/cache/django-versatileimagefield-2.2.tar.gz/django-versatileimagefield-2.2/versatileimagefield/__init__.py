default_app_config = 'versatileimagefield.apps.VersatileImageFieldConfig'
