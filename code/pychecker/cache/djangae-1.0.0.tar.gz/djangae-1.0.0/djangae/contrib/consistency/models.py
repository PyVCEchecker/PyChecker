# Import <anything> from consistency.py so that our signals get registered

from djangae.contrib.consistency.consistency import handle_post_save, handle_post_delete
