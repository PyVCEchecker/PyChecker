default_app_config = 'djangae.contrib.gauth_datastore.apps.GAuthDatastoreConfig'
