from django.contrib import admin


from .models import DatastoreLock


admin.site.register(DatastoreLock)
