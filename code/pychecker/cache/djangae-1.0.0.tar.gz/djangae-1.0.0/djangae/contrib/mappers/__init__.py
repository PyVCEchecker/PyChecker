
from .defer import defer_iteration
