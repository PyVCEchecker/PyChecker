import warnings

warnings.warn(
    "djangae.contrib.gauth.datastore is deprecated, please use djangae.contrib.gauth_datastore "
    "instead"
)

from djangae.contrib.gauth_datastore import *
