import warnings

warnings.warn(
    "djangae.contrib.gauth.sql is deprecated, please use djangae.contrib.gauth_sql instead"
)

from djangae.contrib.gauth_sql import *
