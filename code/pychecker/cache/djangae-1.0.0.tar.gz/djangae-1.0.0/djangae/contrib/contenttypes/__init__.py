default_app_config = 'djangae.contrib.contenttypes.apps.ContentTypesConfig'
