
default_app_config = 'djangae.contrib.processing.mapreduce.apps.MapreduceConfig'

from .helpers import *
