from djangae.contrib.gauth.backends import BaseAppEngineUserAPIBackend


class AppEngineUserAPIBackend(BaseAppEngineUserAPIBackend):
    pass
