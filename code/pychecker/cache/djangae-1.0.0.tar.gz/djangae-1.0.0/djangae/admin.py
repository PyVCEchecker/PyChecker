from django.contrib import admin

from djangae.models import DeferIterationMarker

admin.site.register(DeferIterationMarker)
