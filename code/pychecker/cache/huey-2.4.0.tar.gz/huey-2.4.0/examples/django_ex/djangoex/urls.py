from django.conf.urls import patterns

urlpatterns = patterns('',
)
