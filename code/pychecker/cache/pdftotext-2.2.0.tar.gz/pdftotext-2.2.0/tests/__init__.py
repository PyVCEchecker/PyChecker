"""Tests for the pdftotext module."""
