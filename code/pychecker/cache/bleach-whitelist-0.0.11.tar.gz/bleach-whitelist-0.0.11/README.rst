Project renamed
================

This project and package have been renamed.

Please see:

- https://github.com/yourcelf/bleach-allowlist
- https://pypi.org/project/bleach-allowlist/

The package named `bleach-whitelist` will not see further updates, please use
`bleach-allowlist` instead.
