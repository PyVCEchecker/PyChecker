"""
Gaussian processes examples.
"""
