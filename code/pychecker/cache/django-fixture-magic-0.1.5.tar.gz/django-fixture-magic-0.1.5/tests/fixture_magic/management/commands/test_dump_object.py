from __future__ import absolute_import

__author__ = 'davedash'


def test_import():
    """Just tests that the command can be imported.

    This can be removed entirely once we legitimately test this command.
    """
    # noinspection PyUnresolvedReferences
    from fixture_magic.management.commands import dump_object
