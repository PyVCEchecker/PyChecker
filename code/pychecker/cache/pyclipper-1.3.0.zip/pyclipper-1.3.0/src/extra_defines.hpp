#ifndef extra_defines_hpp
#define extra_defines_hpp

#include "clipper.hpp"

#ifdef use_xyz
#define _USE_XYZ 1
#else
#define _USE_XYZ 0
#endif

#endif