__version__ = "11.0.1"

if __name__ == "__main__":
    print(__version__)
