from django.apps import AppConfig


class BitFieldAppConfig(AppConfig):
    name = 'bitfield'
    verbose_name = "Bit Field"
