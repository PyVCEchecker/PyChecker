import { JupyterFrontEndPlugin } from '@jupyterlab/application';
import '../style/index.css';
/**
 * Initialization data for the jupyterlab-server-proxy extension.
 */
declare const extension: JupyterFrontEndPlugin<void>;
export default extension;
