# -*- coding: UTF-8 -*-

"""Unittests for emoji."""


from . import *
