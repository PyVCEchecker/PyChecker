"""Place of record for the package version"""

__version__ = "3.0.0"
