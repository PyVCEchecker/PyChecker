"""
Google Cloud Emulators
======================

Allows to spin up google cloud emulators, such as PubSub.
"""

from .pubsub import PubSubContainer  # noqa
