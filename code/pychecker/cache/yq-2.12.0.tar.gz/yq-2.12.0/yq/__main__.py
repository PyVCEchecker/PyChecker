from yq.__init__ import cli

if __name__ == "__main__":
    cli()
