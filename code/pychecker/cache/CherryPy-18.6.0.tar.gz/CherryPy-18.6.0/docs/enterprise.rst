.. todo: consider linking to the same text in README.rst.
.. https://github.com/cherrypy/cherrypy/pull/1813#discussion_r330805322

For Enterprise
==============

CherryPy is available as part of the Tidelift Subscription.

The CherryPy maintainers and the maintainers of thousands of other packages
are working with Tidelift to deliver one enterprise subscription that covers
all of the open source you use.

`Learn more <https://tidelift.com/subscription/pkg/pypi-cherrypy?utm_source=pypi-cherrypy&utm_medium=referral&utm_campaign=github>`_.
