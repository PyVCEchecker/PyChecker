Microsoft Azure CLI Service Fabric Module
=========================================

This package is for the `sf` module. It contains commands that can be used
to manage and administer Service Fabric clusters.

These commands are going to be deprecated in future releases. Instead, the new
Service Fabric CLI (sfctl) should be used.
