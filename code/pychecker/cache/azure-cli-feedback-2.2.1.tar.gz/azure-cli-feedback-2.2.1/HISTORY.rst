.. :changelog:

Release History
===============

2.2.1
+++++
* Minor fixes

2.2.0
+++++
* `az feedback` now shows metadata on recently run commands
* `az feedback` prompts user to assist in issue creation process. Opens browser to issue url and copies auto-generated issue
  text containing command and system related information to clipboard. Prints out issue body when run with '--verbose'

2.1.4
+++++
* Minor fixes

2.1.3
++++++
* Minor fixes

2.1.2
++++++
* Minor fixes

2.1.1
+++++
* `sdist` is now compatible with wheel 0.31.0

2.1.0
+++++
* Switch AI upstream feed
* Introduce extension management property to telemetry data.

2.0.8
+++++
* Minor fixes.

2.0.7
++++++
* Update for CLI core changes.

2.0.6
+++++
* minor fixes

2.0.5 (2017-06-21)
++++++++++++++++++
* No changes.

2.0.4 (2017-06-13)
++++++++++++++++++
* Minor fixes.

2.0.3 (2017-05-30)
++++++++++++++++++

* Minor fixes.

2.0.2 (2017-04-28)
++++++++++++++++++

* New packaging system.

2.0.1 (2017-04-17)
++++++++++++++++++

* Apply core changes required for JSON string parsing from shell (#2705)

2.0.0 (2017-02-27)
++++++++++++++++++

* GA release.

0.1.2rc1 (2017-02-17)
+++++++++++++++++++++

* Release candidate.

0.1.1b2 (2017-01-30)
+++++++++++++++++++++

* Support Python 3.6.

0.1.1b1 (2017-01-17)
+++++++++++++++++++++

* Preview release. (no code changes since previous version).


0.1.0b11 (2016-12-12)
+++++++++++++++++++++

* Preview release.
