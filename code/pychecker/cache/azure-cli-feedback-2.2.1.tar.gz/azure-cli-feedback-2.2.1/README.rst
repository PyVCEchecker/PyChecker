Microsoft Azure CLI 'feedback' Command Module
=============================================

This package is for the 'feedback' module.
i.e. 'az feedback'


