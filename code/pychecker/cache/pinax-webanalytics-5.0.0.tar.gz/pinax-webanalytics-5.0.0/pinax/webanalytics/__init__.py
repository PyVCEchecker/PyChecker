import pkg_resources

default_app_config = "pinax.webanalytics.apps.AppConfig"
__version__ = pkg_resources.get_distribution("pinax-webanalytics").version
