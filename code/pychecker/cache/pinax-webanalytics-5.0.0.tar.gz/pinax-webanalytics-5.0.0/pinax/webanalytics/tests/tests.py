from django.test import TestCase


class Tests(TestCase):

    def setUp(self):
        pass
