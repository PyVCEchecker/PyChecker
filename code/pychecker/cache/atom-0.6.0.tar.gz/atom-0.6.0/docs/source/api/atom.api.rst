atom.api module
===============

.. automodule:: atom.api
    :members:
    :undoc-members:
    :show-inheritance:
