atom.coerced module
===================

.. automodule:: atom.coerced
    :members:
    :undoc-members:
    :show-inheritance:
