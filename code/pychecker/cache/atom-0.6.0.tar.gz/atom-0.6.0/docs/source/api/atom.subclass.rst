atom.subclass module
====================

.. automodule:: atom.subclass
    :members:
    :undoc-members:
    :show-inheritance:
