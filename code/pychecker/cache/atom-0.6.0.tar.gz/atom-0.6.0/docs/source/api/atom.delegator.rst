atom.delegator module
=====================

.. automodule:: atom.delegator
    :members:
    :undoc-members:
    :show-inheritance:
