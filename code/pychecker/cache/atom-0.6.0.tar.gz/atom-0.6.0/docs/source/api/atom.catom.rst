atom.catom module
=================

.. automodule:: atom.catom
    :members:
    :undoc-members:
    :show-inheritance:
