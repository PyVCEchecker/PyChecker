atom.enum module
================

.. automodule:: atom.enum
    :members:
    :undoc-members:
    :show-inheritance:
