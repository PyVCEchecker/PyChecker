atom.dict module
================

.. automodule:: atom.dict
    :members:
    :undoc-members:
    :show-inheritance:
