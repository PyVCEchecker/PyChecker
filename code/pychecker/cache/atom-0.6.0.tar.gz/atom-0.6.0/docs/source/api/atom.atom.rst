atom.atom module
================

.. automodule:: atom.atom
    :members:
    :undoc-members:
    :show-inheritance:
