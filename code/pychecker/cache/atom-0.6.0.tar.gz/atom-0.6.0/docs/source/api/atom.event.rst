atom.event module
=================

.. automodule:: atom.event
    :members:
    :undoc-members:
    :show-inheritance:
