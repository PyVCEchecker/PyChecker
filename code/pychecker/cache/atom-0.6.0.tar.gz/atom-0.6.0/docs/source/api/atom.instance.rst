atom.instance module
====================

.. automodule:: atom.instance
    :members:
    :undoc-members:
    :show-inheritance:
