atom.scalars module
===================

.. automodule:: atom.scalars
    :members:
    :undoc-members:
    :show-inheritance:
