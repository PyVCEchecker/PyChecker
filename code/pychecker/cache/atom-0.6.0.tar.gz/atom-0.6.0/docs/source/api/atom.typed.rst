atom.typed module
=================

.. automodule:: atom.typed
    :members:
    :undoc-members:
    :show-inheritance:
