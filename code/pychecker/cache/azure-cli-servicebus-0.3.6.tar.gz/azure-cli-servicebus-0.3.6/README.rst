Microsoft Azure CLI 'servicebus' Command Module
=======================================================

This package is for the 'servicebus' module.
i.e. 'az servicebus'


