"""AWS Cloudformation-based deployment helper."""

import os
import inspect


__version__ = "1.5.10"
__dir__ = os.path.dirname(inspect.getfile(inspect.currentframe()))
