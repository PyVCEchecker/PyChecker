Before contributing to *doc8* or any other PyCQA project, we suggest you read
the PyCQA meta documentation:

   http://meta.pycqa.org/en/latest/

Patches for *doc8* should be submitted to GitHub, as should bugs:

   https://github.com/pycqa/doc8
