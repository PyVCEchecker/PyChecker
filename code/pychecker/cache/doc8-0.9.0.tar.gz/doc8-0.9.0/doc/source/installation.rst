============
Installation
============

At the command line::

    $ pip install doc8

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv doc8
    $ pip install doc8
