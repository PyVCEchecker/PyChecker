"""
    alipay/utils.py
    ~~~~~~~~~~

"""

class AliPayConfig:
    def __init__(self, timeout=15):
        self.timeout = timeout
