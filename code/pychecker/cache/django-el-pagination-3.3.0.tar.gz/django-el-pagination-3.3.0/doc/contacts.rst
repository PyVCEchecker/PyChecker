Source code and contacts
========================

Repository and bugs
~~~~~~~~~~~~~~~~~~~

The **source code** for this app is hosted on
https://github.com/shtalinberg/django-el-pagination.

To file **bugs and requests**, please use
https://github.com/shtalinberg/django-el-pagination/issues.

Contacts
~~~~~~~~

Oleksandr Shtalinberg

- Email: ``o.shtalinberg at gmail.com``

Francesco Banconi

- Email: ``frankban at gmail.com``
- IRC: ``frankban@freenode``
