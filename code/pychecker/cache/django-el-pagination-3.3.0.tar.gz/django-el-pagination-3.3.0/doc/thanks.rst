Thanks
======

This application was initially inspired by the excellent tool
*django-pagination* (see https://github.com/ericflo/django-pagination).

Thanks to Francesco Banconi for improving previos version of this application
(django-endless-pagination)

Thanks to Jannis Leidel for improving the application with some new features,
and for contributing the German translation.

And thanks to Nicola 'tekNico' Larosa for reviewing the documentation and for
implementing the elastic pagination feature.
