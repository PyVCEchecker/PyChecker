"""Pagination exceptions."""

from __future__ import unicode_literals


class PaginationError(Exception):
    """Error in the pagination process."""
