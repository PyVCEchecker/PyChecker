.. _integration:

Integration with third party applications
=========================================

todo: write doc for "Integration with third party applications" section.
