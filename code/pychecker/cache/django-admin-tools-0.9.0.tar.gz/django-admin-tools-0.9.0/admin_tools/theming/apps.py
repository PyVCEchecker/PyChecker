# coding: utf-8
from django.apps import AppConfig


class ThemingConfig(AppConfig):
    name = 'admin_tools.theming'
