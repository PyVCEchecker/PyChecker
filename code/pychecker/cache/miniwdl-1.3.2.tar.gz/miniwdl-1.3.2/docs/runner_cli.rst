``miniwdl run`` command line
============================

.. argparse::
   :module: WDL.CLI
   :func: create_arg_parser
   :prog: miniwdl
   :path: run
   :nodefaultconst:
