from argparse import ArgumentParser

def autocomplete(parser : ArgumentParser) -> None:
    ...

def warn(msg : str) -> None:
    ...
