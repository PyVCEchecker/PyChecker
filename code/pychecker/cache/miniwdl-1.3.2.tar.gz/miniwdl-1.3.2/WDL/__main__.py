# PYTHON_ARGCOMPLETE_OK
from . import CLI

if __name__ == "__main__":
    CLI.main()
