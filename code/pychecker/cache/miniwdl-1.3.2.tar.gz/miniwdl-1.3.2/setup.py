#!/usr/bin/env python3
import setuptools

setuptools.setup(
    setup_requires=['pbr'],
    pbr=True,
    python_requires=">3.6.0",
)
