VERSION = (1, 3, 1)

default_app_config = 'sitegate.config.SitegateConfig'