"""File contains exceptions used by sitegate."""


class SiteGateError(Exception):
    """Exception class for sitesignup application."""
