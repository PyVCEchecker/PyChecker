useful_contracts Package
========================

:mod:`useful_contracts` Package
-------------------------------

.. automodule:: contracts.useful_contracts
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`numbers` Module
---------------------

.. automodule:: contracts.useful_contracts.numbers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`numpy_specific` Module
----------------------------

.. automodule:: contracts.useful_contracts.numpy_specific
    :members:
    :undoc-members:
    :show-inheritance:

