.. include:: definitions.txt

.. include:: menu.txt

.. _credits:

Credits
-------

(Let me know if I forgot to include you)

- `Brett Graham`_: ``attr(name:type)`` syntax for checking types of attributes.
- `William Furr`_: bug reports and performance improvements
- `Karol Kuczmarski`_: implementation of "string" and "unicode" contracts
- Bernhard Biskup
- Adam Palay (EdX)

.. _`William Furr`: http://www.ccs.neu.edu/home/furrwf/
.. _`Karol Kuczmarski`:  http://xion.org.pl/
.. _`Brett Graham`: https://github.com/braingram

.. include:: menu.txt
