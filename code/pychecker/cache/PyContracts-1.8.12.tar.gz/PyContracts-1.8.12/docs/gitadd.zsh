#!/bin/zsh
cd website
git add **/*
git commit -a -m "added"
exit 0