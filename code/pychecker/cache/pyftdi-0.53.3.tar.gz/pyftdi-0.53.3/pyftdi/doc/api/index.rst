API documentation
=================

.. include:: ../defs.rst

|release|
---------

.. toctree::
   :maxdepth: 1
   :glob:

   ftdi
   gpio
   i2c
   spi
   uart
   usbtools
   misc
   eeprom
