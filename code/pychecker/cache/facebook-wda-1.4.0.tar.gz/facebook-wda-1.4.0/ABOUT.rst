Documentation in <https://github.com/openatx/facebook-wda>
