网易云音乐测试例子

运行测试方法

    py.test -vv

Sample output

    collected 2 items

    test_discover_music.py::test_discover_music PASSED
    test_discover_music.py::test_my_music PASSED