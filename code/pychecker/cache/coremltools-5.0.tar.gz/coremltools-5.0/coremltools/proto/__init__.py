### Module for proto generated Python code.
