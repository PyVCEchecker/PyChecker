# coding: utf-8
# This file is imported from __init__.py and exec'd from setup.py

__version__ = '0.3.1'
__description__ = 'Parse and manipulate version numbers.'

__license__ = 'MIT'

__author__ = 'Frazer McLean'
__email__ = 'frazer@frazermclean.co.uk'
