class UnknownStatusError(Exception):
    pass


class InvalidResponse(Exception):
    pass


class InvalidExpectedStatus(Exception):
    pass
