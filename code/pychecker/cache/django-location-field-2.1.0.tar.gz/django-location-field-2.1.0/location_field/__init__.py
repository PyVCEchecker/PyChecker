__version__ = '2.1.0'

default_app_config = 'location_field.apps.DefaultConfig'
