---
name: Question
about: Ask a question
title: ''
labels: ''
assignees: ''

---

PLEASE DO NOT USE ISSUE TRACKER TO ASK QUESTIONS: see [contributing](https://github.com/pydoit/doit/blob/master/CONTRIBUTING.md)
