
static int SIZE = 20;
 
