DOIT_CONFIG = {'default_tasks': ['my_task_1', 'my_task_2'],
               'continue': True,
               'reporter': 'json'}
