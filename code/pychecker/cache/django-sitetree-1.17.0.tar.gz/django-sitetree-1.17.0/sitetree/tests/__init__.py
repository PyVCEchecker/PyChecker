# This package is considered both as a django app, and a test package.
