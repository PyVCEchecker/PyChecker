from sitetree.sitetreeapp import SiteTree


class MySiteTree(SiteTree):
    """Custom tree handler to test deep customization abilities."""

    customized = True
