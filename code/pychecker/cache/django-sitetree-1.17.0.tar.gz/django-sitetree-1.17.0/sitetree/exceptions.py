

class SiteTreeError(Exception):
    """Exception class for sitetree application."""
