VERSION = (1, 17, 0)


default_app_config = 'sitetree.config.SitetreeConfig'