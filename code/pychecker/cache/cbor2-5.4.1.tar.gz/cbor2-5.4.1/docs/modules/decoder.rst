:mod:`cbor2.decoder`
====================

.. automodule:: cbor2.decoder
    :members:
