:mod:`cbor2.types`
==================

.. automodule:: cbor2.types
    :members:
