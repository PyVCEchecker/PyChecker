# This is pyisbn version 1.3.1 (2020-02-14)
# pylint: skip-file

dotted = '1.3.1'
libtool = '13:21'
hex = 0x010301
date = '2020-02-14'
tuple = (1, 3, 1)
dict = {'major': 1, 'minor': 3, 'micro': 1}
web = 'pyisbn/1.3.1'
