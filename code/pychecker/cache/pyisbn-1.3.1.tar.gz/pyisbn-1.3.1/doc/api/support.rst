.. currentmodule:: pyisbn

Internal support features
=========================

.. autodata:: DASHES

.. autodata:: URL_MAP

Types
-----

.. autodata:: TIsbn
.. autodata:: TIsbn10
.. autodata:: TIsbn13
.. autodata:: TSbn

.. spelling::

    SBN
    getdefaultencoding
    repr
    str
    sys
