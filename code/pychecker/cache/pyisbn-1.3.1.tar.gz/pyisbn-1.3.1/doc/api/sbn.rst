.. currentmodule:: pyisbn

Handling SBNs
=============

.. autoclass:: Sbn

.. spelling::

    SBN
