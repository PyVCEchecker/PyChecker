Frequently Asked Questions
--------------------------

..
   Sadly, these two questions come up often enough that I’ve felt the need to
   write a pre-emptive response here.  I hoping it will allow me to skip the
   awkwardness I feel when writing individual replies…

Can you release this under a more permissive licence?
'''''''''''''''''''''''''''''''''''''''''''''''''''''

I’m sorry, but no.

For pet projects I choose to use reciprocal licences because I like them, not
because I’m unaware of their impact.

Can we buy a licence to embed this within a closed source product?
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

I’m sorry, but no.

This isn’t an issue of money, so there is no need to make each other feel
uncomfortable with a bidding discussion.

.. spelling::

    isn
