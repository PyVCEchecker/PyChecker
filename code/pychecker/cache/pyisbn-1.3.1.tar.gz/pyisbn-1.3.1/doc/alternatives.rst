Alternatives
============

Before diving in and spitting out this package I looked for alternatives, but
back in 2006 there were none to be found.  There are, now, a few available and
I’ll list them here when people point them out.  If I have missed something
please drop me a mail_.

.. _mail: jnrowe@gmail.com

``python-stdnum``
-----------------

python-stdnum_ by Arthur de Jong is a package to validate identifiers in a huge
range of formats, including ISBNs.

.. _python-stdnum: https://pypi.org/project/python-stdnum/
