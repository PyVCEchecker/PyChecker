Be tolerant and civil, and above all have fun.
