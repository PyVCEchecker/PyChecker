.. image:: https://travis-ci.com/zopefoundation/AccessControl.svg?branch=master
   :target: https://travis-ci.com/zopefoundation/AccessControl

.. image:: https://coveralls.io/repos/github/zopefoundation/AccessControl/badge.svg?branch=master
   :target: https://coveralls.io/github/zopefoundation/AccessControl?branch=master

.. image:: https://img.shields.io/pypi/v/AccessControl.svg
   :target: https://pypi.org/project/AccessControl/
   :alt: Current version on PyPI

.. image:: https://img.shields.io/pypi/pyversions/AccessControl.svg
   :target: https://pypi.org/project/AccessControl/
   :alt: Supported Python versions


AccessControl
=============

AccessControl provides a general security framework for use in Zope.
