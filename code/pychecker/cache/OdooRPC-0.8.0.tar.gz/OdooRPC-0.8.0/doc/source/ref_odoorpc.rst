odoorpc
=======

.. automodule:: odoorpc
