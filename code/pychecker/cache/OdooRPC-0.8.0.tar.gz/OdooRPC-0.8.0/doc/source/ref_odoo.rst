odoorpc.ODOO
============

.. autoclass:: odoorpc.ODOO
    :members:

