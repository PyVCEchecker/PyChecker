odoorpc.rpc
===========

.. automodule:: odoorpc.rpc
    :members:
