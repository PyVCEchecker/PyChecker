odoorpc.env
===========

.. automodule:: odoorpc.env
    :members:
    :special-members: __getitem__, __contains__
    :exclude-members: commit, dirty, invalidate
