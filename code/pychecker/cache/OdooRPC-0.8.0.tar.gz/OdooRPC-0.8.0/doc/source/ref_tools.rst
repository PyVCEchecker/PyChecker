odoorpc.tools
=============

.. automodule:: odoorpc.tools
    :members:
