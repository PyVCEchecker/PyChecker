.. include:: ../README.rst
   :start-after: inclusion-marker-badges-start
   :end-before: inclusion-marker-badges-end