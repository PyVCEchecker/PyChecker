.. BeautifulTable documentation master file, created by
   sphinx-quickstart on Sun Dec 18 15:59:32 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

##########################################
Welcome to beautifultable's documentation!
##########################################

.. include:: badges.rst

.. include:: introduction.rst
   
.. include:: links.rst


******************************************
Contents
******************************************

.. toctree::
   :maxdepth: 3
   
   install
   quickstart
   changelog


.. include:: donation.rst
