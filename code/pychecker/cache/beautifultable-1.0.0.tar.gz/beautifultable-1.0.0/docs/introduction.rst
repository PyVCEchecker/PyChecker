.. include:: ../README.rst
   :start-after: inclusion-marker-introduction-start
   :end-before: inclusion-marker-introduction-end