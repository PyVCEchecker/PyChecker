.. include:: ../README.rst
   :start-after: inclusion-marker-donation-start
   :end-before: inclusion-marker-donation-end