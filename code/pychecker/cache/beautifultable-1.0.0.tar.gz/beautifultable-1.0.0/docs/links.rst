.. include:: ../README.rst
   :start-after: inclusion-marker-links-start
   :end-before: inclusion-marker-links-end