from PyQt5.QtMultimedia import (
    QAbstractVideoBuffer,
    QAbstractVideoSurface,
    QAudio,
    QAudioDeviceInfo,
    QAudioFormat,
    QAudioInput,
    QAudioOutput,
    QVideoFrame,
    QVideoSurfaceFormat
)