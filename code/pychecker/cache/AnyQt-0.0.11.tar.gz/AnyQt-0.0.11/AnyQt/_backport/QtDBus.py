from .. import _api

assert _api.USED_API is _api.QT_API_PYQT5

from PyQt5.QtDBus import *
