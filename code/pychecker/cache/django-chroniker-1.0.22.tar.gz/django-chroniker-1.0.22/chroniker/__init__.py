VERSION = (1, 0, 22)
__version__ = '.'.join(map(str, VERSION))
