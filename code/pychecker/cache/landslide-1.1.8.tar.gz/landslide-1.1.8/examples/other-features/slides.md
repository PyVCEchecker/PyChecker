# Other Features

---

# Math

MathJax rendering is available for presentations compiled with the `-m` flag

\\[ \\left( \\sum_{k=1}^n a_k b_k \\right)^2 \\]

---

# QR Codes

.qr: 450|http://github.com/adamzap/landslide
