HOME_PATH = "~/.autovizwidget"
CONFIG_FILE = "config.json"

GRAPH_RENDER_EVENT = "notebookGraphRender"
GRAPH_TYPE = "GraphType"
